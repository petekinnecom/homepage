Notes on 'editor.jar':

Click a tile on the selection window, then place it in the level screen.  Tiles can be rotated and mirrored.  Test a level and the physics play selecting 'test play' under options.  


----------------CONTROLS----------------------------

Level editor:

wsad to move

q/e to zoom

click to place tile.

Scroll wheel up to rotate tile.

Scroll wheel down to reflect tile.

Right click to delete a tile.

Save/load working.

Test play!  Weeeeeeeeeee!  (wsad to move)

---------------------
Tile selection panel:

Left click to select tile.

Right click to edit vectors.

Save before exiting!

-----------------------
Vector edit frame:

Left click to begin placing vectors.  

Middle click when finished.  

Use a menu option to erase and restart.

Right click a vector to edit its properties.  

Note: dummy/not dummy to be explained later.

Updates are not saved when you hit OK.  They are saved when you hit "save" in the tile editor.  