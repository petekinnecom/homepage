/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.awt.event.ActionEvent;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Timer;

/**
 *
 * @author pete
 */
class ServerController
{

    private GameView view;
    private ArrayList<ServerPlayerModel> serverPlayers;
    private int TICK_ACTION = 15;
    private int GAME_TICK_MILLISECONDS = 10;
    private int totalTicks = 1;
    DatagramSocket socket;
    Timer gameTimer;
    Thread playerJoinReaderThread;

    ServerController()
    {
        MainFrame mainFrame = new MainFrame();
        view = mainFrame.init();

        this.serverPlayers = new ArrayList<ServerPlayerModel>();
        gameTimer = new Timer(GAME_TICK_MILLISECONDS, gameTick);
        try
        {
            socket = new DatagramSocket();
        } catch (SocketException ex)
        {
            C.print("Could not create DatagramSocket.");
            ex.printStackTrace();
            System.exit(1);
        }
        mainFrame.setListeners(this);
        playerJoinReaderThread = new Thread(new PlayerJoinReaderThread());
        playerJoinReaderThread.start();
    }

    public synchronized void start()
    {
        C.print("Broadcasting startcode");
        playerJoinReaderThread.interrupt();

        gameTimer.start();

        broadcast(new ControlCode(ControlCode.GAME_START));
    }

    public void stop()
    {
        C.print("Broadcasting stopcode");
        gameTimer.stop();
        broadcast(new ControlCode(ControlCode.GAME_END));
    }

    Action gameTick = new AbstractAction()
    {

        private int tickPhase = 0;

        public void actionPerformed(ActionEvent e)
        {

            tickPhase = (tickPhase + 1) % TICK_ACTION;
            if (tickPhase == 0)
            {

                //Assemble the players and draw them
                ArrayList<PlayerModel> players = new ArrayList<PlayerModel>();
                for (ServerPlayerModel sp : serverPlayers)
                {
                    if (sp.getPlayer() != null)
                    {
                        players.add(sp.getPlayer());
                    }
                }
                view.drawPanel(players, (1.0d * tickPhase) / TICK_ACTION);

                // AND SEND DATA
                send();
                //ugly hack to make sure we don't kick everyone right away.
                if (totalTicks > 1)
                {

                    //Now let's see if we have a winner.
                    int alive = 0;
                    String winner = "";
                    for (ServerPlayerModel sp : serverPlayers)
                    {
                        if (sp.getPlayer() != null)
                        {
                            if (sp.getPlayer().isAlive())
                            {
                                alive++;
                                winner = sp.getName();
                            }
                        }
                    }
//                    if (alive == 1)
//                    {
//                        broadcast(new ControlCode(ControlCode.GAME_END));
//                        broadcast(new ControlCode(ControlCode.CHAT, winner + " wins the game!"));
//                        stop();
//                    }
//                    if (alive == 0)
//                    {
//                        broadcast(new ControlCode(ControlCode.GAME_END));
//                        broadcast(new ControlCode(ControlCode.CHAT, "Error, everyone lost!"));
//                        stop();
//                    }
                    totalTicks = 0;
                }
                totalTicks++;
            }
        }

    };

    private synchronized void send()
    {
        for (int i = 0; i < serverPlayers.size(); i++)
        {
            ArrayList<PlayerModel> toSend = new ArrayList<PlayerModel>();
            ServerPlayerModel sp = serverPlayers.get(i);
            int addToForecast = 0;
            for (int j = 0; j < serverPlayers.size(); j++)
            {
                if (j != i)
                {
                    PlayerModel p = serverPlayers.get(j).getPlayer();


                    //make it positive
                    if (p != null)
                    {
                        addToForecast += (-1) * serverPlayers.get(j).getPlayer().getExcess();
                        toSend.add(p.clone());
                    }
                }
            }
            try
            {

                PacketWrapper packet = new PacketWrapper(sp.getClientID(), totalTicks, toSend, addToForecast);
                ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();
                ObjectOutputStream objectOut = new ObjectOutputStream(byteArrayOut);
                objectOut.writeObject(packet);

                byte[] b = byteArrayOut.toByteArray();

                InetAddress address = sp.getAddress();

                //ADD 1 for local testing!
                DatagramPacket p = new DatagramPacket(b, b.length, address, sp.getDatagramPort() + 1);


                socket.send(p);

            } catch (Exception e)
            {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }

    private void broadcast(ControlCode out)
    {
        Thread broadcastThread = new Thread(new BroadcastWriter(out));
        broadcastThread.start();
    }

    void processInput(String s)
    {
        if (s.equalsIgnoreCase("start"))
        {
            C.print("starting game.");
            start();
        } else if (s.equalsIgnoreCase("stop"))
        {
            C.print("Stopping game.");
            stop();
        } else
        {
            String[] part = s.split(":");
            if(part[0].equalsIgnoreCase("set"))
            {
                if(part[1].equalsIgnoreCase("forecast_multiplier"))
                {
                    int n = Integer.parseInt(part[2]);
                    C.print("Sending command to set forecast_multiplier to "+n);
                    broadcast(new ControlCode(ControlCode.SET_FORECAST_MULTIPLIER, n));
                }
                else if(part[1].equalsIgnoreCase("forecast_random"))
                {
                    int n = Integer.parseInt(part[2]);
                    C.print("Sending command to set forecast_random to "+n);
                    broadcast(new ControlCode(ControlCode.SET_FORECAST_RANDOM, n));
                }
                else if(part[1].equalsIgnoreCase("overflow_limit"))
                {
                    int n = Integer.parseInt(part[2]);
                    C.print("Sending command to set overflow_limit to "+n);
                    broadcast(new ControlCode(ControlCode.SET_OVERFLOW_LIMIT, n));
                }
            }
        }
    }

    private class BroadcastWriter implements Runnable
    {

        private ControlCode out;

        public BroadcastWriter(ControlCode out)
        {
            this.out = out;
        }

        public void run()
        {
            for (ServerPlayerModel sp : serverPlayers)
            {
                sp.getTCPSocket().writeControlCode(out);
            }
        }

    }

    private class PlayerTCPReaderThread implements Runnable
    {

        private ServerPlayerModel sp;
        private boolean connected = true;

        public PlayerTCPReaderThread(ServerPlayerModel sp)
        {
            this.sp = sp;
        }

        public void run()
        {

            // We will assume for now that all incoming
            // messages from clients are simply chat.
            ControlCode in;
            while (!Thread.currentThread().isInterrupted() && connected)
            {
                in = sp.getTCPSocket().readControlCode();
                if (in != null)
                {
                    String s = sp.getName() + ": " + in.s;
                    broadcast(new ControlCode(s));
                } else
                {
                    // we appear to have lost contact with
                    // this player.  This could be handled
                    // in a better manner, i.e. deleting
                    // the player from the collection,
                    // but this will at least stop the
                    // errors and complaints for now.
                    connected = false;
                }
            }
        }

    }

    private class PlayerJoinReaderThread implements Runnable
    {

        public void run()
        {
            try
            {
                ServerSocket server = new ServerSocket(C.TCP_PORT);
                int i = 0;
                while (!Thread.currentThread().isInterrupted())
                {
                    // datagramPort hack
                    // used for local testing
                    int port = C.TCP_PORT + 2 *i;
                    //int port = C.TCP_PORT + i;
                    C.print("Waiting for players");
                    Socket s = server.accept();
                    SocketController TCPSocket = new SocketController(s);
                    ControlCode in;
                    ControlCode out = new ControlCode();

                    C.print("writing clientID : " + i);
                    out.code = i;
                    TCPSocket.writeControlCode(out);

                    C.print("writing port : " + port);
                    out.code = port;
                    TCPSocket.writeControlCode(out);

                    C.print("Reading user name.");
                    in = TCPSocket.readControlCode();
                    String name = in.s;
                    if (name.isEmpty())
                    {
                        name = "NoName_" + i;
                    }

                    C.print("Read user name: " + name);
                    TCPSocket.writeControlCode(in);
                    ServerPlayerModel sp = new ServerPlayerModel(TCPSocket, name, i, port);
                    serverPlayers.add(sp);
                    sp.startReaderThread();
                    Thread t = new Thread(new PlayerTCPReaderThread(sp));
                    t.start();
                    broadcast(new ControlCode("Player " + name + " has joined."));
                    i++;
                }

            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }
}
