
package mathtris;

import java.io.Serializable;

/**
 *
 * @author pete
 */
public class PlayerModel implements Serializable, Cloneable
{

    private Board board;
    private Cloud cloud;
    private int forecast;
    private int tick = 0;
    private int excess = 0;
    private int overflowCount;
    private boolean alive;

    private boolean[] underControl = {false, false, false, false, false, false};

    PlayerModel()
    {
        this.overflowCount = 0;
        alive = true;
    }

    //Just used for cloning
    PlayerModel(Board board, Cloud cloud, int forecast, int tick, int excess, 
            boolean[] underControl, int overflowCount, boolean alive)
    {
        this.board = board;
        this.cloud = cloud;
        this.forecast = forecast;
        this.tick = tick;
        this.excess = excess;
        this.underControl = underControl;
        this.overflowCount = overflowCount;
        this.alive = alive;

    }

    @Override
    public PlayerModel clone()
    {
        boolean[] tmp = new boolean[underControl.length];
        for(int i=0;i<underControl.length;i++)
        {
            tmp[i] = underControl[i];
        }
        return new PlayerModel(board.clone(), cloud.clone(), forecast, tick, 
                excess, tmp, overflowCount, alive);
    }

    PlayerModel(Board b, Cloud c)
    {
        this();
        board = b;
        cloud = c;
        forecast = 0;
    }

    public void gameTick(int tickPhase, Square s)
    {
        if(!alive)
            return;
        
        if(s!=null)
            cloud.makeItRain(s);
        else if(forecast > 10)
        {
            cloud.makeItRain();
            cloud.makeItRain();
            forecast--;
        }
        else if(forecast>1 && tickPhase%12==0)
        {
            cloud.makeItRain();
            forecast--;

        }

        Square.setControl(underControl);
        board.move();
        cloud.move();

// <editor-fold defaultstate="collapsed" desc="comment">
/*
         * These functions merely set the direction vector for the squares.
         * Squares should not set their vector and move immediately, or else we
         * will bypass the animation phase.  So, we set the vectors and let them
         * sit until the next action phase.
         * 
         * Each of these functions decides which squares are allowed to move.
         */// </editor-fold>


        board.gravitate();
        cloud.gravitate(board);
        cloud.resetHorizontals();
        board.explodeSquares();
        forecast -= board.deleteSquares();

        //If we deleted more than we're forecast, throw these to other players
        excess = Math.min(forecast, 0);

        //Now reset forecast to be non-negative
        forecast = Math.max(forecast, 0);
        tick++;
        if(overflowed())
        {
            overflowCount++;
            if(overflowCount == C.OVERFLOW_LIMIT)
            {
                this.alive = false;
                board.setSquaresGray();
                cloud.setSquaresGray();
            }
            else
            {
                board = new Board();
                cloud = new Cloud();
            }
        }
    }

    public boolean overflowed()
    {
        return board.overflowed();
    }

    void movePiece(int i, int j)
    {
        cloud.setDirection(board, i, j);
    }

    public void changeControl(int v, boolean b)
    {
        underControl[v] = b;
        //System.out.println("changed control of "+v+" to "+b);
    }

    /*
     * getBoard and getCloud exist for the GameView, so that it can pass
     * each some Graphics g, and have them draw themselves.
     */
    public Board getBoard()
    {
        return board;
    }
    public Cloud getCloud()
    {
        return cloud;
    }

    public boolean[] getControl()
    {
        return underControl;
    }

    public int getForecast()
    {
        return forecast;
    }

    void addForecast(int i)
    {
        forecast += i;
    }
    public int getTick()
    {
        return tick;
    }
    @Override
    public String toString()
    {
        return  "tick: " + tick + " forecast: "+forecast;
    }
    public int getExcess()
    {
        return excess;
    }

    boolean isAlive()
    {
        return alive;
    }
}
