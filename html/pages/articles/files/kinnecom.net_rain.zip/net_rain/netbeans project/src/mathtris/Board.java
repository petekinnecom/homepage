
package mathtris;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Board implements Serializable,Cloneable{

    private ArrayList<Square> squares;

    Board()
    {

        squares = new ArrayList<Square>();
        for (int i = 0; i < C.BOARD_WIDTH; i++)
        {
            for (int j = 0; j < C.STARTING_BOARD_HEIGHT; j++)
            {
                squares.add(new Square(i,j));
            }
        }

    }
    Board(ArrayList<Square> tmp)
    {
        this.squares = tmp;
    }

    @Override
    public Board clone()
    {
        ArrayList<Square> tmp = new ArrayList<Square>();
        for(Square s : squares)
        {
            tmp.add(s.clone());
        }
        return new Board(tmp);
    }
    void mergeToBoard(Square s)
    {
        squares.add(s);
        s.setDirection(0,0);
        s.setRedraw(true);
    }

    public int deleteSquares()
    {
        int deleted = 0;
        ArrayList<Square> toDelete = new ArrayList<Square>();
        for (Square s : squares)
        {
            if(s.getPoint().y<0)
            {
                System.out.println("error");
            }
            if (s.hasExploded())
            {
                toDelete.add(s);
                deleted++;
            }
        }
        for (Square s:toDelete)
        {
            squares.remove(s);
        }
        return deleted;
    }

    void explodeSquares()
    {
        //Now the hard part of ensuring everything works.
        Collections.sort(squares);
        for (Square s : squares)
        {
            if(s.getExplodeStage()>0)
            {
                s.explode();
            } else
            {
                if (s.getInfected() && numberOfNeighbors(s)>0)
                {
                    s.explode();
                    infectNeighbors(s);
                }

            }
        }
    }

    private boolean infectNeighbors(Square s)
    {
        boolean changedSomething = false;
        for(Square b : squares)
        {
            if(!b.getInfected() && b.isNeighbor(s, s.getValue()))
            {
                b.infect();
                b.explode();
                while(infectNeighbors(b)){}
                changedSomething = true;
            }
        }
        return changedSomething;
    }
    /* Here we check below the square.  If there is nothing there, or
     * if the square found there is moving downward, then we set the vector.
     * Because squares are sorting ASC x then ASC y, the vertical vectors will
     * be set in the correct domino order.
     */
    public boolean canFall(Square s)
    {
        Point sp = s.getPoint();
        Point bp;
        boolean r = true;
        if(sp.y==0)
            r = false;

        //Collections.sort(squares);

        for(Square b : squares)
        {
            bp = b.getPoint();
            //same column
            if(sp.x==bp.x)
            {
                //just above
                if(sp.y-bp.y==1)
                {
                    //not moving down already
                    if(b.getDirection().y != -1)
                    {
                        r = false;
                    }
                }
            }

        }
        //System.out.print("S: "+s.toString() + " can move? "+r+"\n"+squares.toString()+"\n*********************************************\n");

        return r;
    }

    /*
     * Here we'll decide whether a raindrop can move to a space or not.
     * We will check to see if it's empty and that no other board piece is
     * moving in.
     * 
     * This should probably be the same functionality as canFall, but meh.
     */
    public boolean canMoveTo(int i, int j)
    {
        if(i<0 || i>=C.BOARD_WIDTH || j<0)
            return false;
        Point sp;
        for(Square s : squares)
        {
            sp = s.getPoint();
            if(sp.x==i && sp.y==j)
                return false;
            if(sp.x==i && sp.y==j+1)
                return false;
        }
        return true;
    }

    public void fixDirection(Square s)
    {
        for(Square b : squares)
        {
            Point bp = b.getPoint();
            Point sp = s.getPoint();

            Point bn = b.getNextPoint();
            Point sn = s.getNextPoint();
            if (bn.equals(sn))
            {
                if (bp.x != sp.x)
                {
                    s.setHorizontalDirection(0);
                }
                if (bp.y != sp.y)
                {
                    s.changeDirection(0, 1);
                    fixDirection(s);
                }
            }
        }
    }

    void gravitate()
    {
        for (Square s : squares)
        {
            if(canFall(s))
            {
                s.setVerticalDirection(-1);
            }
            else
            {
                s.setVerticalDirection(0);
            }
        }
    }

    private int numberOfNeighbors(Square s)
    {
        int i = 0;
        for(Square b : squares)
        {
            if(b.isNeighbor(s, s.getValue()))
            {
                i++;
            }
        }
        return i;
    }

    void move()
    {
        for(Square s : squares)
        {
            s.move();
        }
    }

    /*
     * Accessed from Gameview, we construct a small square for each
     * square to draw itself on.  We add tickPhase to smooth out
     * animations.
     */
    public void draw(
            Graphics g, int yMax, double xScale, double yScale,
            double tickPhase)
    {
        for (Square s : squares)
        {
            s.draw(g, xScale, yScale, yMax, tickPhase, false);
        }

    }

    public void erase(Graphics2D g)
    {
        for (Square s : squares)
        {
            s.erase(g);
        }
    }

    public boolean overflowed()
    {
        for(Square s : squares)
        {
            if(s.getPoint().y>=C.OVERFLOW_HEIGHT)
                return true;
        }
        return false;
    }

    void setSquaresGray()
    {
        for(Square s : squares)
        {
            s.setColor(Color.GRAY);
        }
    }

}
