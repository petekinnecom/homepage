/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mathtris;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author pete
 */
public class ServerModel implements Serializable{

    private ArrayList<PlayerModel> players;

    void initGameModel()
    {

    }

    public void gameTick(int tickCount)
    {
        Random gen = new Random();
        Square s;
        for(PlayerModel p : players)
        {
            s = null;
            if(tickCount == 0)
                s = new Square(gen.nextInt(C.BOARD_WIDTH),C.BOARD_HEIGHT);
            int toAdd = gen.nextInt(2);
            p.addForecast(toAdd);

            p.gameTick(tickCount, s);
        }
    }

    public void movePiece(int i, int j, int p)
    {
        Square.setControl(players.get(p).getControl());
        players.get(p).movePiece(i,j);
    }

    public void changeControl(int v, boolean b, int p)
    {
        players.get(p).changeControl(v, b);
    }


    public ArrayList<PlayerModel> getPlayers()
    {
        return players;
    }

    void setPlayers(ArrayList<PlayerModel> readPlayers)
    {
        players = readPlayers;
    }
    public PlayerModel getPlayer(int i)
    {
        if(i<players.size())
            return players.get(i);
        else
            return players.get(0);
    }

    void setPlayers(int i, PlayerModel p)
    {
        players.set(i,p);
    }



}
