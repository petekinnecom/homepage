package mathtris;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JDialog;
import javax.swing.Timer;

/**
 *
 * @author pete
 */
public class ClientController
{

    private ClientGameModel model;
    private GameView view;
    private MainFrame mainFrame;
    private Timer gameTimer;
    private JDialog connectionDialog;
    private ConnectionPanel connectionPanel = new ConnectionPanel(this);
    private int TICK_ACTION = 15;
    private int TICK_NEW_RAIN = 6;
    public static final int NUM_PLAYERS = 5;
    private int GAME_TICK_MILLISECONDS = 10;
    private static int NUMBER_OF_VALUES = 4;
    private static int BOMB_PERCENT = 20;
    private static int totalTicks = 1;
    private InetAddress datagramAddress;
    private int datagramPort;
    private DatagramSocket inputSocket, outputSocket;
    private int clientID;
    private boolean multiplayer = true;
    private SocketController TCPSocket;
    private Thread playerReaderThread, controlCodeReaderThread;

    ClientController()
    {
        C.print("GameController inited.");
        C.print("Initiating model/view.");
        Square.init(NUMBER_OF_VALUES, BOMB_PERCENT);
        model = new ClientGameModel();

        mainFrame = new MainFrame();
        view = mainFrame.init();
        mainFrame.setListeners(this);


        view.addKeyListener(new KeyHandler());
        gameTimer = new Timer(GAME_TICK_MILLISECONDS, gameTick);
        //startGame();
    }

    public void startSinglePlayer()
    {
        multiplayer = false;

        startGame();
    }

    public void connectToServer(String ip, String name)
    {
        stopGame();
        multiplayer = true;
        connectionDialog.setVisible(false);

        TCPSocket = null;

        try
        {
            C.print("connecting to " + ip);
            TCPSocket = new SocketController(ip, C.TCP_PORT);
            C.print("connected");
        } catch (Exception e)
        {
            C.print("failed to connect to server.");
            C.print(e.getMessage());
            return;
        }

        ControlCode out = new ControlCode();
        ControlCode in;

        in = TCPSocket.readControlCode();
        clientID = in.code;
        C.print("Received id: " + clientID);

        in = TCPSocket.readControlCode();
        datagramPort = in.code;
        C.print("Received port: " + datagramPort);

        out.s = name;
        TCPSocket.writeControlCode(out);

        in = TCPSocket.readControlCode();

        C.print("Server set name to " + in.s);

        try
        {
            C.print("Opening datagram sockets.");
            datagramAddress = TCPSocket.getAddress();
            outputSocket = new DatagramSocket();
            C.print("Datagram sockets opened successfully.");
        } catch (SocketException e)
        {
            C.print("Error opeing datagram sockets.");
            C.print(e.getMessage());
            return;
        }


        playerReaderThread = new Thread(new ClientPlayerModelReader(model, datagramPort));
        controlCodeReaderThread = new Thread(new TCPReader());
        controlCodeReaderThread.start();
        playerReaderThread.start();
    }

    private void startGame()
    {
        C.print("Starting game.");
        mainFrame.showGameView();
        model.newPlayer();
        gameTimer.start();
    }

    private void stopGame()
    {
        C.print("Game ended.");
        gameTimer.stop();
        //Should stop reader threads here!
        mainFrame.showLobby();
        //playerReaderThread.interrupt();
    }

    Action gameTick = new AbstractAction()
    {

        private int tickPhase = 0;
        private int tickCount = 0;

        public void actionPerformed(ActionEvent e)
        {

            /*
             * tickPhase decides whether we're on an animation or action tick.
             * tickCount decides whether our action tick should spawn a raindrop
             */
            tickPhase = (tickPhase + 1) % TICK_ACTION;
            tickCount = (tickCount + 1) % (TICK_ACTION * TICK_NEW_RAIN);

            if (tickPhase == 0)
            {
                model.gameTick(tickCount);
                totalTicks++;

                if (multiplayer)
                {
                    PacketWrapper packet = new PacketWrapper(clientID, totalTicks, model.getPlayer(0));
                    send(packet);
                }
                //hack to make opponents not jump.
                //draw everyone on major tick
                view.drawPanel(model.getPlayers(), (1.0d * tickPhase) / TICK_ACTION);
            }
            //only draw this player on minor tick
            if (model.getPlayer(0).isAlive())
            {
                ArrayList<PlayerModel> justFirstPlayer = new ArrayList<PlayerModel>();
                justFirstPlayer.add(model.getPlayer(0));
                view.drawPanel(justFirstPlayer, (1.0d * tickPhase) / TICK_ACTION);
            }
        }

    };

    private void send(PacketWrapper packet)
    {
        try
        {
            ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();
            ObjectOutputStream objectOut = new ObjectOutputStream(byteArrayOut);
            objectOut.writeObject(packet);

            byte[] b = byteArrayOut.toByteArray();

            DatagramPacket p = new DatagramPacket(b, b.length, datagramAddress, datagramPort);
            //C.print("Sending PacketWrapper: Port: "+datagramPort+" "+packet.toString());
            outputSocket.send(p);
        } catch (Exception e)
        {
            C.print("Can't send PacketWrapper");
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void connectDialog()
    {

        connectionDialog = new JDialog(mainFrame, "Connect", true);
        connectionDialog.add(connectionPanel);
        connectionDialog.setLocationRelativeTo(mainFrame);
        connectionDialog.setResizable(false);
        connectionDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        connectionDialog.pack();
        connectionDialog.setVisible(true);
    }

    void sendChat(String text)
    {
        Thread t = new Thread(new TCPWriter(new ControlCode(text)));
        t.start();
    }

    private class KeyHandler implements KeyListener
    {

        public void keyTyped(KeyEvent e)
        {
        }

        public void keyPressed(KeyEvent e)
        {
            int p = 0;
            switch (e.getKeyCode())
            {

                case KeyEvent.VK_LEFT:
                {
                    model.movePiece(-1, -1, p);
                    break;
                }
                case KeyEvent.VK_RIGHT:
                {
                    model.movePiece(1, -1, p);
                    break;
                }
                case KeyEvent.VK_DOWN:
                {
                    model.movePiece(0, -2, p);
                    break;
                }
                case KeyEvent.VK_UP:
                {
                    //model.movePiece(0, 0, p);
                    break;
                }

            }
            processMove(e.getKeyCode(), true);

        }

        public void keyReleased(KeyEvent e)
        {

            processMove(e.getKeyCode(), false);

        }

        private void processMove(int keyCode, boolean b)
        {
            int p = 0;
            switch (keyCode)
            {

                case KeyEvent.VK_W:
                {
                    model.changeControl(0, b, p);
                    break;
                }
                case KeyEvent.VK_S:
                {
                    model.changeControl(1, b, p);
                    break;
                }
                case KeyEvent.VK_G:
                {
                    model.changeControl(2, b, p);
                    break;
                }
                case KeyEvent.VK_F:
                {
                    model.changeControl(3, b, p);
                    break;
                }

            }

        }

    }

    private class TCPReader implements Runnable
    {

        public void run()
        {
            ControlCode in;
            while (!Thread.currentThread().isInterrupted())
            {
                in = TCPSocket.readControlCode();
                //process code
                if (in.code == ControlCode.CHAT)
                {
                    C.print(in.s);
                } else if (in.code == ControlCode.GAME_START)
                {
                    C.print("Starting game.");
                    startGame();
                } else if (in.code == ControlCode.GAME_END)
                {
                    C.print("Ending game.");
                    stopGame();
                } else if (in.code == ControlCode.SET_FORECAST_MULTIPLIER)
                {
                    C.FORECAST_MULTIPLIER = in.n;
                    C.print("Set forecast multiplier to " + in.n);
                } else if (in.code == ControlCode.SET_FORECAST_RANDOM)
                {
                    C.FORECAST_RANDOM = in.n;
                    C.print("Set forecast randomizer to " + in.n);
                } else if (in.code == ControlCode.SET_OVERFLOW_LIMIT)
                {
                    C.OVERFLOW_LIMIT = in.n;
                    C.print("Set overflow limit to " + in.n);
                }
            }
        }

    }

    private class TCPWriter implements Runnable
    {

        ControlCode out;

        public TCPWriter(ControlCode out)
        {
            this.out = out;
        }

        public void run()
        {
            TCPSocket.writeControlCode(out);
        }

    }
}
