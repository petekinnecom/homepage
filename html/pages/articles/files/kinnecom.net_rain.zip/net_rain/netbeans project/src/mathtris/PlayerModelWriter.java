/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author pete
 */
public class PlayerModelWriter implements Runnable
{

    ArrayList<PlayerModel> toSend;
    Socket s;

    PlayerModelWriter(ArrayList<PlayerModel> toSend, Socket s)
    {
        this.toSend = toSend;
        this.s = s;
    }

    public void run()
    {
        try
        {
            ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
            out.writeObject(toSend);

        } catch (Exception e)
        {
            e.printStackTrace();
        }

    }

}
