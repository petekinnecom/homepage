/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mathtris;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author pete
 */
public class ClientGameModel implements Serializable{

    private ArrayList<PlayerModel> players;

    public ClientGameModel()
    {
        players = new ArrayList<PlayerModel>();
        /*
         * we will start with randomized board and cloud
         */
        players.add(new PlayerModel(new Board(), new Cloud()));
    }

    public synchronized void gameTick(int tickCount)
    {
        Random gen = new Random();
        Square s;
        s = null;

        if(tickCount == 0)
            s = new Square(gen.nextInt(C.BOARD_WIDTH),C.BOARD_HEIGHT);
        int toAdd = gen.nextInt(C.FORECAST_RANDOM);
        players.get(0).addForecast(toAdd);

        players.get(0).gameTick(tickCount, s);
    }

    public void movePiece(int i, int j, int p)
    {
        Square.setControl(players.get(p).getControl());
        players.get(p).movePiece(i,j);
    }

    public void changeControl(int v, boolean b, int p)
    {
        players.get(p).changeControl(v, b);
    }


    public ArrayList<PlayerModel> getPlayers()
    {
        return players;
    }

    public synchronized void updatePlayers(ArrayList<PlayerModel> bufferedPlayers, int addToForecast)
    {
        if(bufferedPlayers == null)
            return;
        ArrayList<PlayerModel> temp = new ArrayList<PlayerModel>();
        temp.add(players.get(0));
        for(PlayerModel p : bufferedPlayers)
        {
            if(p!=null)
                temp.add(p);
        }
        players = temp;
        players.get(0).addForecast(addToForecast*C.FORECAST_MULTIPLIER);
    }
    public PlayerModel getPlayer(int i)
    {
        if(i<players.size())
            return players.get(i);
        else
            return players.get(0);
    }

    void newPlayer()
    {
        players = new ArrayList<PlayerModel>();
        players.add( new PlayerModel(new Board(), new Cloud()));
    }

}
