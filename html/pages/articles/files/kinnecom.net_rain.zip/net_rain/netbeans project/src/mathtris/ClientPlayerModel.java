
package mathtris;

import java.io.Serializable;

/**
 *
 * @author pete
 */
public class ClientPlayerModel implements Serializable
{

    private Board board;
    private Cloud cloud;
    private int forecast;
    private int drained;

    private boolean[] underControl = {false, false, false, false, false, false};

    ClientPlayerModel()
    {
    }

    ClientPlayerModel(Board b, Cloud c)
    {
        board = b;
        cloud = c;
        forecast = 0;
        drained = 0;
    }

    void gameTick(int tickPhase, Square s)
    {
        if(s!=null)
            cloud.makeItRain(s);
        else if(forecast > 10)
        {
            cloud.makeItRain();
            cloud.makeItRain();
            forecast--;
        }
        else if(forecast>1 && tickPhase%12==0)
        {
            cloud.makeItRain();
            forecast--;

        }

        Square.setControl(underControl);
        board.move();
        cloud.move();

// <editor-fold defaultstate="collapsed" desc="comment">
/*
         * These functions merely set the direction vector for the squares.
         * Squares should not set their vector and move immediately, or else we
         * will bypass the animation phase.  So, we set the vectors and let them
         * sit until the next action phase.
         * 
         * Each of these functions decides which squares are allowed to move.
         */// </editor-fold>
        board.gravitate();
        cloud.gravitate(board);
        cloud.resetHorizontals();
        drained += board.deleteSquares();
        board.explodeSquares();
        forecast -= drained;
        drained = 0;
        forecast = Math.max(forecast, 0);
    }


    void movePiece(int i, int j)
    {
        cloud.setDirection(board, i, j);
    }

    public void changeControl(int v, boolean b)
    {
        underControl[v] = b;
        //System.out.println("changed control of "+v+" to "+b);
    }

    /*
     * getBoard and getCloud exist for the GameView, so that it can pass
     * each some Graphics g, and have them draw themselves.
     */
    public Board getBoard()
    {
        return board;
    }
    public Cloud getCloud()
    {
        return cloud;
    }

    public boolean[] getControl()
    {
        return underControl;
    }

    public int getForecast()
    {
        return forecast;
    }

    void addForecast(int i)
    {
        forecast += i;
    }

}
