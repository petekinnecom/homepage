/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author pete
 */
class GameView extends JPanel
{
    private BoardCanvas[] boardCanvas = new BoardCanvas[5];

    GameView()
    {

        for(int i = 0;i<5;i++)
        {
            boardCanvas[i] = new BoardCanvas();
        }

        this.setFocusable(true);
    }
    public void init()
    {
        GridBagLayout layout = new GridBagLayout();
        this.setLayout(layout);

        /*
         * MAIN LEFTMOST COLUMN
         */
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.gridheight = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(3,3,3,3);
        this.add(boardCanvas[0], gbc);



        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weightx = 0.5;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(1,1,1,1);
        this.add(boardCanvas[1], gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weightx = 0.5;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(1,1,1,1);
        this.add(boardCanvas[2], gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weightx = 0.5;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(1,1,1,1);
        this.add(boardCanvas[3], gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 3;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weightx = 0.5;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(1,1,1,1);
        this.add(boardCanvas[4], gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 4;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(1,1,1,1);

        //this.add(scroll, gbc);

        for(BoardCanvas c : boardCanvas)
        {
            c.init();
        }
    }

    public void drawPanel(ArrayList<PlayerModel> players, double tickPhase)
    {
        int i = 0;
        for(PlayerModel p : players)
        {
            boardCanvas[i].draw(p, tickPhase);
            i++;
        }

    }
    public void drawClear()
    {
        Graphics2D g = (Graphics2D) this.getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0,0,getWidth(), getHeight());
        g.dispose();
        for(BoardCanvas c : boardCanvas)
        {
            c.drawClear();
        }
    }
 }
