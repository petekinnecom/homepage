/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mathtris;

import java.io.Serializable;

/**
 *
 * @author pete
 */
public class ControlCode implements Serializable{

    public static final int GAME_START = 1;
    public static final int GAME_END = 2;
    public static final int PLAYER_DIED = 3;
    public static final int REQUEST_CLIENTID = 0;
    public static final int REQUEST_UDP_PORT = 4;
    public static final int PLAYER_NAME = 5;
    public static final int CHAT = 6;
    public static final int SET_FORECAST_MULTIPLIER = 7;
    public static final int SET_FORECAST_RANDOM = 8;
    public static final int SET_OVERFLOW_LIMIT = 9;

    public int code;
    public String s;
    public int n;

    ControlCode(int code, String s)
    {
        this.code = code;
        this.s = s;
    }
    ControlCode()
    {
        
    }

    ControlCode(int code)
    {
        this.code = code;
    }

    ControlCode(String text)
    {
        this.code = CHAT;
        this.s = text;
    }
    ControlCode(int code, int n)
    {
        this.code = code;
        this.n = n;
    }

    @Override
    public String toString()
    {
        return "code: "+code+", s: "+s;
    }
}
