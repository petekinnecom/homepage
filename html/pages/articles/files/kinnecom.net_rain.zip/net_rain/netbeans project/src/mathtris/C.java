/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

/**
 *
 * @author pete
 */
public class C
{

    public static final int BOARD_WIDTH = 6;
    public static final int BOARD_HEIGHT = 24;
    public static final int DEFAULT_WIDTH = 400;
    public static final int DEFAULT_HEIGHT = 400;
    public static final int NUM_PLAYERS = 5;
    public static int OVERFLOW_LIMIT = 1;
    public static int OVERFLOW_HEIGHT = BOARD_HEIGHT - 4;
    public static int STARTING_BOARD_HEIGHT = 3;
    static int FORECAST_RANDOM = 2;
    static int FORECAST_MULTIPLIER = 3;
    //ugly hack to make console on lobby and connection panel
    public static Console console = new Console();
    static SimpleDateFormat f = new SimpleDateFormat("HH:mm:ss");
    private static BufferedWriter log;
    public static final int TCP_PORT = 62112;

    public static void init()
    {
        try
        {
            SimpleDateFormat form = new SimpleDateFormat("HH.mm.ss");

            //log = new BufferedWriter(new FileWriter("Log - "+form.format(System.currentTimeMillis())+".txt"));
            log = new BufferedWriter(new FileWriter("log.txt"));
        } catch (IOException e)
        {
        }
    }

    public static void print(String s)
    {


        String time = f.format(System.currentTimeMillis());

        String out = time + " : " + s;
        System.out.println(out);
        console.out(out);
        try
        {
            log.write(out+"\n");
            log.flush();
        } catch (IOException e)
        {
        }
    }

}
