/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mathtris;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author pete
 */
public class PacketWrapper implements Serializable {


    public int tick;

    public PlayerModel p;
    public int totalForecast;

    public ArrayList<PlayerModel> players;
    public int clientID;

    PacketWrapper(int clientID, int tick,
            ArrayList<PlayerModel> players, int totalForecast)
    {

        this.clientID = clientID;
        this.players = players;
        this.totalForecast = totalForecast;
        this.tick = tick;

        this.p = null;

    }

    PacketWrapper(int clientID, int tick,
                    PlayerModel p)
    {
        this.clientID = clientID;
        this.p = p;
        this.tick = tick;

        this.players = null;
        this.totalForecast = 0;
    }
    @Override
    public String toString()
    {
        return "tick: " + tick +
                " totalForecast: " + totalForecast +
                " PlayerModel: " + p.toString() +
                " Players: [" + p.toString()+"]";
    }
}
