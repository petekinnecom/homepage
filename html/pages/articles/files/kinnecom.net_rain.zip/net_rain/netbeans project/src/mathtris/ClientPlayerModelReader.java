/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 *
 * @author pete
 */
public class ClientPlayerModelReader implements Runnable
{

    ClientGameModel model;
    int datagramPort;

    ClientPlayerModelReader(ClientGameModel model, int datagramPort)
    {
        this.model = model;

        // ADD 1 for local testing!
        // datagramPort hack
        this.datagramPort = datagramPort+1;
        //this.datagramPort = datagramPort;
    }

    public void run()
    {
        while (true)
        {

            try
            {
                DatagramSocket socket = new DatagramSocket(datagramPort);
                byte[] buf = new byte[500000];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);

                packet.getData();

                ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(packet.getData()));
                PacketWrapper tmp = (PacketWrapper) in.readObject();

                model.updatePlayers(tmp.players, tmp.totalForecast);

                socket.close();
            } catch (Exception e)
            {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }

}



