/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mathtris;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author pete
 */
class Cloud implements Serializable, Cloneable{

    private ArrayList<Square> rain;
    private Random gen = new Random();

    public Cloud()
    {
        rain = new ArrayList<Square>();
    }

    public Cloud(ArrayList<Square> tmp)
    {
        rain = tmp;
        gen = new Random();
    }
    @Override
    public Cloud clone()
    {
        ArrayList<Square> tmp = new ArrayList<Square>();
        for(Square s : rain)
        {
            tmp.add(s.clone());
        }
        return new Cloud(tmp);
    }

    public void makeItRain()
    {
        rain.add(new Square(gen.nextInt(C.BOARD_WIDTH), C.BOARD_HEIGHT));
    }

    void makeItRain(Square s)
    {
        rain.add(s);
    }
    public void gravitate(Board board)
    {
        
         /* 
          * toRemove avoids concurrent ArrayList editing
         */
        ArrayList<Square> toRemove = new ArrayList<Square>();
        for (Square s : rain)
        {
            if(board.canFall(s))
            {
                s.setVerticalDirection(-1);
            }
            else
            {
                board.mergeToBoard(s);
                toRemove.add(s);
            }
        }
        for(Square s : toRemove)
        {
            rain.remove(s);
        }
    }

    /*
     * The user has asked us to move the piece horizontally or downward.
     * Before we set the direction vectors, we must make sure the the board
     * has room for the square.
     */
    public void setDirection(Board board, int i, int j)
    {
        Point sp;
        for(Square s : rain)
        {
            if(s.getControl())
            {
                /*
                 * We set the direction, then fix it as appropriate
                 */
                s.setDirection(i, j);
                
                /* Some basic fixes first */
                Point n = s.getNextPoint();
                if(n.x<0 || n.x>=C.BOARD_WIDTH)
                    s.setHorizontalDirection(0);
                if(n.y<0 || n.y>=C.BOARD_HEIGHT)
                    s.setVerticalDirection(0);

                /* Now dependent fixes */
                board.fixDirection(s);
                this.fixDirection(s);
            }
        }
    }

    private void fixDirection(Square s)
    {

        Point sp = s.getPoint();
        Point sn = s.getNextPoint();

        Point bp, bn;

        for (Square b : rain)
        {
            bp = b.getPoint();
            bn = b.getNextPoint();

            if (bn.equals(sn) && !b.equals(s))
            {
                if (bp.x != sp.x)
                {
                    s.setHorizontalDirection(0);
                    return;
                }
                if(bp.y == sp.y - 1)
                {
                    s.changeDirection(0, 1);
                    fixDirection(s);
                }
                if(bp.y > sp.y)
                {
                    s.changeDirection(0, -1);
                    fixDirection(s);
                }
            }
            if(bp.x == sp.x && bp.y==sp.y+1 && s.getDirection().y>-1)
            {
                s.setVerticalDirection(b.getDirection().y);
            }

        }
    }

    public void resetHorizontals()
    {
        for(Square s : rain)
        {
            s.setHorizontalDirection(0);
        }
    }

    public void move()
    {
        for(Square s : rain)
        {
            s.move();
        }
    }

    void draw(Graphics2D g, int yMax, double xScale, double yScale,
             double tickPhase)
    {
        for (Square s : rain)
        {
            s.draw(g, xScale, yScale, yMax, tickPhase, true);
        }
    }

    public void erase(Graphics2D g)
    {
        for (Square s : rain)
        {
            s.erase(g);
        }
    }

    void setSquaresGray()
    {
        for(Square s : rain)
        {
            s.setColor(Color.GRAY);
        }
    }







}
