///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package mathtris;
//
//import java.io.ByteArrayInputStream;
//import java.io.ObjectInputStream;
//import java.net.DatagramPacket;
//import java.net.DatagramSocket;
//import java.net.SocketException;
//
///**
// *
// * @author pete
// */
//public class ServerPlayerModelReader implements Runnable
//{
//
//    ServerPlayerModel sp;
//
//    public ServerPlayerModelReader(ServerPlayerModel p)
//    {
//        this.sp = p;
//    }
//
//    public void run()
//    {
////        DatagramSocket socket = null;
////        try
////        {
////            socket = new DatagramSocket(sp.getDatagramPort());
////        } catch (SocketException ex)
////        {
////            C.print("Could not create datagram socket.");
////            ex.printStackTrace();
////            System.exit(1);
////        }
//        DatagramSocket socket;
//        try
//        {
//            socket = new DatagramSocket(sp.getDatagramPort());
//            while (true)
//            {
//                try
//                {
//                    //C.print("checking datagramPort: "+sp.getDatagramPort());
//
//                    byte[] buf = new byte[500000];
//                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
//                    socket.receive(packet);
//
//                    packet.getData();
//
//                    ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(packet.getData()));
//                    PacketWrapper tmp = (PacketWrapper) in.readObject();
//
//                    if (tmp.p != null)
//                    {
//                        sp.setPlayer(tmp.p);
//                        //C.print("found player : " + tmp.p.toString());
//                    }
//
//                } catch (Exception e)
//                {
//                    e.printStackTrace();
//                    System.exit(1);
//                }
//            }
//        } catch (SocketException ex)
//        {
//            C.print("Error in ServerPlayerModelReader");
//            ex.printStackTrace();
//
//        }
//    }
//
//}
