/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mathtris;

import java.io.Serializable;
import javax.swing.JTextArea;

/**
 *
 * @author pete
 */
public class Console extends JTextArea implements Serializable{

    public void out(String s)
    {
        append(s+"\n");
        //to make it auto scroll.  Don't know what this does, really.
        selectAll();
    }

}
