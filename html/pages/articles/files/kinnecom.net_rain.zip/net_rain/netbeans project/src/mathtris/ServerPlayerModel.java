/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 *
 * @author pete
 */
public class ServerPlayerModel
{

    private PlayerModel p;
    private SocketController TCPSocket;
    private int clientID;
    private InetAddress address;
    private int datagramPort;
    private String name;
    private Thread playerModelReaderThread;

    ServerPlayerModel(SocketController s, String name, int clientID, int port)
    {
        this.TCPSocket = s;
        this.clientID = clientID;
        this.datagramPort = port;
        this.name = name;
        address = TCPSocket.getAddress();
        playerModelReaderThread = new Thread(new ServerPlayerModelReader());
    }

    public int getDatagramPort()
    {
        return datagramPort;
    }


    public void setPlayer(PlayerModel p)
    {
        this.p = p;
    }

    public PlayerModel getPlayer()
    {
        return p;
    }

    public int getClientID()
    {
        return clientID;
    }

    public InetAddress getAddress()
    {
        return TCPSocket.getAddress();
    }

    public SocketController getTCPSocket()
    {
        return TCPSocket;
    }

    public void writeControlCode(final ControlCode out)
    {
        Thread t = new Thread(new Runnable()
        {

            public void run()
            {
                TCPSocket.writeControlCode(out);

            }

        });
        t.start();
    }

    public String getName()
    {
        return name;
    }

    public void startReaderThread()
    {
        playerModelReaderThread.start();
    }
    public void stopReaderThread()
    {
        playerModelReaderThread.interrupt();
    }
    private class ServerPlayerModelReader implements Runnable
{
    public void run()
    {
        DatagramSocket socket;
        try
        {
            socket = new DatagramSocket(datagramPort);
            while (!Thread.currentThread().isInterrupted())
            {
                try
                {
                    //C.print("checking datagramPort: "+sp.getDatagramPort());

                    byte[] buf = new byte[500000];
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    socket.receive(packet);

                    packet.getData();

                    ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(packet.getData()));
                    PacketWrapper tmp = (PacketWrapper) in.readObject();

                    if (tmp.p != null)
                    {
                        p = tmp.p;
                        //C.print("found player : " + tmp.p.toString());
                    }

                } catch (Exception e)
                {
                    e.printStackTrace();
                    System.exit(1);
                }
            }
        } catch (SocketException ex)
        {
            C.print("Error in ServerPlayerModelReader");
            ex.printStackTrace();

        }
    }

}
}
