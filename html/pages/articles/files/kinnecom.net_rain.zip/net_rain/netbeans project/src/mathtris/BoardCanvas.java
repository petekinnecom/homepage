/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;

/**
 *
 * @author pete
 */
public class BoardCanvas extends Canvas
{

    private BufferStrategy strategy;

    BoardCanvas()
    {
        this.setIgnoreRepaint(true);
    }

    public void init()
    {
        this.setVisible(true);
        this.setFocusable(false);
        createBufferStrategy(2);
        strategy = getBufferStrategy();
        try
        {
            Thread.sleep(30);
        } catch (Exception e)
        {
        }
        Graphics2D g = (Graphics2D) strategy.getDrawGraphics();
        //Graphics2D g = (Graphics2D) this.getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.dispose();
        //strategy.show();

    }

    //Synchronized to allow multiple threads to draw at the same time
    public synchronized void draw(PlayerModel p, double tickPhase)
    {
        Square.setControl(p.getControl());
        Graphics2D g = (Graphics2D) strategy.getDrawGraphics();
        //Graphics2D g = (Graphics2D) this.getGraphics();
        //g.setColor(new Color(0, 0, 0));
        //g.fillRect(0,0,getWidth(),getHeight());

        //scale the squares to fit what we want
        Dimension d = this.getSize();
        double xScale = ((double) d.width) / ((double) C.BOARD_WIDTH);
        double yScale = ((double) d.height) / ((double) C.BOARD_HEIGHT);

        if (tickPhase == 0.0)
        {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, getWidth(), getHeight());
        } else
        {
            p.getBoard().erase(g);
            p.getCloud().erase(g);

        }

        g.setColor(Color.GREEN);
        g.drawLine(0, (int) yScale * 4, this.getWidth(), (int) yScale * 4);

        int f = Math.min(p.getForecast() * 8, 255);
        g.setColor(new Color(f, f, f));
        g.fillRect(0, 0, this.getWidth(), (int) yScale * 4);

        p.getBoard().draw(g, getHeight(), xScale, yScale, tickPhase);

        p.getCloud().draw(g, getHeight(), xScale, yScale, tickPhase);


        g.dispose();
        strategy.show();
    }

    void drawClear()
    {
        Graphics2D g = (Graphics2D) this.getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0,0,getWidth(), getHeight());
        g.dispose();
    }

}
