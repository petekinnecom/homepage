/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mathtris;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 *
 * @author pete
 */
public class SocketController{

    private Socket s;
    private ObjectOutputStream objectOut;
    private ObjectInputStream objectIn;


    public SocketController(String ip, int port) throws IOException
    {
        s = new Socket(ip, port);
        objectOut = new ObjectOutputStream(s.getOutputStream());
        objectIn = new ObjectInputStream(s.getInputStream());
    }
    public SocketController(Socket s) throws IOException
    {
        this.s = s;
        objectOut = new ObjectOutputStream(s.getOutputStream());
        objectIn = new ObjectInputStream(s.getInputStream());
    }
    public synchronized ControlCode readControlCode()
    {
        try
        {
            return (ControlCode) objectIn.readObject();
        } catch (Exception e)
        {
            C.print("error readControlCode() : " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public void writeControlCode(ControlCode code)
    {

        try
        {
            objectOut.reset();
            objectOut.writeObject(code);
        } catch (Exception e)
        {
            C.print("error writeControlCode() : " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    public InetAddress getAddress()
    {
        return s.getInetAddress();
    }

}
