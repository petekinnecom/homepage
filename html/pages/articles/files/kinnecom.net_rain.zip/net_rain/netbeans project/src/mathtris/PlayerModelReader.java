///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package mathtris;
//
//import java.io.ObjectInputStream;
//
///**
// *
// * @author pete
// */
//public class PlayerModelReader implements Runnable
//{
//
//    ServerPlayerModel p;
//
//    public PlayerModelReader(ServerPlayerModel p)
//    {
//        this.p = p;
//    }
//
//    public void run()
//    {
//        while (true)
//        {
//            try
//            {
//                ObjectInputStream in = new ObjectInputStream(p.getSocket().getInputStream());
//                p.setPlayer((PlayerModel) in.readObject());
//            } catch (Exception ex)
//            {
//                ex.printStackTrace();
//            }
//        }
//    }
//
//}
