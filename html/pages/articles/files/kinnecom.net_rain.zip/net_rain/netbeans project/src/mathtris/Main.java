/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import javax.swing.JOptionPane;

/**
 *
 * @author pete
 */
public class Main
{

    public static void main(String[] args)
    {
        C.init();
        String[] options =
        {
            "Client", "Server"
        };
        int n = JOptionPane.showOptionDialog(null,
                "Choose wisely.",
                "",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[1]);

        //If a string was returned, say so.
        if (n == 1)
        {
            new ServerController();
        } else if(n==0)
        {
            new ClientController();
        }


    }

}
