/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.io.Serializable;
import java.util.Random;

/**
 *
 * @author pete
 */
public class Square implements Comparable<Square>, Serializable, Cloneable
{
    /* DEFAULTS */

    private static double EXPLODE_MAX = 4.0d;
    private static int NUMBER_VALUES;
    private static int BOMB_PERCENT;
    private static boolean[] underControl = {false, false, false, false, false, false, false, false};
    private static final Color[] colors =
    {
        Color.BLUE, Color.YELLOW, Color.GREEN, Color.RED, Color.ORANGE, Color.PINK, Color.GRAY
    };

    public static void init(int nv, int bp)
    {
        NUMBER_VALUES = nv;
        BOMB_PERCENT = bp;
    }


    /*
     * p is location
     * d is direction
     */
    private Point p;
    private Point d;
    private int value;
    private double explodeStage;
    private Color color;
    //used to find what to blow up
    private boolean infected;
    //flag to set as bomb
    private boolean bomb;

    // These hold previous values,
    // so that squares can be erased.
    private int rectX, rectY, rectW, rectH;
    private boolean redraw;

    public static void setControl(boolean[] c)
    {
        underControl = c;
    }


    public Square()
    {
        Random generator = new Random();
        value = generator.nextInt(NUMBER_VALUES);

        d = new Point(0, 0);

        color = colors[value];

        infected = false;
        int i = generator.nextInt(100);
        if (i < BOMB_PERCENT)
        {
            bomb = true;
            infected = true;
        } else
        {
            bomb = false;
        }
        rectX = rectY = rectW = rectH = 0;
        redraw = true;
    }

    @Override
    public Square clone()
    {
        return new Square(p,d,value,explodeStage, color, infected,
                bomb, rectX, rectY, rectW, rectH, redraw);
    }

    public Square(Point p, Point d, int value, double explodeStage, Color color, boolean infected,
            boolean bomb, int rectX, int rectY, int rectW, int rectH, boolean redraw)
    {
        this.p = new Point(p);
        this.d = new Point(d);
        this.value = value;
        this.explodeStage = explodeStage;
        this.color = color;
        this.infected = infected;
        this.bomb = bomb;
        this.rectX = rectX;
        this.rectY = rectY;
        this.rectW = rectW;
        this.rectH = rectH;
        this.redraw = redraw;
    }

    public Square(int i, int j)
    {
        this();
        p = new Point(i, j);

    }

    Square(int i, int j, int v)
    {
        this(i, j);
        value = v % 5;
    }

    Square(int i, int j, int v, int dx, int dy)
    {
        this(i, j, v);
        d = new Point(dx, dy);
    }

    //Create a square within the given dimension
    Square(Point d)
    {
        this(d.x, d.y);
    }

    public Point getPoint()
    {
        return p;
    }

    public int getValue()
    {
        return value;
    }

    public double getExplodeStage()
    {
        return explodeStage;
    }

    public boolean getControl()
    {
        return underControl[value];
    }

    public Point getNextPoint()
    {
        return new Point(p.x + d.x, p.y + d.y);
    }

    public void erase(Graphics g)
    {
        if(!redraw)
            return;
        g.setColor(Color.BLACK);
        g.fillRect(rectX, rectY, rectW, rectH);
    }

    //inCloud tells us whether it's on the board or not.  If it is, don't
    //highlight it when it's under control.
    public void draw(Graphics g, double scaleX, double scaleY, int yMax, double tickPhase, boolean inCloud)
    {
         //Full update every major tick
       if(tickPhase==0.0)
            redraw = true;
        
        if(!redraw)
            return;

        rectX = (int) (scaleX* (p.x + this.d.x * tickPhase));
        rectY = yMax - (int) (scaleY * (p.y + 1 + this.d.y * tickPhase));

        rectW = (int)(scaleX);
        rectH = (int)(scaleY);


        if (this.getControl() && inCloud)
        {
            g.setColor(Color.WHITE);
            if (this.bomb)
            {
                g.fillOval(rectX, rectY, rectW, rectH);
            } else
            {
                g.fillRect(rectX, rectY, rectW, rectH);
            }
        }

        if (explodeStage != 0.0d)
        {
            int R = color.getRed();
            int G = color.getGreen();
            int B = color.getBlue();
            double A =  255*(1.0d - ((explodeStage+tickPhase)/(EXPLODE_MAX+1d)));
            Color c = new Color(R,G,B,(int)A); //Red
            g.setColor(c);
        } else
        {
            g.setColor(color);
        }
       // Random r = new Random();
       // g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));
        if (this.bomb)
        {
            g.fillOval(rectX+3, rectY+3, rectW-6, rectH-6);
        } else
        {
            g.fillRect(rectX+3, rectY+3, rectW-6, rectH-6);
        }



        //g.drawString(""+value,(int) (d.width/2.5),(int)( d.height/1.5));
    }

    public boolean hasExploded()
    {
        if (explodeStage < EXPLODE_MAX)
        {
            return false;
        }
        return true;
    }

    public int compareTo(Square s)
    {
        Point sp = s.getPoint();
        if (this.p.x < sp.x)
        {
            return -1;
        } else if (this.p.x > sp.x)
        {
            return 1;
        } else
        {
            if (this.p.y < sp.y)
            {
                return -1;
            } else if (this.p.y > sp.y)
            {
                return 1;
            } else
            {
               // System.out.println("failure in Square.compareTo()!");
                return 0;
            }
        }
    }

    @Override
    public String toString()
    {
        return "(" + this.p.x + ", " + this.p.y + ")";
    }

    void explode()
    {
        explodeStage += 1.0d;
        redraw = true;
    }


    void setDirection(int i, int j)
    {
        d = new Point(i, j);
    }

    void setVerticalDirection(int j)
    {
        d.y = j;
    }

    void setHorizontalDirection(int i)
    {
        d.x = i;
    }

    public Point getDirection()
    {
        return d;
    }

    void move()
    {
        this.p.x = this.p.x + this.d.x;
        this.p.y = this.p.y + this.d.y;
        if(d.x!=0 || d.y!=0)
            redraw = true;
        else
            redraw = false;

    }

    public boolean isNeighbor(Square s, int v)
    {
        if (this.value == v && isNeighbor(s))
        {
            return true;
        }
        return false;
    }

    boolean isNeighbor(Square s)
    {
        Point sp = s.getPoint();
        //This square is itself
        if (this.p.x == sp.x && this.p.y == sp.y)
        {
            return false;
        }
        if (Math.abs(this.p.x - sp.x) <= 1 && Math.abs(this.p.y - sp.y) < 1)
        {
            return true;
        } else if (Math.abs(this.p.x - sp.x) < 1 && Math.abs(this.p.y - sp.y) <= 1)
        {
            return true;
        }
        return false;
    }

    public void infect()
    {
        infected = true;
    }

    public boolean getInfected()
    {
        return infected;
    }

    void addDirection(int i, int j)
    {
        this.d.x += i;
        this.d.y += j;
    }

    void changeDirection(int i, int j)
    {
        d.x += i;
        d.y += j;
    }
    public void setRedraw(boolean b)
    {
        redraw = b;
    }
    public void setColor(Color c)
    {
        color = c;
    }

}
