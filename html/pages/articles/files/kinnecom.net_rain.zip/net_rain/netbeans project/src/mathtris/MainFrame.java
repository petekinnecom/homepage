/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathtris;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

/**
 *
 * @author pete
 */
public class MainFrame extends JFrame
{

    private JLayeredPane layers;
    //private JScrollPane scroll;
    private GameView view;
    private LobbyPanel lobby;
    private ConnectionPanel connectionPanel;
    private JMenuItem connectionViewMenu;
    private JMenuItem lobbyViewMenu;
    private JMenuItem gameViewMenu;
    private JMenuItem singlePlayerMenu;
    private JMenu viewMenu;

    MainFrame()
    {
        JPopupMenu.setDefaultLightWeightPopupEnabled(false);
        setTitle("Game.");
        this.setSize(C.DEFAULT_WIDTH, C.DEFAULT_HEIGHT);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocation(500, 0);

        layers = new JLayeredPane();
        layers.setPreferredSize(this.getSize());

        this.add(layers, BorderLayout.CENTER);
    }

    public GameView init()
    {
        Rectangle bounds = new Rectangle(0, 0, this.getWidth(), this.getHeight()-40);
        //Set up game view
        view = new GameView();
        view.setBounds(bounds);
        layers.add(view, new Integer(1));


        //set up lobby
        lobby = new LobbyPanel();
        lobby.setBounds(bounds);
        view.setSize(this.getSize());
        layers.add(lobby, new Integer(0));

        //set up ConnectionPanel
        connectionPanel = new ConnectionPanel();
        connectionPanel.setBounds(bounds);
        layers.add(connectionPanel);

        //Set up Menu
        JMenuBar menuBar = new JMenuBar();


        viewMenu = new JMenu("Menu of possibilities");
        menuBar.add(viewMenu);
        connectionViewMenu = viewMenu.add("Connect to Server");
        singlePlayerMenu = viewMenu.add("Single Player game");
        lobbyViewMenu = viewMenu.add("View Lobby");
        gameViewMenu = viewMenu.add("View Game");
        this.setJMenuBar(menuBar);



        this.setVisible(true);
        layers.setVisible(true);
        layers.setBorder(BorderFactory.createTitledBorder("Layered Pane."));
        view.setVisible(true);

        showLobby();
        view.init();
        this.pack();
        return view;
    }

    public void rebound()
    {
        Dimension d = getRootPane().getSize();
        d.height = d.height;
        layers.setSize(d);
        view.setSize(d.width,d.height-20);
        lobby.setSize(d);
    }

    public void setListeners(final ClientController controller)
    {
        this.addComponentListener(new ComponentListener(){

            public void componentResized(ComponentEvent e)
            {
                rebound();
            }

            public void componentMoved(ComponentEvent e)
            {
            }

            public void componentShown(ComponentEvent e)
            {
            }

            public void componentHidden(ComponentEvent e)
            {
            }
        });
        connectionPanel.getButton().addActionListener(new java.awt.event.ActionListener()
        {

            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                controller.connectToServer(connectionPanel.getIPString(), connectionPanel.getNameString());
            }

        });

        connectionViewMenu.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent evt)
            {
                controller.connectDialog();
            }

        });

        lobbyViewMenu.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent evt)
            {
                showLobby();
            }

        });

        gameViewMenu.addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent evt)
            {
                showGameView();
            }

        });

        singlePlayerMenu.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent evt)
            {
                controller.startSinglePlayer();
            }
        });

        lobby.getChatTextField().addActionListener(new ActionListener()
        {

            public void actionPerformed(ActionEvent evt)
            {
                controller.sendChat(lobby.getChatTextField().getText());
                lobby.getChatTextField().setText(null);
            }

        });



    }

    public void setListeners(final ServerController controller)
    {
        lobby.getChatTextField().addActionListener(new java.awt.event.ActionListener()
        {

            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                String s = lobby.getChatTextField().getText();
                controller.processInput(s);

                lobby.getChatTextField().setText("");
            }

        });
    }

    private void resetLayers()
    {
        layers.setLayer(view, 0);
        layers.setLayer(lobby, 0);
        layers.setLayer(connectionPanel, 0);
    }

    public void showGameView()
    {
        resetLayers();
        //rebound();
        layers.setLayer(view, 1);
        view.drawClear();
        view.grabFocus();

    }

    public void showLobby()
    {
        resetLayers();
        layers.setLayer(lobby, 1);
    }

    public void showConnectionPanel()
    {
        resetLayers();
        layers.setLayer(connectionPanel, 1);
    }

}
