///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//
//package mathtris;
//
//import java.net.ServerSocket;
//import java.net.Socket;
//import java.util.ArrayList;
//
///**
// *
// * @author pete
// */
//public class Server {
//
//    /**
//     * @param args the command line arguments
//     */
//
//
//    Server() {
//
//        try
//        {
//            ServerSocket server = new ServerSocket(8189);
//            ArrayList<ServerPlayerModel> serverPlayers = new ArrayList<ServerPlayerModel>();
//            for (int i = 0; i < 1; i++)
//            {
//                int port = 6694+2*i;
//                C.print("Waiting for players");
//                Socket s = server.accept();
//                SocketController TCPSocket = new SocketController(s);
//                ControlCode in;
//                ControlCode out = new ControlCode();
//
//                C.print("writing clientID : "+i);
//                out.code = i;
//                TCPSocket.writeControlCode(out);
//
//                C.print("writing port : "+port);
//                out.code = port;
//                TCPSocket.writeControlCode(out);
//
//                C.print("Reading user name.");
//                in = TCPSocket.readControlCode();
//                String name = in.s;
//
//
//                C.print("Read user name: "+name);
//                TCPSocket.writeControlCode(in);
//
//                serverPlayers.add( new ServerPlayerModel(TCPSocket,name, i, port));
//
//            }
//            try
//            {
//                C.print("All players here.  Starting game.");
//                new ServerController(serverPlayers);
//            }
//            catch(Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//        }
//
//    }
//
//}
