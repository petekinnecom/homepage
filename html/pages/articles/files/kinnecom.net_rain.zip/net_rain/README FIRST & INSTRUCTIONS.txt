How to play:

BUGS: 

Occaisionally, when a game is started, the game window will not be drawn and updated.  Simply resizing the window will fix this.  If this does not fix the issue, please use the alternate jar provided: 'Net_Rain (no resize).jar'

GAME:

Like Tetris, bricks fall.  Don't let them stack up above the threshhold line.  A round brick will cause a chain reaction, destroying all bricks of the same color to which it's connected.

CONTROLS:

Take control of bricks by pressing their "control key".  Use the arrow keys to move them.  E.G. Hold "F" and press the right arrow, to move all red bricks to the right.

Red (Fire)    : "F" key
Blue (Water)  : "W" key
Yellow (Sand) : "S" key
Green (Grass) : "G" key 

SINGLE PLAYER:

When starting, select 'Client'.  Then choose 'Single Player Game' from the Menu of Possibilities.

MULTIPLAYER:

Multiplayer only works on a local network.  In theory, the code should work across the internet, but I was unable to make sense of various firewall and port-forwarding issues.

To test multiplayer locally, start the program and select 'Server'.  Now, begin another instance of the program and select 'Client'.  From the menu select 'Connect to Server'.  Enter a name and use localhost as the server.  Repeat this process up to four times.

To begin the multiplayer game, go to the SERVER instance (they all look the same at this point, so be careful).  Type 'start' into the chat line.  It should say "starting game.  Broadcasting start code."  Then the madness begins.
