<?

function set_user_session_data($name)
{

	$userinfo = db_get_user_info($name);
	$_SESSION['user_name'] = $userinfo['username'];
	$_SESSION['user_id'] = $userinfo['id'];
	$_SESSION['user_points'] = $userinfo['points'];
	$_SESSION['user_email'] = $userinfo['email'];
	$_SESSION['avatar'] = $userinfo['avatar'];
	$_SESSION['points_in_holding'] = $userinfo['points_in_holding'];
	$_SESSION['user_title'] = $userinfo['title'];
	$_SESSION['active_this_month']=$userinfo['active_this_month'];
	
	//added to track user stats:
	db_init_user_stats();
}

/**
 * checkLogin - Checks if the user has already previously
 * logged in, and a session with the user has already been
 * established. Also checks to see if user has been remembered.
 * If so, the database is queried to make sure of the user's 
 * authenticity. Returns true if the user has logged in.
 */
 
 
function checkLogin()
{
   /* Check if user has been remembered */
   if($_SESSION['user_name'])
		{
			return true;
		}
	else if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookpass']))
		{
			// Confirm that username and password are valid 
			if(db_check_user_password($_COOKIE['cookname'], $_COOKIE['cookpass']) != 'success')
				{
					//Variables are incorrect, user not logged in 
					unset($_SESSION['user_name']);
					unset($_SESSION['password']);
					return false;
				}
		  
			//success, the cookie tests positive.
			set_user_session_data($_COOKIE['cookname']);
			log_action('000','cookied',$msg);
			return true;
		}

   /* User not logged in */
   else
		{
			if(!$_SESSION['logged'])
				{
					$ref = $_SERVER['HTTP_REFERER'];
					$msg='';
					if($ref)
						$msg = "referred by " . $ref;
					log_action('000','browsed',$msg);
					$_SESSION['logged']='true';
				}
		  
			return false;
		}
}

/**
 * Checks to see if the user has submitted his
 * username and password through the login form,
 * if so, checks authenticity in database and
 * creates session.
 */
if($_GET['logout'])
	{
	   /* Kill session variables */

	   unset($_SESSION['user_name']);
	   unset($_SESSION['password']);
	   unset($_SESSION['user_id']);
	   unset($_SESSION['user_points']);
	   unset($_SESSION['user_email']);
	   //set the cookie to expire an hour ago, so it is deleted.
	   setcookie("cookname", $_SESSION['user_name'], time()-3600, "/");
	   setcookie("cookpass", $_SESSION['password'], time()-3600, "/");
	   $_SESSION = array(); // reset session array
	   session_destroy();   // destroy session.
	}
	
if(isset($_POST['sublogin']))
{
	/* Check that all fields were typed in */
	if(!$_POST['user'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url={$_SERVER['PHP_SELF']}?fail=nm\">");
		}
	if(!$_POST['pass'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url={$_SERVER['PHP_SELF']}?fail=pss&usrnm={$_POST['username']}\">");
		}

	/* Spruce up username, check length */
	$_POST['user'] = trim($_POST['user']);
	if(strlen($_POST['user']) > 30)
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=login.php?fail=3\">");
		}

	/* Checks that username is in database and password is correct */
	$md5pass = md5($_POST['pass']);
	$result = db_check_user_password($_POST['user'], $md5pass);

	/* Check error codes */
	if($result == 'username_failure')
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url={$_SERVER['PHP_SELF']}?fail=nm\">");
		}
	else if($result == 'password_failure')
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url={$_SERVER['PHP_SELF']}?fail=pss&usrnm={$_POST['username']}\">");
		}


	/* Username and password correct, register session variables */
	$_POST['user'] = stripslashes($_POST['user']);
	$_SESSION['password'] = $md5pass;
	set_user_session_data($_POST['user']);


	/**
	* This is the cool part: the user has requested that we remember that
	* he's logged in, so we set two cookies. One to hold his username,
	* and one to hold his md5 encrypted password. We set them both to
	* expire in 100 days. Now, next time he comes to our site, we will
	* log him in automatically.
	*/

	if(isset($_POST['remember']))
		{
			setcookie("cookname", $_SESSION['user_name'], time()+60*60*24*100, "/");
			setcookie("cookpass", $_SESSION['password'], time()+60*60*24*100, "/");
		}

	/* Quick self-redirect to avoid resending data on refresh */
	//echo "<meta http-equiv=\"Refresh\" content=\"0;url=/\">";
	return;
}
if(!$_SESSION['user_name'])
	checkLogin();
?>