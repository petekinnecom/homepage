<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_output.php");
/*************************************/

output_header();

?>

<div id="container">
<center>
<div id="center">
<center>
<h1>Login</h1>
</center>
<form action="" method="post">
<table align="center" border="0" cellspacing="0" cellpadding="3">
<tr>
<td>
<?php
 if($_GET['fail']==1 || $_GET['fail']==3 || $_GET['fail']==4)
     {
      echo '<b class="orange">Username:</b>';
     }
   else
     {
      echo "Username:";
     }
?>
</td>


<td><input type="text" name="user" maxlength="30"></td></tr>
<tr>
<td>
<?php
   if($_GET['fail']==2 || $_GET['fail']==5)
     {
      echo '<b class="orange">Password:</b>';
     }
   else
     {
      echo "Password:";
     }
?>
</td>

<td><input type="password" name="pass" maxlength="30"></td></tr>
<tr><td colspan="2" align="left"><input type="checkbox" name="remember">
<font size="2">Remember me next time</td></tr>
<tr><td colspan="2" align="right"><input type="submit" name="sublogin" value="Login"></td></tr>
</table>
</form>
<p>
<font color="#FF6633">
<?php
  if($_GET['fail']==1)
    {
     echo "Hello, my name is Pete.  You are?";
    }
  if($_GET['fail']==2)
    {
     echo "It's okay.  Your password is safe with me.";
    }
  if($_GET['fail']==3)
    {
     echo "Usernames can't be more than 30 characters long.";
    }
  if($_GET['fail']==4)
    {
     echo "Hmmm.  That user name doesn't seem to be on file.";
    }
   if($_GET['fail']==5)
    {
     echo "That didn't work.  This time enter the <i>real</i> password.";
    }
   if($_GET['newuser'])
    {
	 echo "Thanks for registering.  You can now log-in.";
	 }
?>
</font>
</div>
</center>
</div>
</html>
<? 

?>