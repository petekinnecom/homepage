<?php
include('f_log.php');
include('f_mail.php');
<?php
define( 'SAFE_HTML_VERSION', 'safe_html.php/0.6' );

/* safe_html.php
   Copyright 2003 by Chris Snyder (csnyder@chxo.com)
   Free to use and redistribute, but see License and Disclaimer below

     - Huge thanks to James Wetterau for initial testing and feedback!
     - Originally posted at http://lists.nyphp.org/pipermail/talk/2003-May/003832.html

Version History:
2007-01-29 - 0.6 -- added additional check after tag stripping, thanks to Görg Pflug for exploit!
                             -- finally linked to standard tests page in demo
2005-09-05 - 0.5 -- upgrade to handle cases at http://ha.ckers.org/xss.html
2005-04-24 - 0.4 -- added check for encoded ascii entities
2003-05-31 - 0.3 -- initial public release

License and Disclaimer:
Copyright 2003 Chris Snyder. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this 
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this 
   list of conditions and the following disclaimer in the documentation and/or other 
   materials provided with the distribution.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;  LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  

*/

if ( !empty( $_GET['source'] ) && $_GET['source']=='safe_html' ) {
  header('Content-Type: text/plain');
  exit( file_get_contents( __FILE__ ) );
}

// first, an HTML attribute stripping function used by safe_html()
//   after stripping attributes, this function does a second pass
//   to ensure that the stripping operation didn't create an attack
//   vector.
function strip_attributes ($html, $attrs) {
  if (!is_array($attrs)) {
    $array= array( "$attrs" );
    unset($attrs);
    $attrs= $array;
  }
  
  foreach ($attrs AS $attribute) {
    // once for ", once for ', s makes the dot match linebreaks, too.
    $search[]= "/".$attribute.'\s*=\s*".+"/Uis';
    $search[]= "/".$attribute."\s*=\s*'.+'/Uis";
    // and once more for unquoted attributes
    $search[]= "/".$attribute."\s*=\s*\S+/i";
  }
  $html= preg_replace($search, "", $html);

  // do another pass and strip_tags() if matches are still found
  foreach ($search AS $pattern) {
    if (preg_match($pattern, $html)) {
      $html= strip_tags($html);
      break;
    }
  }

  return $html;
}

function js_and_entity_check( $html ) {
  // anything with ="javascript: is right out -- strip all tags if found
  $pattern= "/=[\S\s]*s\s*c\s*r\s*i\s*p\s*t\s*:\s*\S+/Ui";
  if (preg_match($pattern, $html)) {
    return TRUE;
  }
  
  // anything with encoded entites inside of tags is out, too
  $pattern= "/<[\S\s]*&#[x0-9]*[\S\s]*>/Ui";
  if (preg_match($pattern, $html)) {
    return TRUE;
  }
  
  return FALSE;
}

// the safe_html() function
//   note, there is a special format for $allowedtags, see ~line 90
function safe_html ($html, $allowedtags="") {
  
  // check for obvious oh-noes
  if ( js_and_entity_check( $html ) ) {
    $html= strip_tags($html);
    return $html;
  }
  
  // setup -- $allowedtags is an array of $tag=>$closeit pairs, 
  //   where $tag is an HTML tag to allow and $closeit is 1 if the tag 
  //   requires a matching, closing tag
  if ($allowedtags=="") {
    $allowedtags= array ( "p"=>1, "br"=>0, "a"=>1, "img"=>0, 
                        "li"=>1, "ol"=>1, "ul"=>1, 
                        "b"=>1, "i"=>1, "em"=>1, "strong"=>1, 
                        "del"=>1, "ins"=>1, "u"=>1, "code"=>1, "pre"=>1, 
                        "blockquote"=>1, "hr"=>0
                        );
  }
  elseif (!is_array($allowedtags)) {
    $array= array( "$allowedtags" );
  }

  // there's some debate about this.. is strip_tags() better than rolling your own regex?
  // note: a bug in PHP 4.3.1 caused improper handling of ! in tag attributes when using strip_tags()
  $stripallowed= "";
  foreach ($allowedtags AS $tag=>$closeit) {
    $stripallowed.= "<$tag>";
  }

  //print "Stripallowed: $stripallowed -- ".print_r($allowedtags,1);
  $html= strip_tags($html, $stripallowed);

  // also, lets get rid of some pesky attributes that may be set on the remaining tags...
  // this should be changed to keep_attributes($htmlm $goodattrs), or perhaps even better keep_attributes
  //  should be run first. then strip_attributes, if it finds any of those, should cause safe_html to strip all tags.
  $badattrs= array("on\w+", "style", "fs\w+", "seek\w+");
  $html= strip_attributes($html, $badattrs);

  // close html tags if necessary -- note that this WON'T be graceful formatting-wise, it just has to fix any maliciousness
  foreach ($allowedtags AS $tag=>$closeit) {
    if (!$closeit) continue;
    $patternopen= "/<$tag\b[^>]*>/Ui";
    $patternclose= "/<\/$tag\b[^>]*>/Ui";
    $totalopen= preg_match_all ( $patternopen, $html, $matches );
    $totalclose= preg_match_all ( $patternclose, $html, $matches2 );
    if ($totalopen>$totalclose) {
      $html.= str_repeat("</$tag>", ($totalopen - $totalclose));
    }
  }
  
  // check (again!) for obvious oh-noes that might have been caused by tag stipping
  if ( js_and_entity_check( $html ) ) {
    $html= strip_tags($html)."<!--xss stripped after processing-->";
    return $html;
  }

  // close any open <!--'s and identify version just in case
  $html.= '<!-- '.SAFE_HTML_VERSION.' -->';

  return $html;
}

// End of file
function percent($num, $sum, $dec=0){
   if($sum==0) return 0;
   return round($num*100/$sum+0.00000001,$dec);
}
function month()
{
	return date('m').'.'.date('Y');
}
function process_tags($content)
{
   $content=trim($content);
   $content = strip_tags($content,'<i><b><a><br><blockquote><center><ul><li><ol><img>');
   
   $allowed = array('i','b','blockquote','ul','li','center','ol','img');
   $trash = strtolower($content);
   foreach($allowed as $tag)
	   {
		   $i = substr_count($trash,'<'.$tag);
		   $j = substr_count($trash,'</'.$tag);

		   //die( 'start debug' .$test . $tag . $i . $j);
		   while($i>$j)
		   {$content=$content . '</' . $tag . '>';$j++;}
	   }
   $content = nl2br ($content);
   
   
   return $content;
}
function db_update_user_profile($birthday, $sex, $location, $website, $description)
{
	$username = $_SESSION['user_name'];
	$description = process_tags($description);
	
	$query = "UPDATE users SET birthday = '{$birthday}', sex='$sex', location='$location', website='$website', description='{$description}' WHERE username = '$username'";
	if(!mysql_query($query)){die('error db_update_user_profile.  Please report this to mctk@koutouki.org: <br/>'.mysql_error());}
	
	$msg = "Changed profile";
	log_action('000','profile',$msg);
	return true;


}
function db_change_user_password($username,$password)
{
	//The pass is already encrypted
	$query  = "UPDATE users SET password='{$password}' WHERE username = '{$username}'";
   
	if(!mysql_query($query)){die('error db_change_user_password.');}
	
	$msg = "Changed password";
	log_action('000','settings', $msg);
	return true;
	
}
function db_set_user_avatar($filename,$username)
{
	$query  = "UPDATE users SET avatar='{$filename}' WHERE username = '{$username}'";
   
	if(!mysql_query($query)){die('error db_set_user_avatar.');}
	
	$msg = "Changed avatar";
	log_action('000','settings', $msg);
	return true;
}

function db_check_user_password($username, $password)
{
	// This function requires the password to have already been md5'd.  This is because the encrypted pass is stored in the cookie.
	
	/* Add slashes if necessary (for query) */
	if(!get_magic_quotes_gpc())
		{
			$username = addslashes($username);
		}
		
	$query = "SELECT password FROM users WHERE username = '$username'";
	$result = mysql_query($query);
	
	if(!$result || (mysql_numrows($result) < 1))
		{
			return 'username_failure'; //Indicates username failure
		}
	
	$dbarray = mysql_fetch_array($result);
	$db_password = stripslashes($dbarray['password']);
	

	
	/* Retrieve password from result, strip slashes */
	$password = stripslashes($password);

	/* Validate that password is correct */
	if($password == $db_password)
		{
			$msg = $username;
			log_action('000','log-in',$msg);
			return 'success'; //Success! Username and password confirmed
		}
	else
		{
			return 'password_failure'; //Indicates password failure
		}
}
function db_get_user_list($orderby,$asc_desc='DESC')
{	

	if($_GET['month']=='all')
		{
			$query =   "SELECT username,
						points,
						points_capital,
						votes_cast,
						votes_for,
						votes_for_percentage,
						points_won,
						points_wagered,
						earnings_percentage,
						num_debates_won,
						num_arguments,
						num_comments,				
						email 
						FROM users ORDER BY $orderby $asc_desc";
		}
	else
		{
			if(!$_GET['month'])
				$month = month();
			else
				$month = $_GET['month'];
				
			$query ="SELECT username,
					points,
					votes_for,
					votes_for_percentage,
					points_won,
					points_wagered,
					earnings_percentage,
					num_debates_won,
					num_arguments,
					num_comments				
					FROM user_stats WHERE month='$month' ORDER BY $orderby $asc_desc";
		}
	$result = mysql_query($query);
	if(!$result)
		{
			die("You shouldn't be here.  Let's see what mySQL has to tell you: ".$query."<br/>".mysql_error());
		}
	$i=0;
	while($stuff = mysql_fetch_array($result))
		{
			//this keeps dummy names from showing up
			if($stuff['email']!='private_user')
				{
					$data[$i] = $stuff;
					$i++;
				}
		}
	return $data;
}

function db_get_user_place($username, $luminosity)
{	
	$query = "SELECT id FROM users WHERE points_won-points_wagered >='$luminosity' AND email!='private_user'";
	$result = mysql_query($query);
	return mysql_numrows($result) + 1;
}
function db_get_user_stats($username)
{
	$data = db_get_user_info($username);
	$data['point_rank'] = db_get_user_place($username,$data['luminosity']);
	
	//Query to find biggest victory, biggest loss.
	
	$data['biggest_wager_won'] = 0;
	$data['biggest_wager_lost'] = 0;
	$query = "SELECT wager,id,victor,owner,challenger FROM bets WHERE 
	(owner='$username' OR challenger='$username') AND status='resolved'";
	$result = mysql_query($query);
	if(!$result)
		{
			die(mysql_error());
		}
	while($stuff = mysql_fetch_array($result))
		{
			if(($stuff['owner']==$username && $stuff['victor']=='owner')
				|| ($stuff['challenger']==$username && $stuff['victor']=='challenger'))
				{
					//This is a bet this user has won
					if($stuff['wager']>$data['biggest_wager_won'])
						{
							$data['biggest_wager_won'] = $stuff['wager'];
							$data['biggest_wager_won_id'] = $stuff['id'];
						}
				}
			else
				{
					//the user has lost this bet
					if($stuff['wager']>$data['biggest_wager_lost'])
						{
							$data['biggest_wager_lost'] = $stuff['wager'];
							$data['biggest_wager_lost_id'] = $stuff['id'];
						}
				}

		}

	$data['adj_id'] = $data['id'] - 75;
	
	return $data;
	
}
function db_get_user_info($username)
{
  
	//return an array of all user info except the password.
	 
	$query  = "SELECT 
	id,
	username,
	points,
	points_capital,
	active_this_month,
	votes_cast,
	votes_for,
	votes_against,
	votes_for_percentage,
	points_wagered,
	points_won,
	earnings_percentage,
	email,
	email_options,
	avatar,
	birthday,
	sex,
	location,
	website,
	description,
	num_debates,
	num_debates_won,
	debate_win_percentage,
	num_arguments,
	num_comments,
	title,
	time_registered
	FROM users WHERE username = '$username'";
     $result = mysql_query($query);
	 if(!$result || (mysql_numrows($result) < 1))
	 {
      return false;
	 }
   
	$data = (mysql_fetch_array($result));
	
	//split birthday
	if($data['birthday'])
		{
			$split = explode("-", $data['birthday']);
			$data['birth_year'] = $split[0];
			$data['birth_month'] = $split[1];
			$data['birth_day'] = $split[2];
			
			//thanks mjlintz from code_snippets
		    $year_diff  = date("Y") - $data['birth_year'];
		    $month_diff = date("m") - $data['birth_month'];
		    $day_diff   = date("d") - $data['birth_day'];
		    if ($month_diff < 0)
		      $year_diff--;
		    else if($month_diff==0)
				if($day_diff<0)
					$year_diff--;
					
			/*this is good stuff 
			$data['age'] = $year_diff . " years " . $month_diff . " months and " . $day_diff . " days";
			*/
			$data ['age'] = $year_diff;
		}
	else
		{
			$data['age'] = '?';
		}
	
	$data['adj_id'] = $data['id'] - 75;
	if($data['time_registered'])
		{$data['member_since'] = date("F j, Y",$data['time_registered']);}
	else
		{$data['member_since'] = 'the beginning';}
	
	$data['points_in_holding'] = $data['points_capital'] - $data['points'];
	
	//for overall site ranking, since points are now reset monthly
	$data['luminosity'] = $data['points_won'] - $data['points_wagered'];
	
	return $data;
}
   
function db_username_availability($username)
{

   //returns true if available, false if not.  Don't know what magic_quotes is doing, but seems to work.
   
   if(!get_magic_quotes_gpc()){$username = addslashes($username);}
   $query = "select username from users where username = '$username'";
   $result = mysql_query($query);
   return (mysql_numrows($result) > 0);
}
function db_add_user($username, $password, $email)
{

    //Inserts the given info into the database
	$ip = $_SERVER['REMOTE_ADDR'];
	$time = time();
	$query = "INSERT INTO users (username, password, points,points_capital, email, registered_ip, time_registered) VALUES ( '$username', '$password','1000','1000','$email','$ip','$time')";
	
	$msg = $username;
	log_action('000','register', $msg);
	return mysql_query($query);

			

}    
function db_get_search_results()
{
	$i = 0;
	$query = "SELECT id FROM bets WHERE MATCH (claim,title) AGAINST('{$_GET['query']}')";
	$result = mysql_query($query);
	if(!$result)
		die(mysql_error());
		
    while($stuff = mysql_fetch_array($result))
		{
			$data[$i] = $stuff['id'];
			$i++;
		}
	$query = "SELECT bet_id FROM arguments WHERE MATCH (content) AGAINST('{$_POST['query']}')";
	$result = mysql_query($query);
	if(!$result)
		die(mysql_error());
		
    while($stuff = mysql_fetch_array($result))
		{
			$data[$i] = $stuff['bet_id'];
			$i++;
		}
	$query = "SELECT bet_id FROM comments WHERE MATCH (content) AGAINST('{$_POST['query']}')";
	$result = mysql_query($query);
	if(!$result)
		die(mysql_error());
		
    while($stuff = mysql_fetch_array($result))
		{
			$data[$i] = $stuff['bet_id'];
			$i++;
		}
	return $data;
}
function db_add_bet($owner, $wager, $title, $claim, $type, $anonymous, $show_vote_counts, $num_arguments_allowed, $creator, $user_to_challenge)
{
   if(!$_SESSION['user_name'])
		{
			die("I'm afraid I can't do that, Dave.  You must be logged-in.  If you feel that you have received this mesage in error, then you please report this to the CIA, you terrorist.");
		}
   //add this info to database. 
   
	$title = addslashes($title);
    $claim = addslashes($claim);
   
	$title = str_replace('<','&lt;',$title);
    $title = str_replace('>','&gt;',$title);
	
	$challenger='';
	$claim = process_tags($claim);
	if($type=='proposal'){$action = 'proposal'; $wager=0; $owner='';}
	else if($type=='challenge'){$action='pending'; $creator='';}
	else if($type=='personal_challenge'){$action='personal_challenge'; $challenger=$user_to_challenge;$creator='';}
    else{die('error db_add_bet() line 137: bet has no type!');}
    $time = time();
   

	$query = "INSERT INTO bets (owner, wager, title, claim, challenger, action, anonymous, show_vote_counts, num_arguments_allowed, creator, timestamp)
			VALUES ('{$owner}', '{$wager}','{$title}','{$claim}','{$challenger}','{$action}','$anonymous','$show_vote_counts','$num_arguments_allowed','{$creator}', '{$time}')";
    if(!mysql_query($query)){die('error db_add_bet.  Could not insert bet.');}
   

	$query  = "UPDATE users SET points=points-'$wager' WHERE username = '{$owner}'";
	if(!mysql_query($query)){die('error db_add_bet.  Could not update user points.');}
	
	$_SESSION['user_points'] = $_SESSION['user_points']-$wager;
	
	$msg = $_SESSION['user_name']." placed bet: \"".$title."\"";
	log_action('000','bet', $msg);
	
	if($type=='personal_challenge')
		{
			$query = "SELECT id FROM bets WHERE title='$title'";
			$result = mysql_query($query);
			$data = mysql_fetch_array($result);
			$bet = db_get_bet($data['id']);
			send_mail($bet['challenger'],'personal_challenge',$bet);
		}
		
	//keep all stats current
	set_user_session_data($name);
	return true;
}


function db_get_bet_list($type)
{
/* Using the GET variables, construct a mysql query to find wanted bets.
     Creating the $query gets failry convoluted.  To make construction simpler
     always use AND and if an option is absent, search for NOT NULL.
	 
    I don't know much about SQL.  Maybe this is okay, maybe it's not.  If 
    you're reading this, and you're not me, you probably know.  Why are you reading
   this anyways?  Who are you and how did you find me? 	
	
*/
	/*added to allow specification of multiple status filters separated by commas */
	if($type=='dispute')
		{
			$query = 'SELECT id FROM bets WHERE status=\'dispute\' ORDER BY timestamp ASC LIMIT 0,10';
		}
	else if($type=='open')
		{
			$query = 'SELECT id FROM bets WHERE status=\'open\' ORDER BY timestamp DESC LIMIT 0,10';
		}
	else if($type=='resolved')
		{
			$query = 'SELECT id FROM bets WHERE status=\'resolved\' ORDER BY timestamp DESC LIMIT 0,10';
		}
	else if($type=='announcement')
		{
			$query = "SELECT id FROM bets WHERE status='announcement' ORDER BY timestamp DESC LIMIT 0,10";
		}
	else
		{
			$status_filters = explode(",",$_GET['filter_status']); 
			
			$query  = "SELECT id FROM bets WHERE ";

			if($_GET['filter_user'])
				{
					$query = $query . "(owner='{$_GET['filter_user']}' OR challenger='{$_GET['filter_user']}') AND (anonymous='no' OR status='resolved') AND ";
				}
			if($_GET['filter_action'])
				{
					$query = $query . "action='{$_GET['filter_action']}' AND ";
				}
			if($_GET['filter_status'])
				{	
					//added to support announcements.
					$query = $query . "(status!='announcement' AND (";
					foreach($status_filters as $filter_status)
						{
							$query = $query . "status='$filter_status' OR ";
						}
					$query = $query . ")) ";
					$query = str_replace('OR )',')',$query);
				}	
			else
				{
					if($_GET['sort']=='last_updated')
						$query = $query . " status!=''";
					else
						$query = $query . "(status!='announcement' AND status!='') ";
				}

		    
			$query = $query . "ORDER BY ";
			
			if($_GET['sort'])
			   {
			    $query = $query . $_GET['sort'];
				}
			else
			  {
			   $query = $query . "id";
			  }
		 
		    if ($_GET['order'])
			  {
			   $query = $query . " " . $_GET['order'];
			   }
			else
			  {
			   $query = $query . " DESC ";
			  }

			//Added to support General Announcements page.
			if($_GET['announcement'])
				{
					$query = "SELECT id FROM bets WHERE status='announcement' ORDER BY timestamp DESC ";
				}
			
			/* 
			Added LIMIT syntax
			We'll show 10 results per page.
			There will currently be only "next & previous" links.
			*/
			if($_GET['page']>=1)
				{
					$start = $_GET['page']*10;
					$end = $start + 10;
					$query = $query . " LIMIT ".$start.",".$end;
				}
			else
				{
					$query = $query . " LIMIT 0,10";
				}
			
	}//close if(type = 'get')
     $result = mysql_query($query);

 if(!$result)
       {
        die('Database error f_database in function db_get_bet_list(), $result is null.<br/>'.$query);
       }

	
	//Extract our rows.  Don't know if this is normal.  See message above.
     $i=0;
     While($row = mysql_fetch_array($result))
           {
             $bet_list[$i] = $row['id'];
             $i++;

           }

return $bet_list;

}
function db_close_bet($bet_id)
{
	//mark the bet as closed, this should be easy.  Interface changes must be made in f_output. 
	//f_add_argument will need to verify that the bet is not closed
	$query = "UPDATE bets SET action='closed' WHERE id='$bet_id'";
	if(!mysql_query($query))
		{
			die('db_close_bet:<br>' . mysql_error());
		}
	

}
function db_expire_bet($bet)
{
  
	//To expire a bet, we have to check cases.  Is it a dispute?  who won?  If not, just expired.
	if($bet['status']=='open')
		{
			//if it's open, simply expire it.
			$query = "UPDATE bets SET status='expired' WHERE id='{$bet['id']}'";
			if(!mysql_query($query))
				{
					die('db_expire_bet:<br>' . mysql_error());
				}
			//(whoah there, champ.  We better give the poster his/her lms back, eh?)
			if($bet['owner'])
				{
					$query = "UPDATE users SET points=points+'{$bet['wager']}' WHERE username='{$bet['owner']}'";
					if(!mysql_query($query))
						{
							die('db_expire_bet:<br>' . mysql_error());
						}
				}
			return true;
		}
	else if($bet['status']=='dispute')
		{

			//figure out who won.  And make the appropriate query.
			if($bet['num_votes_owner']>$bet['num_votes_challenger'])
				{
					$victor = 'owner';
					$victor_name = $bet['owner'];
					$query = "UPDATE bets SET 
							status='resolved', 
							victor='$victor', 
							action='voted'
							WHERE id='{$bet['id']}'";
					
					send_mail($bet['owner'],'win',$bet);
					send_mail($bet['challenger'],'lose',$bet);
				}
			else if($bet['num_votes_owner']<$bet['num_votes_challenger'])
				{
					$victor = 'challenger';
					$victor_name = $bet['challenger'];

					$query = "UPDATE bets SET status='resolved', victor='$victor', action='voted' WHERE id='{$bet['id']}'";
					send_mail($bet['challenger'],'win',$bet);
					send_mail($bet['owner'],'lose',$bet);
				}
			else
				{
					//We have a tie on our hands, boys.
					/*
					$victor = 'tie';
					$owner_wins = $bet['wager'];
					$challenger_wins = $owner_wins;
					*/
					
					//if it has expired with a tie,  mark action as 'tied' the next vote will break this.  This should all work as-is.  
					//Return so that we don't do the exchange of points which is the section below.
					/*
					$query = "UPDATE bets SET action='tied' WHERE id='{$bet['id']}'";
					if(!mysql_query($query))
						{
							die('db_expire_bet:<br>' . mysql_error());
						}
					*/
					//new method:  Simply open the debate for another 24 hours.  Give voters 24 to vote.
					//timestamp needs to be set to two days ago.
					//set action to pending.
					//email owners
					$time = time() - 86400*2;
					$query="UPDATE bets SET
							timestamp='$time',
							action='pending'
							WHERE id='{$bet['id']}'";
							
					if(!mysql_query($query))
						{
							die('db_expire_bet:<br>' . mysql_error());
						}					
					send_mail($bet['challenger'],'tied',$bet);
					send_mail($bet['owner'],'tied',$bet);
					return true;
					
				}
	
			//we know our winner, update the database
			//resolve it.
			if(!mysql_query($query))
				{
					die('db_expire_bet:<br>' . mysql_error());
				}
			
			//give winnings.
			//(below: done cause I don't really understand php/mysql string syntax and I don't think I'll get to test this for a while.)
			$owner = $bet['owner'];
			$challenger = $bet['challenger'];
			
			if($victor=='owner')
				{
					$owner_wins = 2*$bet['wager'];
					$owner_capital = $bet['wager'];
					$did_owner_win = 1;
					
					$challenger_wins = 0;
					$challenger_capital = -$bet['wager'];
					$did_challenger_win = 0;
				}
			else
				{
					$owner_wins = 0;
					$owner_capital = -$bet['wager'];
					$did_owner_win = 0;
					
					$challenger_wins = 2*$bet['wager'];
					$challenger_capital = $bet['wager'];
					$did_challenger_win = 1;
				}
				
				
			//update database OWNER
			$query = "UPDATE users SET 
			points=points+'$owner_wins', 
			points_capital=points_capital+'$owner_capital',
			votes_for=votes_for+'{$bet['num_votes_owner']}', 
			votes_against=votes_against+'{$bet['num_votes_challenger']}',
			points_wagered=points_wagered+'{$bet['wager']}',
			points_won=points_won+'$owner_wins',
			num_debates=num_debates+1,
			num_debates_won=num_debates_won+'$did_owner_win',
			votes_for_percentage=round((votes_for/(votes_for+votes_against))*100),
			earnings_percentage=round(((points_won-points_wagered)/points_wagered)*100),
			debate_win_percentage=round((num_debates_won/num_debates)*100)
			WHERE username='$owner'";
			if(!mysql_query($query))
				{
					die('db_expire_bet: update owner<br>' . mysql_error());
				}
			
			//update user_stats for monthly competition tracking
			$month = date('m').'.'.date('Y');
			$query = "UPDATE user_stats SET 
			earnings_percentage ='$earnings_percentage',
			debate_win_percentage='$debate_win_percentage',
			votes_for=votes_for+'{$bet['num_votes_owner']}', 
			votes_against=votes_against+'{$bet['num_votes_challenger']}',
			points_wagered=points_wagered+'{$bet['wager']}',
			points_won=points_won+'$owner_wins',
			num_debates=num_debates+1,
			num_debates_won=num_debates_won+'$did_owner_win',
			votes_for_percentage=round((votes_for/(votes_for+votes_against))*100),
			earnings_percentage=round(((points_won-points_wagered)/points_wagered)*100),
			debate_win_percentage=round((num_debates_won/num_debates)*100),
			points=points_won-points_wagered+100
			WHERE username='$owner' AND month='$month'";
			if(!mysql_query($query))
				{
					die('db_expire_bet: update owner<br>' . mysql_error());
				}
			
			//update database CHALLENGER
			$query = "UPDATE users SET 
			points=points+'$challenger_wins', 
			points_capital=points_capital+'$challenger_capital',
			votes_for=votes_for+'{$bet['num_votes_challenger']}', 
			votes_against=votes_against+'{$bet['num_votes_owner']}',
			points_wagered=points_wagered+'{$bet['wager']}',
			points_won=points_won+'$challenger_wins',
			num_debates=num_debates+1,
			num_debates_won=num_debates_won+'$did_challenger_win',
			votes_for_percentage=round((votes_for/(votes_for+votes_against))*100),
			earnings_percentage=round(((points_won-points_wagered)/points_wagered)*100),
			debate_win_percentage=round((num_debates_won/num_debates)*100)
			WHERE username='$challenger'";
			if(!mysql_query($query))
				{
					die('db_expire_bet: update challenger<br>' . mysql_error());
				}
			//update user_stats for monthly competition tracking
			$query = "UPDATE user_stats SET 
			votes_for=votes_for+'{$bet['num_votes_challenger']}', 
			votes_against=votes_against+'{$bet['num_votes_owner']}',
			points_wagered=points_wagered+'{$bet['wager']}',
			points_won=points_won+'$challenger_wins',
			num_debates=num_debates+1,
			num_debates_won=num_debates_won+'$did_challenger_win',
			votes_for_percentage=round((votes_for/(votes_for+votes_against))*100),
			earnings_percentage=round(((points_won-points_wagered)/points_wagered)*100),
			debate_win_percentage=round((num_debates_won/num_debates)*100),
			points=points_won-points_wagered+100
			WHERE username='$challenger' AND month='$month'";
			if(!mysql_query($query))
				{
					die('db_expire_bet: update challenger<br>' . mysql_error());
				}			
		} //closes if status == dispute
	else
		{
			die('db_expire_bet:  I don\'t know how you got here.  Please report this.  codeword: SPASMODIC');
		}
	if($_SESSION['user_name'])
		{
			set_user_session_data();
		}
}



function db_get_bet($bet_id)
{
	//retrieve data from specified bet
	$query  = "SELECT id,
			owner, 
			challenger, 
			wager, 
			title,
			claim,
			timestamp,
			anonymous,
			status,
			action,
			show_vote_counts,
			num_arguments_allowed,
			creator,
			votes_owner,
			votes_challenger,
			victor,
			num_comments,
			num_arguments,
			last_updated,
			last_updated_by
			FROM bets WHERE id='{$bet_id}'";

	$result = mysql_query($query);
	
	if(!$result)
		{
			return false;
		}
	
	$bet = mysql_fetch_assoc($result);
	if(!$bet){echo mysql_error(); return false;}

	//Let's count our votes and get to know our voters. 
	//This is necessary for the voting process: No double votes, etc..
	
	$bet['voters_owner'] = explode(",",$bet['votes_owner']); 
	$bet['num_votes_owner'] = count($bet['voters_owner'])-1;
	$bet['voters_challenger'] = explode(",",$bet['votes_challenger']);
	$bet['num_votes_challenger'] = count($bet['voters_challenger'])-1;

	$bet['title']=stripslashes($bet['title']);
	$bet['claim']=stripslashes($bet['claim']);
	
	
	//added to handle proposals
	if(!$bet['wager']){$bet['wager']='<img src="files/koutouki_favicon.png" alt="Proposal" border="0" />';}

	//added to display how long until expiration
	if($bet['status']=='open' || $bet['status']=='dispute')
		{
			$bet['time_remaining'] = $bet['timestamp'] + 4*24*60*60 - time();
			if($bet['time_remaining']<=0 && $bet['action']!='tied')
				{
					//this bet has expired, update the database
					db_expire_bet($bet);
					return db_get_bet($bet_id); 
				}
			else if($bet['action']=='tied')
				{
					/*
					I have no idea how tied bets are being expired.
					I think that there is some redundant database queries.
					Perhaps, marked as tied, then closed, then expired?
					
					It's currently working, though.
					*/
				}
			else if($bet['time_remaining']<=86400 && $bet['action']!='closed' && $bet['status']=='dispute')
				{
					db_close_bet($bet['id']);
				}

			//lifted from comment on php.net manual for time()
			//Thank you STaRDoGGCHaMP
			
			$until = $bet['timestamp'] + 4*24*60*60;
			$now = time();
			$difference = $until - $now;

 
			//If the initial difference is negative, then this bet should have been expired.
			//It hasn't been, because it's tied.
			if($difference<0)
				{
					$tied = 1;
				}
			
			$days = floor($difference/86400);
			$difference = $difference - ($days*86400);

			$hours = floor($difference/3600);
			$difference = $difference - ($hours*3600);

			$minutes = floor($difference/60);
			$difference = $difference - ($minutes*60);

			$seconds = $difference;
			$bet['time_remaining_formatted'] = "$days days, $hours hours and $minutes minutes";
			$argdays = $days - 1;
			$bet['time_remaining_arguments'] = "$argdays days, $hours hours and $minutes minutes";
			$bet['time_remaining'] = "{$days}:{$hours}:{$minutes}";
			
			/* format time for FRONTPAGE */
			if($minutes==0){$minutes=1;}
			if($days==1)
				{
					$bet['time_remaining_frontpage'] = $days . " day";
				}
			else if($days>1)
				{
					$bet['time_remaining_frontpage'] = $days . " days";
				}
			else if($hours==1)
				{
					$bet['time_remaining_frontpage'] = $hours . " hour";
				}
			else if ($hours>1)
				{
					$bet['time_remaining_frontpage'] = $hours . " hours";
				}
			else if($minutes==1)
				{
					$bet['time_remaining_frontpage'] = $minutes . " minute";
				}
			else if($minutes>1)
				{
					$bet['time_remaining_frontpage'] = $minutes . " minutes";
				}
			else
				{
					$bet['time_remaining_frontpage'] = "ERROR";
				}
			if($tied)
				{
					$bet['time_remaining_frontpage'] = "No time ";
				}
			if($days<1)
				{
					$bet['time_remaining_frontpage'] = '<font class="error_message">'.$bet['time_remaining_frontpage'].'</font>';
				}
		}
	//formate Last_updated: hours:minutes AGO
	
	$since = $bet['last_updated'];
	$now = time();
	$difference = $now - $since;
	
	$days = floor($difference/86400);
	$difference = $difference - ($days*86400);		
	
	$hours = floor($difference/3600);
	$difference = $difference - ($hours*3600);
	
	$minutes = floor($difference/60);
	$difference = $difference - ($minutes*60);
	
	if($minutes==0){$minutes=1;}
	if($days==1)
		{
			$bet['last_updated'] = $days . " day";
		}
	else if($days)
		{
			$bet['last_updated'] = $days . " days";
		}
	else if($hours==1)
		{
			$bet['last_updated'] = $hours . " hour";
		}
	else if ($hours)
		{
			$bet['last_updated'] = $hours . " hours";
		}
	else if($minutes==1)
		{
			$bet['last_updated'] = $minutes . " minute";
		}
	else if($minutes)
		{
			$bet['last_updated'] = $minutes . " minutes";
		}
	else
		{
			$bet['last_updated'] = "error";
		}
		
	$bet['owner_shown'] = $bet['owner'];
	$bet['challenger_shown'] = $bet['challenger'];
		
	//if our debate is anonymous and still live, hide the names and avatars.
	if($bet['anonymous']=='yes' && ($bet['status']=='dispute' || $bet['status']=='open'))
		{
			if($bet['owner'])
				$bet['owner_shown'] = 'Socrates';
			if($bet['challenger'])
				$bet['challenger_shown'] = 'Plato';
		
		}
	
	
	return $bet;
 
}
function db_get_arguments($bet)
{
   //retrieve data from specified comment
  $query  = "SELECT id, bet_id, owner, DATE_FORMAT(time,'%H:%i - %c/%e') AS time, content FROM arguments WHERE bet_id='{$bet['id']}' ORDER BY id ASC";
  
  $result = mysql_query($query);
     
       if(!$result)
			{
				die('in f_database, db_get_argument query returns NULL for argument: {$argument_id}.  Interesting, eh?');
            }
  		$i=0;
		while($data = mysql_fetch_array($result))
			{
				$arguments[$i] = $data;
				$i++;
			}
		
		//censor arguments that should not be shown yet.
		
		//if we're waiting, then we shouldn't show the last argument.
		if($bet['action']=='waiting_challenger' || $bet['action']=='waiting_owner')
			unset($arguments[$i-1]);

	return $arguments;
}


function db_get_comments($bet_id, $parent)
{
   //retrieve data from specified comment
  $query  = "SELECT id, bet_id, owner, DATE_FORMAT(time,'%H:%i - %c/%e') AS time, content, parent, num_children, rating, rated_by FROM comments WHERE bet_id='{$bet_id}' AND parent='{$parent}' ORDER BY id ASC";
  
  $result = mysql_query($query);
     
       if(!$result)
           {
          die('in f_database, db_get_comment query returns NULL for comment: {$comment_id}.  Interesting, eh?');
            }
		$i=0;
		while($data = mysql_fetch_array($result))
           {
				$comments[$i] = $data;
				$i++;
           }

	return $comments;
}
function db_add_argument($bet_id, $owner, $content)
{
	//I know this looks inefficient, but the $bet will not be passed as an argument because
	//the bet_id is pulled from the GET value.  So there is no doubling up of database queries.
	
	$bet = db_get_bet($bet_id);
	
	// verify that bet is still open
	if($bet['action']=='closed' || $bet['status']=='resolved')
		{
			die("uh-oh.  You've tried to argue on a bet that has been closed.  Don't feel bad.  I'm sure you'll win anyway.  Hit that back utton.");
		}
		
	$content = process_tags($content);
	if(!$content)
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&replyto={$parent}&fail=content#footer\">");
		}
		
	$query = "INSERT INTO arguments (bet_id, owner, content) VALUES ( '$bet_id', '$owner','$content')";

	if(!mysql_query($query)){die('error db_add_argument.  Could not insert argument. Database error');}
	

	//not only do we have to update num_arguments, and last updated etc,
	//we have to decide whether to set status to 'waiting'
	//if there's a limit, we need to either turn waiting off, or set it to the opponent.

	$action_string = "";
	if($bet['num_arguments_allowed']>0)
		{
			//we've got a limit
			if(($bet['num_arguments']+1)/2 == $bet['num_arguments_allowed'])
				{
					//This is the last argument.  Close the debate
					$action_string = "action='closed', ";
				}
			else if($bet['action']=='pending' || $bet['action']=='proposal')
				{
					//set the bet to waiting
					if($bet['owner']==$_SESSION['user_name'])
						{
							$action_string = "action='waiting_challenger', ";
						}
					else
						{
							$action_string = "action='waiting_owner', ";
						}
				}
			else
				{
					//we've been waiting, set it back to open.
					
					$action_string = "action='pending', ";
				}
		}
	
	$time=time();
	$query = "UPDATE bets SET 
			num_arguments=num_arguments+1,
			last_updated='$time', "
			.$action_string.
			"last_updated_by='$owner'
			WHERE id='$bet_id'";
	
	//send mail to appropriate person
	if($_SESSION['user_name']==$bet['owner'])
		{
			send_mail($bet['challenger'],'reply_argument',$bet);
		}
	else
		{
			send_mail($bet['owner'],'reply_argument',$bet);
		}
	
	if(!mysql_query($query)){die('<br>error db_add_argument. Database error: don\'t feel bad, it\'s not your fault.<br/>'.mysql_error());}
	
	$query = "UPDATE users SET num_arguments=num_arguments+1 WHERE username='$owner'";
	if(!mysql_query($query))
		{
			die("db_add_argument:<br/>".mysql_error());
		}
	//update user_stats for monthly tracking
	$month = month();
	$query = "UPDATE user_stats SET num_arguments=num_arguments+1 WHERE username='$owner' AND month='$month'";
	if(!mysql_query($query))
		{
			die("db_add_argument:<br/>".mysql_error());
		}
	
	$msg = "";
	log_action($bet_id,'argument', $msg);
   
}
function db_add_comment($bet_id, $owner, $content, $parent)
{
	//I know this looks inefficient, but the $bet will not be passed as an argument because
	//the bet_id is pulled from the GET value.  So there is no doubling up of database queries.
	
	$bet = db_get_bet($bet_id);
	
	/* removed to allow anonymous commenting
	
	if(!$_SESSION['user_name'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&replyto={$parent}&fail=login#footer\">");
		}
	*/	
	$content = process_tags($content);
	if(!$content)
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&replyto={$parent}&fail=content#footer\">");
		}
		
	$query = "INSERT INTO comments (bet_id, owner, content, parent) VALUES ( '$bet_id', '$owner','$content','$parent')";

	if(!mysql_query($query)){die('error db_add_comment.  Could not insert comment. Database error');}
	$time=time();
	
	if($parent>0)
		{
			$query = "UPDATE comments SET num_children=num_children+1 WHERE id='{$parent}'";
			if(!mysql_query($query)){die('<br>error db_add_argument.  Could not update num_children. Database error: don\'t feel bad, it\'s not your fault.');}
			$query = "SELECT owner,id FROM comments WHERE id='{$parent}'";
			$result = mysql_query($query);

			$data = mysql_fetch_array($result);
			$info['parent'] = $parent;
			$info['id'] = $bet_id;
			//die("owner = ".$data['owner']);

		}
		
	$query = "UPDATE bets SET num_comments=num_comments+1, last_updated='$time', last_updated_by='$owner' WHERE id='$bet_id'";
	if(!mysql_query($query)){die('<br>error db_add_comment.  Could not update num_comments. Database error: don\'t feel bad, it\'s not your fault.');}
	
	$query = "UPDATE users SET num_comments=num_comments+1 WHERE username='$owner'";
	if(!mysql_query($query))
		{
			die("db_add_comment:<br/>".mysql_error());
		}
		
	//update user_stats for monthly tracking
	$month = month();
	$query = "UPDATE user_stats SET num_comments=num_comments+1 WHERE username='$owner' AND month='$month'";
	if(!mysql_query($query))
		{
			die("db_add_comment:<br/>".mysql_error());
		}
	
	$msg = "";
	log_action($bet_id,'comment', $msg);
	
	//send email to parent owner, unless replying to self.
	if($parent>0 && $data['owner']!=$owner)
		{
			send_mail($data['owner'],'reply_comment',$info);
		}
		
	//send email to debate owners, unless commenting on own debate.	
	else if($owner!=$bet['owner'] && $owner!=$bet['challenger'])
		{
			send_mail($bet['owner'],'reply_debate',$bet);
		}

	
   
}

function db_add_vote($vote_for,$bet_id)
{
 $bet = db_get_bet($bet_id);
 if(!$bet)
  {
   die("I have no idea how you got here.  It just doesn't make sense: db_add_vote from descent.php");
  }
  //insert their user_name, into votes_owner, votes_challenger depending on who they picked.  Delete from other string, regardless of whether it's there or not.
/*  if($vote_for=='owner')
    {
	 //$votes_challenger = str_replace($_SESSION['user_name'],"",$bet['votes_challenger']);
	 //$votes_owner = $bet['votes_owner'] . ','.$_SESSION['user_name'];
	}
  else if($vote_for=='challenger')
    {
	 $votes_owner = ',' . str_replace($_SESSION['user_name'],"",$bet['votes_owner']);
	 $votes_challenger = $bet['votes_challenger'] . ','.$_SESSION['user_name'];
	}
  else{die('There is no way you could possibly have ended up here.  db_add_vote, from descent.php');}
  
  */
	$newvote=true;
	$num_voters=0;
	$voters_owner='';
	foreach($bet['voters_owner'] as $voter)
	    {
			if($voter==$_SESSION['user_name'])
				{$newvote = false;}
			if($voted_for=='owner' || $voter!=$_SESSION['user_name'])
				{
					if($voter!='' && $voter!=',')
						{			
							$voters_owner = $voters_owner . ',' . $voter;
							$num_voters++;
						}
				}
		}

	$voters_challenger='';
	foreach($bet['voters_challenger'] as $voter)
	    {
			if($voter==$_SESSION['user_name'])
				{$newvote = false;}
				
			if($voted_for=='challenger' || $voter!=$_SESSION['user_name'])
				{	
					if($voter!='' && $voter!=',')
						{			
							$voters_challenger = $voters_challenger . ',' . $voter;
							$num_voters++;
						}
				}			 
		}
	if($vote_for=='owner')
		{
			$voters_owner = $voters_owner . ',' . $_SESSION['user_name'];
			$num_voters++;
		   
			$msg = $_SESSION['user_name']." voted for ".$bet['owner'];
			log_action($bet_id,'vote', $msg);
		 
		}
	else if($vote_for=='challenger')
		{
			$voters_challenger = $voters_challenger . ',' .$_SESSION['user_name'];
			$num_voters++;
			
			$msg = $_SESSION['user_name']." voted for ".$bet['challenger'];
			log_action($bet_id,'vote', $msg);
		
		}
	 
	 
	  
   $query = "UPDATE bets SET num_votes='$num_voters', votes_owner = '$voters_owner', votes_challenger = '$voters_challenger', action='pending' WHERE id='$bet_id'";
  
   if(!mysql_query($query)){die('Database error: could not db_add_vote<br>' . mysql_error());}
   
   //add one to our votes_cast count for the current user
	if($newvote)
		{
			$username = $_SESSION['user_name'];
			$query = "UPDATE users SET votes_cast=votes_cast+1 WHERE username='$username'";
			mysql_query($query);
		}
   return true;
}

function db_challenge_open_bet($bet_id)
{
	$bet = db_get_bet($bet_id);
	if(!$bet)
		{
			die("I have no idea how you got here.  You can't challenge a bet that does not exist.  Must have been a database error:  db_challenge_open_bet from descent.php");
		}
	if($bet['wager']>$_SESSION['user_points'])
		{
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&fail=bigwager\">");
		}
	//make sure that the bet is not already challenged.
	if($bet['status']=='dispute')
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&error=bet_taken\">");
		}
	if($bet['action']=='personal_challenge' && $bet['challenger']!=$_SESSION['user_name'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&error=bet_not_for_you\">");
		}
	//put the bet in the database
	$time=time();
	$query = "UPDATE bets SET challenger='{$_SESSION['user_name']}', timestamp='$time', status='dispute' WHERE id='$bet_id'";
  	if(!mysql_query($query))
		{
			die('Database error: could not db_challenge_open_bet in descent.php  ' . mysql_error() .'<br><br>Don\'t feel bad, it wasn\'t your fault...');
		}
	
	
	//update user info
	$info = db_get_user_info($_SESSION['user_name']);
	$points = $info['points'] - $bet['wager'];
	$query  = "UPDATE users SET points='{$points}' WHERE username = '{$_SESSION['user_name']}'";
   
   if(!mysql_query($query)){die('error db_add_bet.  Could not update user points.');}
   $_SESSION['user_points'] = $points;

	send_mail($bet['owner'],'challenge',$bet);

	$msg = $_SESSION['user_name']." challenged ".$bet['owner'];
	log_action($bet_id,'challenge', $msg);
	return true;
}

function db_accept_proposal($bet_id, $wager, $anon)
{
	$wager = (int) ($wager);
	$bet = db_get_bet($bet_id);
	if(!$bet)
		{
			die("I have no idea how you got here.  You can't challenge a bet that does not exist.  Must have been a database error:  db_challenge_open_bet from descent.php");
		}
	
	//make sure that the bet is not already challenged.
	if($bet['owner'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&error=proposal_taken\">");
		}
	if($wager>$_SESSION['user_points'])
		{
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&fail=bigwager\">");
		}
	if($wager==0)
		{
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&fail=nowager\">");
		}
	if($wager<0)
		{		
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$bet_id}&fail=negwager\">");
		}
		
	//is our debate going to be anonymous?
	if($anon)
		$bet['anonymous'] = 'yes';
		
	//We can update all the information.  This could all be done in one command if I knew how to UPDATE more than one variable at a time.  Do you know how?  Change it for me please?  
	//there, i did it for myself.  
		$time=time();
	$query = "UPDATE bets SET 
			owner='{$_SESSION['user_name']}',
			wager={$wager}, timestamp='$time',
			anonymous='{$bet['anonymous']}',
			status='open',
			action='pending'
			WHERE id='$bet_id'";
  	if(!mysql_query($query))
		{
			die('Database error: could not db_challenge_open_bet in descent.php  ' . mysql_error() .'<br><br>Don\'t feel bad, it wasn\t your fault...');
		}
	
	//update user points
	$points = $_SESSION['user_points'] - $wager;
	$query  = "UPDATE users SET points='{$points}' WHERE username='{$_SESSION['user_name']}'";
   
   if(!mysql_query($query)){die('error db_add_bet.  Could not update user points.');}
   $_SESSION['user_points'] = $points;
   send_mail($bet['creator'],'proposal_accepted',$bet);
   	
	$msg = $_SESSION['user_name']." challenged ".$bet['creator'];
	log_action($bet_id,'challenge', $msg);
   return true;
}
function db_process_resurrection($bet, $decision)
{
	if($bet['status']!='expired' && $bet['action']!='resurrecting')
		{return false;}
	if($decision=='decline')
		{
			$query  = "UPDATE users SET points='{$points}'+{$bet['wager']} WHERE username = '{$bet['challenger']}'";
			if(!mysql_query($query)){die('error db_add_bet.  Could not update user points: '.mysql_error());}
			$query = "UPDATE bets SET 
			status='expired',
			action='pending'
			WHERE id='{$bet['id']}'";
		  	if(!mysql_query($query))
				{
					die('Database error: could not db_process_resurrection in  descent.php  ' . mysql_error() .'<br><br>Don\'t feel bad, it wasn\t your fault...');
				}
		
		}
	else if($decision=='accept')
		{
			if($_SESSION['user_points']<$bet['wager'])
				{
					echo "you don't enough lumens";
					db_process_resurrection($bet,'decline');
					return false;
				}
			
			$time = time();
			$query = "UPDATE bets SET 
			timestamp='$time',
			status='dispute',
			action='pending'
			WHERE id='{$bet['id']}'";
		  	if(!mysql_query($query))
				{
					die('Database error: could not db_process_resurrection in  descent.php  ' . mysql_error() .'<br><br>Don\'t feel bad, it wasn\t your fault...');
				}
	
			//update user points
			$points = $_SESSION['user_points'] - $bet['wager'];
			$query  = "UPDATE users SET points='{$points}' WHERE username='{$_SESSION['user_name']}'";

			if(!mysql_query($query)){die('error db_add_bet.  Could not update user points.');}
			$_SESSION['user_points'] = $points;
			return true;
		}
	return false;
}
function db_resurrect($bet)
{
	/*
	*	this function is for when an expired bet
	*	is to be brought back.  
	*	proposal -> accept proposal (changed, handled by descent.php)
	*	open -> email user, marked resurrecting.
	*	resurrecter's lumens wil be returned if the original debater denies resurrection
	*/
	
	if($bet['status']!='expired')
		{return false;}
	if($_SESSION['user_name']==$bet['owner'])
		{return false;}
		
	//put the bet in the database
	$time=time();
	$query = "UPDATE bets SET challenger='{$_SESSION['user_name']}', timestamp='$time', status='expired', action='resurrecting' WHERE id='{$bet['id']}'";
  	if(!mysql_query($query))
		{
			die('Database error: could not db_resurrect in descent.php  ' . mysql_error() .'<br><br>Don\'t feel bad, it wasn\'t your fault...');
		}
	
	//update user info
	$info = db_get_user_info($_SESSION['user_name']);
	$points = $info['points'] - $bet['wager'];
	$query  = "UPDATE users SET points='{$points}' WHERE username = '{$_SESSION['user_name']}'";
   
	if(!mysql_query($query)){die('error db_add_bet.  Could not update user points.');}
	$_SESSION['user_points'] = $points;
	
	send_mail($bet['owner'],'resurrection',$bet);

	$msg = $_SESSION['user_name']." resurrected ".$bet['id']." by ".$bet['owner'];
	log_action($bet['id'],'challenge', $msg);
	return true;

}
function db_get_user_email($username)
{
    $query  = "SELECT email, email_options FROM users WHERE username = '$username'";
    $result = mysql_query($query);
	$data = mysql_fetch_array($result);
	return $data;
}
function db_change_email_options($user, $email, $options)
{
	
	$query  = "UPDATE users SET email='$email', email_options = '$options' WHERE username='$user'";
   
	if(!mysql_query($query)){die('error db_change_email_options:  Could not update options.');}

	$msg = "Changed email options";
	log_action('000','settings', $msg);
   
}
function db_crazy_edit()
{


}
function db_close_month()
{
	//





}

function db_init_month()
{

	/*
	*	Calculate place for user_stats:
	*	.	Grab all names
	*	.	For each, db_get_user_place
	*	.	update users user_stats
	*/
	$month = month();
	$query = "SELECT id, username, points FROM user_stats WHERE month='01.2007'";
	$result = mysql_query($query);
	if(!$result)
		die('Oh boy (db_init_month()): <br>'. mysql_error(). $query);
	while($data = mysql_fetch_array($result))
		{
			$place = db_get_user_place($data['username'],$data['points']);
			$query = "UPDATE user_stats SET place='$place' WHERE id='{$data['id']}'";
			$result = mysql_query($query);
			echo "go!<br/>";	
				if(!$result)
					die('Oh boy (db_init_month(): nested): <br>'.mysql_error(). $query);
		}
	
	/*	prep for this month's competition
	*	by resetting all users points to 100.
	*/
	$query  = "UPDATE users SET 
	points='100',
	points_capital='100',
	active_this_month='no'";
	if(!mysql_query($query)){die('error db_init_month: '.mysql_error());}
}
function db_init_user_stats()
{
	/*	create a stats history entry in user_stats on log-in
	*	
	*	This function exists so that a user_stats entry is not 
	*	created every month for unused usernames
	*/
	if($_SESSION['active_this_month']=='yes' || $_SESSION['user_email']=='private_user' || !$_SESSION['user_name'])
		return true;
	else
		{
			//new entry
			$month = date("m").'.'.date("Y");
			$query = "INSERT INTO user_stats (month, username,points) VALUES ('$month','{$_SESSION['user_name']}','100')";
			if(!mysql_query($query)){die('error db_init_user_stats: '.mysql_error());}
			
			//set active this month so we don't do this again this month
			$query = "UPDATE users SET active_this_month='yes' WHERE username='{$_SESSION['user_name']}'";
			if(!mysql_query($query)){die('error db_init_user_stats: '.mysql_error());}
			return true;
		}
}

$dbhost = 'localhost';
$dbuser = 'pquusczc_root';
$dbpass = 'rush2112';

$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die('Error connecting to mysql');

$dbname = 'pquusczc_bet';
mysql_select_db($dbname);


?>
