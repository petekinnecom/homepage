<?php


function process_accept_bet()
	{
		$urlcontent=urlencode($_POST['content']);
		if(!$_SESSION['user_name'])
			{
				die("<meta http-equiv=\"Refresh\" content=\"0;url=login.php\">");
			}
		
		if(!$_POST['content'])
			{
			   die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&fail=content&wager={$_POST['wager']}\">");
			}		
		
		if(!$_POST['accept_checkbox'])
			{
				die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&fail=chkbx&content={$urlcontent}&wager={$_POST['wager']}\">");
			}

		if($_POST['accept_checkbox']=='accept_challenge')
			{
			//update bet stuff
			 //This function will spit an error message if the bet has been changed to challenge in the database
			 db_challenge_open_bet($_GET['id']);
			 //add argument
			 db_add_argument($_GET['id'], $_SESSION['user_name'], $_POST['content']);
			
			}
		
		if($_POST['accept_checkbox']=='accept_proposal')
			{
				$_POST['wager'] = (int) ($_POST['wager']);
				if(!$_POST['wager'])
					{
						die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&fail=nowager&content={$urlcontent}\">");
					}
				if($_POST['wager']>$_SESSION['user_points'])
					{
						die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&fail=bigwager&content={$urlcontent}\">");
					}
				//update bet stuff
				db_accept_proposal($_GET['id'], $_POST['wager'], $_POST['anonymous']);
				//add argument
				db_add_argument($_GET['id'], $_SESSION['user_name'], $_POST['content']);
			}

	}
function process_resurrect_bet()
{
	$bet = db_get_bet($_GET['id']);

	if(!$bet['owner'])
		{//dead proposal
			if(!$_POST['content'])
				{
				   die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&fail=content&wager={$_POST['wager']}&resurrect={$_GET['id']}\">");
				}		
			
			if(!$_POST['accept_checkbox'])
				{
					die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&fail=chkbx&content={$urlcontent}&wager={$_POST['wager']}&resurrect={$_GET['id']}\">");
				}

			if($_POST['accept_checkbox']=='accept_proposal')
				{
					//update bet stuff
					//This function will spit an error message if the bet has been changed to challenge in the database
					db_accept_proposal($_GET['id'], $_POST['wager'], $_POST['anonymous']);
					//add argument
					db_add_argument($_GET['id'], $_SESSION['user_name'], $_POST['content']);
				
				}
		}
	else if($bet['owner'])
		{
			db_resurrect($bet);
		}
}