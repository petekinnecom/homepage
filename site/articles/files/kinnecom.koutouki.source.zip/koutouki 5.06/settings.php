<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_output.php");
/*************************************/

initiate_pagination_sequence();
if(!$_SESSION['user_name'])
	{
		die('you need to be logged in to edit settings');
	}
if($_POST['upload'])
	{
		// Fix path of your file to be uploaded, don't forget to CHMOD 777 to this folder 
		$file_dir  = "/home/pquusczc/public_html/koutouki/avatars/"; 
		if (trim($_FILES['myfiles']['name'][0])!="") 
			{
				$loweredfilename= strtolower($_SESSION['user_name']); 
				$loweredfilename = str_replace(" ", "_", $loweredfilename);
				$newfile = $file_dir. $loweredfilename; 

				/* check filetype */

				$filename = $_FILES['myfiles']['name'][0];
				if (($pos = strrpos($filename, ".")) === FALSE)
				  echo "<b>Error <i>" . $_FILES['myfiles']['name'][$i] . "</i> NOT uploaded: filename must have an extension</b>";

				else {

				  $upload_approved=0;
				  $extension = substr($filename, $pos + 1);
				  $extension = strtolower($extension); 
				 switch ($extension) {
				    case jpg:
				    case bmp:
				    case png:
				    case gif:
				    case tif:
				    case tga:
				    case ico:
				    $upload_approved=1;
				     break;
				    default:    
				      echo "<p><b>Error <i>" . $_FILES['myfiles']['name'][0] . "</i> NOT uploaded: invalid filetype<p></b>";
				     break;
				        }

				     }

				/* done check filetype */
				$newfile = $newfile . "." . $extension;
				$loweredfilename = $loweredfilename . "." . $extension;
				if(!$_FILES['myfiles']['tmp_name'][0]){$upload_approved=0;}
				if(filesize($_FILES['myfiles']['tmp_name'][0])>1000000){$upload_approved=0; echo "<br><b>File too big!</b>";}      

				if($upload_approved)
					{
						if(move_uploaded_file($_FILES['myfiles']['tmp_name'][0], $newfile))
							{
								//success!  update the db with the new info
								db_set_user_avatar($loweredfilename,$_SESSION['user_name']);
							
							}
				else{echo '<br>' . $_FILES['myfiles']['name'][0] . ' failed to upload for some unknown reason.';}}

			} 
	}  

//process all posted info
if($_POST['save'])
	{
		if($_POST['bet_info'])
			{
				if($_POST['replies'])
					{
						$type = 'all';
					}
				else
					{
						$type = 'bet_info';
					}
			}
		else if ($_POST['replies'])
			{
				$type = 'replies';
			}
		else
			{
				$type = 'none';
			}
		
		db_change_email_options($_SESSION['user_name'], $_POST['email'], $type);
		$message = "As you wish.";
	}
	
if($_POST['change_password'])
	{
		$md5pass = md5($_POST['old_password']);
		if(db_check_user_password($_SESSION['user_name'],$md5pass) != 'success')
			{
				$message = "Your old password did not match the password in the database.<br/>Many Bothans died to bring us this information.";
			}
		else if($_POST['new_password_1'] != $_POST['new_password_2'])
			{
				$message = "The new passwords did not match.  I know, it's frustrating. I can feel your anger. I am unarmed. Take your weapon. Strike me down with all of your hatred and your journey towards the dark side will be complete. ";
			}
		else if(!$_POST['new_password_1'])
			{
				$message = "Setting your password to nothing would be a major security risk.  I won't do it. I'll never turn to the Dark Side. You've failed, your highness. I am a Jedi, like my father before me. ";
			}
		else
			{
				$md5pass = md5($_POST['new_password_1']);
				db_change_user_password($_SESSION['user_name'],$md5pass);
				$message = "As you wish.";
			}
	}
	
$info = db_get_user_info($_SESSION['user_name']);
?>

<a href="edit_profile.php">Edit your profile.</a>

<div align="center"><br/><br/>

<?output_avatar($_SESSION['user_name'])?><br/>
Change avatar.<br/>
<font class="note">must be 100 x 100</font>
<form method='post' enctype='multipart/form-data'>
<input type='file' name='myfiles[]' size='30'><br>
<input type='submit' name='upload' value='upload'> 
</form>
<br/><br/>
<table align="center" border="0" cellspacing="0" cellpadding="3">
<tr>
<form name="myform" action="/settings.php" method="POST">
<td>Email:</td>

<td><input type="text" name="email" maxlength="30" value="<? echo $info['email'];?>"></td>
</tr>
<tr>
<td>
<input type="checkbox" name="bet_info" value="bet_info"
<? if($info['email_options']=='all' || $info['email_options']=='bet_info')
	{echo "checked";} ?>
></td>
<td> Email me when I win, lose, or am challenged.</td>
</tr>
<tr>
<td>
<input type="checkbox" name="replies" value="replies"
<? if($info['email_options']=='all' || $info['email_options']=='replies')
	{echo "checked";} ?>

></td><td>Email me when someone replies to my posting.</td>
</tr>

<tr><td><input type="submit" name="save" value="  Save"></td></tr>

</form>
<tr><td><br/></td></tr>

<form name="myform2" action="/settings.php" method="POST">


<tr>
<td>Old Password:</td>

<td><input type="password" name="old_password" maxlength="30"></td>
</tr>
<tr>
<td>New Password:</td>

<td><input type="password" name="new_password_1" maxlength="30"></td>
</tr>
<tr>
<td>New Password:</td>

<td><input type="password" name="new_password_2" maxlength="30"></td>
</tr>


<tr><td><input type="submit" name="change_password" value="  Change Password  "></td></tr>
</table>

</div></form>
<br/>
<?echo $message;
output_footer();
?>