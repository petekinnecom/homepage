<?php
include("f_database.php");
include("f_output.php");

$bet = db_get_bet($_GET['id']);

?>
	<div style="text-align:center;">
	<div style="float:left;"><?
	output_avatar($bet['owner_shown'])
	?></div>	
	<div style="float:right;"><?
	output_avatar($bet['challenger_shown'])
	?></div>
	<div style="width:200px;text-align:left;margin:auto;"><?
	if($bet['show_vote_counts']=='yes' || $bet['status']!='dispute')
		{
			echo $bet['owner_shown'].":  ".$bet['num_votes_owner']."  ||  ";
			echo $bet['challenger_shown'].":  ".$bet['num_votes_challenger']."<br/>";
		}
?>
<br/>
shown vote tallies: <?echo $bet['show_vote_counts']?><br/>
anonymous: <?echo $bet['anonymous']?><br/>
number of arguments: <?echo $bet['num_arguments']?><br/>
<?if($bet['status']=='dispute')
	{
		if($bet['status']=='pending')
			{?>time left for arguments: <?echo $bet['time_remaining_arguments']?><br/><?}
		else
			{?>time left for voting: <?echo $bet['time_remaining_formatted']?><br/><?}
	}
	?>
last updated: <?echo $bet['last_updated']?>  ago<br/> 
<?	//to avoid showing last updated in anonymous debates.

if ($bet['anonymous']=='no' || ($bet['status']!='open' && $bet['status']!='dispute'))
	{
	?>
	by: 
	<?	echo $bet['last_updated_by'];
	}
	?>
</div>
</div>
</html>