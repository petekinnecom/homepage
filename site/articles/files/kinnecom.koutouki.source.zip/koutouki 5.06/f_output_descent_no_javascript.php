<?


function output_time_remaining($bet,$clocknum,$days,$type='expire')
{
	$clock = 'cd'.$clocknum;
	if($type=='expire')
		{
			$display = "This debate will end in";
			$finish = "This debate has ended.";
		}
	else if($type=='close')
		{
			$display = "This debate will close in";
			$finish = "This debate has closed.  Pressing update will do NOTHING!";
		}
	?>
	<div class="error_message">
	<? 
	$javatimeleft = date('m/d/Y h:i A',$bet['timestamp'] + $days*24*60*60);
	?>
	<script language="javascript" src="files/countdown.js"></script>
	<script language="javascript">
	var <?echo $clock?> = new countdown('<?echo $clock?>');
	<?echo $clock?>.Div			= "clock2";
	<?echo $clock?>.TargetDate		= "<? echo $javatimeleft ?>";
	<?echo $clock?>.DisplayFormat	= "<?echo $display?> %%D%% days, %%H%% hours, %%M%% minutes, %%S%% seconds";
	<?echo $clock?>.FinishMessage = "<?echo $finish?>";
	</script>
	<div id="clock<?echo $clocknum?>">[clock]</div>
	<script language="javascript">
	<?echo $clock?>.Setup();
	</script>
	<noscript>
	<? echo "This debate will".$type." in ". $bet['time_remaining_arguments']; ?>.
	</noscript>
	</div>
	<?
}

function output_response_box_sorry_message($bet)
{
	if($bet['status']!='open' && $bet['status']!='dispute')
		{
			return true;
		}
	if(!$_SESSION['user_name'])
		{
			?>
			<div class="response_box ac">
			You must be <a href="login.php">logged-in</a> to vote.<br /><br />
			Don't have an account?  <a href="register.php">Sign-up</a>
			</div>
			<?
			return true;
		}
	if(is_debater($_SESSION['user_name'],$bet))
		{
			if($bet['action']=='closed')
				{
					?>
					<div class="response_box">
					<div class="ac">
					This debate has closed.<br/>
					Voting will close in <? echo $bet['time_remaining_formatted']; ?>
					</div>
					</div>
					<?
					return true;
				}
		}
	return false;
}
function output_response_box_vote_buttons($bet)
{
	//if we don't have a debater, and we have a dispute, let them vote.
	if(!is_debater($_SESSION['user_name'],$bet))
		{
			if($bet['status']=='dispute')
				{
					?>
					<div class="response_box ac">
					Vote.<br/><?
					output_vote_buttons($bet);
					?></div><?
					return true;
				}	
		
		}
	return false;
}


function output_response_box($bet)
{
	/*  ORDER OF EVENTS:
	
	open response_box div
	process opening statements.
	show preview
	show box
	process response options
	show buttons
	*/
	?><div class="response_box"><?



	if($bet['status']=='open' && $_SESSION['user_name']==$bet['owner'])
		{
			?>
			<div class="ac">
			This is your bet.  No one has responded yet.<br/>
			<? 

			$clocknum = 2;
			$days = 3;
			output_time_remaining($bet,$clocknum,$days) ?>
			Wish to clarify anything?
			<br/>
			</div>
			<?
		}
	else if($bet['status']=='dispute')
		{
			$clocknum = 2;
			$days = 3;
			output_time_remaining($bet,$clocknum,$days,'close');
		}
	
	if($_POST['preview'])
		{
			$content = process_tags(stripslashes($_POST['content']));
			$form_content = br2nl($content);
			?>
			<div class="dispute_listing border_open">
			<div class="dispute_listing_title">
			</div>
			<div class="dispute_content ">
			<? echo $content; ?>
			<br />
			<div class="ar note"><?
			echo $_SESSION['user_name'];
			?></div>
			</div>
			</div>
			<br/>
			<?	
			
		}
	else if($_GET['content'])
		{
			$form_content = stripslashes(stripslashes($_GET['content']));
		}
	?>
	<a name="footer"></a>
	<form action="<? echo "descent.php?id=". $_GET['id']; ?>#footer" method="post" name="response_form">
	<? output_tag_buttons() ?>
	<textarea style="width:99%;" rows="10" name="content" id="canvas"><?echo $form_content;?></textarea>
<script type="text/javascript">var edCanvas = document.getElementById('canvas');</script>
	<?
	if($bet['status']=='open' && $_SESSION['user_name']!=$bet['owner'])
		{
			?>
			<br />
			<input type="checkbox" name="accept_checkbox" 
			value="<? 
			if($bet['action']=='proposal'){echo 'accept_proposal';}
			else{echo 'accept_challenge';} ?>"
			<?if($_POST['accept_checkbox'])
				echo "checked"
			?>
			>
			I wager <? 
	
			if($bet['action']=='pending')
				{
					echo $bet['wager']; 
				}
			else if($bet['action']=='proposal')
				{
					?>
					<input type="text" name="wager" maxlength="6" size="6" value="<? echo $_POST['wager']; ?>">
					<?
				}
			else	
				{
					die('This bet has been added to the database incorrectly.  Please report this to mctk@koutouki.org Betid = '.$bet['id']);
				}
			?> lm.<br/><?
			if($bet['anonymous']=='no' && $bet['action']=='proposal')
				{
					?>
					<input type="checkbox" name="anonymous" value="yes"	<?

					if($_POST['anonymous']=='yes')
						{
								echo "checked";
						}
					?>> <a href="javascript:openpopup('description/anonymous.html')">Anonymous</a> Debate<?
				}
			?><div class="ar">
			<?
			if($bet['show_vote_counts']=='yes')
				{
					echo "Vote tallies will be shown during debate.";
				}
			else
				{
					echo "Vote tallies will be hidden during debate.";
				}
			if($bet['anonymous']=='yes')
				{
					echo '<br/>This is an <a href="javascript:openpopup(\'description/anonymous.html\')">anonymous</a> debate.';
				}
			
			?>
			</div>
			<?
		}
	?>
	<div class="ar">
	<input type="submit" name="preview" value="   Preview  ">
	<input type="submit" name="<?
	//handle form name
	if($bet['status']=='open')
		{
			echo "accept_bet";
		}
	else
		{
			echo "add_argument";
		}
	?>" value="   Respond   ">
	</div>
	</form>
	<? output_allowed_tags();
	if($_GET['fail'])
	{
		?><div class="error_message ac"><?
		if($_GET['fail']=='bigwager')
		{
			?>I'm afraid you don't have that many lumens, my friend.<?
		}
		else if($_GET['fail']=='nowager')
		{
			?>You must enter a wager.<?
		}
		else if($_GET['fail']=='chkbx')
		{
			?>To make this challenge, you must check the box.<?
		}
		else if($_GET['fail']=='content')
		{
			?>My dearest friend, that large box you see is meant to be filled with text.  Surely you have something to say.<?
		}
		else if($_GET['fail']=='negwager')
		{
			?>Nice try.  It used to work.  Those were good days.<?
		}
		else
		{
			?>You've found the secret message.  (In other words: ERROR.  I have no clue how you got here.<br/>Let's just keep this between you and me, shall we? <?
		}
		?>
		</div>
		<?
	}
	?>

	</div>
	<?

}

function output_vote_buttons($bet)
{
/*This function returns 2 if the buttons print, 1 if the user is involved in the discussion, and 0 if the user is not logged in */

	if(!$_SESSION['user_name'])
		{
			return 0;
		}
	else if($_SESSION['user_name']==$bet['owner'] || $_SESSION['user_name']==$bet['challenger'])
		{
			return 1;
		}
	else
		{

			//user is logged in and can vote.  See if has already voted.
			foreach($bet['voters_owner'] as $voter)
				{
					if($voter==$_SESSION['user_name']){$voted='owner';}
				}
			foreach($bet['voters_challenger'] as $voter)
				{
					if($voter==$_SESSION['user_name']){$voted='challenger';}
				}
			?>
			<div class="vote_box">
			<?
			//first, give the information statement.  the buttons come later.
			/*if($voted)
				{
					echo "You have voted for " . $bet[$voted] . ".  Change your vote?";
				}
			else
				{
					echo "Who will you vote for?";
				}
			*/
				

			//Button for owner.  Votes will be GET. (changed sept 16)
			if($voted!='owner')
				{
					echo "<a href=\"descent.php?id=" . $_GET['id'] . "&vote=owner\" class=\"vote_button vote_button_owner\">" . $bet['owner_shown'] . "</a>";
				}
			else
				{
					echo "<font class=\"note\">".$bet['owner_shown']."</font>";
				}
			echo "&nbsp;&nbsp;||&nbsp;&nbsp;";
			//button for challenger
			if($voted!='challenger')
				{
					echo "<a href=\"descent.php?id=" . $_GET['id'] . "&vote=challenger\" class=\"vote_button vote_button_challenger\">" . $bet['challenger_shown'] . "</a>";
				}
			else
				{
					echo "<font class=\"note\">".$bet['challenger_shown']."</font>";
				}
			?></div>
			<?	
		}//closes else
	return 2;
}

function output_children_comments($bet_id, $comment_id, $nest_level)
{
	$data = db_get_comments($bet_id,$comment_id);
	if($data)
		{
			$margin = 30*$nest_level;


				
			//print each argument
			foreach($data as $comment)
				{
					if($_GET['replyto']==$comment['id'])
						echo '<a name="response"></a>';
					?>
					<a name="<? echo $comment['id'] ?>"></a>
					<div class="comment_listing nest_level_<?echo $nest_level%2?>" style="margin-left:<? echo $margin ?>px;">
					<div class="comment_listing_title">

					</div>
					<div class="comment_content border_comment">
					<? echo $comment['content']; ?>
					<br />
					
					<div class="ar note"><? echo $comment['owner'];?>
					<br/><? echo $comment['time'] ?></div>
					<div class="fl info"><?echo $comment['id'];?></div>
					<div class="ar note">
					<?
					if($_SESSION['user_name'])
					{
						?>
						<a href="descent.php?id=<?echo $bet_id?>&replyto=<?echo $comment['id']?>#response">reply to this</a>
						<?
					}
					?>
					</div>
					</div>
					<?
					if($_POST['preview'] && $_GET['replyto']==$comment['id'])
						{
							?>
							<div class="comment_listing nest_level_<?echo $nest_level%2+1?>" style="margin-left:30px;">
							<div class="comment_listing_title">
							<?
							//echo $comment['time'];
							?> 
							</div>
							<div class="comment_content border_comment">
							<? echo process_tags(stripslashes($_POST['content'])); ?>
							<br />
							<div class="ar note"><? echo $_SESSION['user_name'];?>
							<br/><font class="inactive">Preview</font>
							</div>
							</div>
							<?
						}
					if($_GET['replyto']==$comment['id'] && $_SESSION['user_name'])
						{
							?>
							<div class="response_box">
							<form action="descent.php?id=<?echo $_GET['id']?>&replyto=<? echo $comment['id']; 
							if($nest_level>4)
							{echo "&parent=".$comment['parent'];}		
							?>#<?echo $comment['id']?>" method="post">
							<textarea style="width:99%;" rows="10" name="content"><?
							if($_POST['preview'])
								{
									$content = br2nl(process_tags(stripslashes($_POST['content'])));
									echo $content;
								}?></textarea>
							<br />
							<div class="ar">
							<input type="submit" name="preview" value="   Preview   ">
							<input type="submit" name="add_comment" value="   Respond   ">
							</div>
							</form>
							<? output_allowed_tags();
							if($_POST['preview'])
								{?></div><?}
							if($_GET['fail'])
								{
									?>
									<br/>
									<div class="error_message">
									See that box there?  That's where you type stuff.
									</div>
									<?
								}
							?></div><?
						}
						?>
						</div>
						<?
					
					if($comment['num_children'])
						{
							output_children_comments($bet_id,$comment['id'],$nest_level+1);
							
						}
						

				}
			return true;
		}
	return false;
}

function output_descent($bet_id)
{
   ?> <div id="left_content_box"> <?
	//verify that bet exists
	$bet = db_get_bet($_GET['id']);
	

 /*  Layout of this section
 
 1.  Output Votes Header
 2.  Output Bet or proposal
 3.  Output rest of page
	A.  If status is open or proposal, output response box.
	B.  If status is dispute or resolved
		1.  Output arguments
		2.  Output response_box
			a.  If user is owner or challenger, output text area for argument
			b.  If user is not involved, output voting options.
			c.  If user is not logged in display login message.
	C.  If status is resolve
		1.  Output comments
		2.  Output add_comment box
 
 */
 
 
 if(!$bet)
  {
   die("These aren't the droids you're looking for.  Move along.");
  }
 
   //ouput the bet
 /*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/
 ?>
   
	<div class="control_header ac">
	<div class="fl"><?
	output_avatar($bet['owner_shown'])
	?></div>	
	<div class="fr"><?
	output_avatar($bet['challenger_shown'])
	?></div>
	
	<?

	if($bet['status'] == 'resolved' || $bet['status']=='expired' )
		{
			$ended = date('m/d/Y',$bet['timestamp'] + 4*24*60*60);
			echo "ended: " . $ended."<br/>";
		}
	else
		{
			$clocknum = 2;
			$days = 4;
			output_time_remaining($bet,$clocknum,$days);
		}
	

	
	/*
		Display the vote header depending on status of votes.
	*/
	
   if($bet['status']=='dispute')
		{
			/* changed to hide vote counts */
			
			?><b><a href="profile.php?user=<?echo $bet['owner_shown']?>"><? echo $bet['owner_shown']; ?></a></b>

			<?
			if($bet['show_vote_counts']=='yes')
				{
					echo $bet['num_votes_owner'];
				}
			?>
			&nbsp;&nbsp;vs&nbsp;&nbsp;
			<b><a href="profile.php?user=<?echo $bet['challenger_shown']?>"><? echo $bet['challenger_shown']; ?></a></b>
			
			<?
			if($bet['show_vote_counts']=='yes')
				{
					echo $bet['num_votes_challenger'];
				}

			
			if(!output_vote_buttons($bet))
				{
					?>
					<br/>
					<div class="note">You must be <a href="login.php">logged-in</a> to vote.<br />
					</div>
					<?
				}
			
		}
	else if($bet['status']=='expired')
		{
			?>This proposal has expired.<?
		}
	else if($bet['action']=='proposal')
		{
			?>This proposal is open.<?

		}
	else if($bet['status']=='open')
		{
			?><b><a href="profile.php?user=<?echo $bet['owner_shown']?>"><? echo $bet['owner_shown']; ?></a> </b> vs.  <b>?</b><?

		}
	else if($bet['status']=='resolved')
		{
			?><div class="error_message"><b>The results:</b></div><br /><?
			if($bet['victor']=='owner')
				{
					?><b><a href="profile.php?user=<?echo $bet['owner']?>"><? echo $bet['owner']; ?></a>:</b>  <? echo $bet['num_votes_owner'];?>
					&nbsp;&nbsp;defeats&nbsp;&nbsp;
					<b><a href="profile.php?user=<?echo $bet['challenger']?>"><? echo $bet['challenger']; ?>:</a></b>  <? echo $bet['num_votes_challenger'];
				}
			else if($bet['victor']=='challenger')
				{
					?><b><a href="profile.php?user=<?echo $bet['owner']?>"><? echo $bet['owner']; ?></a>:</b>  <? echo $bet['num_votes_owner'];?>
					&nbsp;&nbsp;loses to&nbsp;&nbsp;
					<b><a href="profile.php?user=<?echo $bet['challenger']?>"><? echo $bet['challenger']; ?>:</a></b>  <? echo $bet['num_votes_challenger'];	
					
				}
			else
				{
					?>You have found an error.  Congratulations.  Please contact mctk@koutouki.org about this error.  You'll win a prize! There is an error in the database with bet #<?
					echo $_GET['id'];
				
				}
			
		}
	if($bet['anonymous']=='yes')
		{
			echo "<br/><b>Anonymous debate.</b>";
		}
	?>
	<div style="clear:left;"></div>
	</div>
   <div class="bet_listing_descent">
	 <div class="bet_listing_title_descent">
     <?
	 echo "<div class=\"fl\"><b class=\"thick\">{$bet['title']}</b></div><div class=\"ar\"><b class=\"wager\">{$bet['wager']}</b></div>";
	 ?> 
	 </div>
	 <?
	 if($bet['status']=='expired')
		{
			?>
			<div class="bet_content_descent">
			<?
		}
	 else if($bet['creator'])
		{
			?>
			<div class="bet_content_descent">
			<?
		}
	else
		{
			?>
			<div class="bet_content_descent">
			<?
		}
	 if($bet['claim'])
		{
			echo $bet['claim'];
			?><br /><br/><?
		}
	?>
	 <div class="ar note">
	 <? 
	if($bet['creator'])
		{
			if($bet['anonymous']=='yes')
				{
					echo "Anonymously proposed.";
				}
			else
				{
					echo "Proposed by: {$bet['creator']}";
				}
		}
	 else
		{
			echo $bet['owner_shown']; 
		}
		?>
	 </div>
	 </div>
	 </div>
	 
	 <?
/*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/
 
 /*  Layout of this section:
 
 1.  print arguments
 2.  print vote/response box
     A.  if owner/challenger, print response box
     B.  else print vote box
          1. if Dispute
              a.  if logged in, print buttons
              b.  if not logged, print sign up message
          2.  if resolved, print results
 3.  print comments.		  
 
 */
 
 
  //grab the list of arguments
	$argument_number = 0;
	$arguments = db_get_arguments($bet['id']);
	if($arguments)
		{

			//print each argument
   
			foreach($arguments as $argument)
				{
					
					//set $speaker as owner or challenger
					if($argument['owner']==$bet['owner'])
						{
							$speaker = 'owner';
							//hide argument owner
							$argument['owner'] = $bet['owner_shown'];
						}
					else if($argument['owner']==$bet['challenger'])
						{
							$speaker = 'challenger';
							//hide argument owner
							$argument['owner'] = $bet['challenger_shown'];
						}
					else 
						{
						    echo $argument['owner'];
							echo '<br>';
							echo $bet['challenger'];
							die('<br />Error: argument not owned by bet owner or bet challenger.  This comment has been incorrectly classified.');
						}
		
/*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/

					?>
					<div class="dispute_listing border_<? echo $speaker; ?>">
					<div class="dispute_listing_title ar fr">
					<font class="info"><?echo $argument_number;?></font>
					</div>
					<div class="dispute_content ">
					<? echo $argument['content']; ?>
					<br />
					<div class="ar note"><?
					echo $argument['owner'];
					echo "<br/>".$argument['time'];
					?></div>
					</div>
					</div>
					<?
					$argument_number++;
/*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/	
				}//close foreach
		}//close if argument_list

/*

OUTPUT THE APPROPRIATE RESPONSE MECHANISMS:
if we don't give a sorry message, and we don't output response box, output vote buttons.

All if's are handled within.

*/

//Sorry messages include NOT outputting a response box for resolved debates
if(!output_response_box_sorry_message($bet))
	{

		//our debate is unresolved.  if we don't output a response box, then we need to output vote buttons.
		if(!output_response_box_vote_buttons($bet))
			{
				output_response_box($bet);
			}
	}

		
  // after we've printed the arguments, if the argument is resolved, print the comments.
  //after comments are printed, allow users to add a comment
if($bet['status']=='resolved' || $bet['status']=='expired' || $bet['status']=='announcement')
    {
		//display comments header
		?>
		<div class="comment_header">
		comments
		</div>
		<?
		if($_SESSION['user_name'])
			{
				?>
				<div class="ar">
				<a href="descent.php?id=<?echo $bet['id']?>&replyto=0#response">Start new thread</a>
				</div>
				<?
			}
		else
			{
				?>
				<div class="ar">
				<a href="login.php">log in</a>
				</div>
				<?
			
			}
		
	   //grab the list of comments
		$were_there_comments = output_children_comments($bet['id'],0,0);

	

		//give login message
		if(!$_SESSION['user_name'])
			{
				?>
				<div class="response_box ac">
				You must be <a href="login.php">logged-in</a> to comment.<br /><br />
				Don't have an account?  <a href="register.php">Sign-up</a>
				</div>
				<?
			}
		else if($_GET['replyto']=='0')//show comment box
			{
					if($_POST['preview'])
						{
							?>
							<a name="preview"></a>
							<div class="comment_listing nest_level_0">
							<div class="comment_listing_title">
							<?
							//echo $comment['time'];
							?> 
							</div>
							<div class="comment_content border_comment">
							<? echo process_tags(stripslashes($_POST['content'])); ?>
							<br />
							<div class="ar note"><? echo $_SESSION['user_name'];?>
							<br/><? echo "time" ?>
							</div>
							</div>
							
							<?
						}
				?>
				<a name="response"></a>
				<div class="response_box">
				<form action="descent.php?id=<?echo $_GET['id']?>&replyto=0#preview" method="post">
				<textarea style="width:99%;" rows="10" name="content"><?
				if($_POST['preview'])
					{
						echo br2nl(process_tags(stripslashes($_POST['content'])));
					}?></textarea>
				<br />
				<div class="ar">
				<input type="submit" name="preview" value="   Preview   ">
				<input type="submit" name="add_comment" value="   Respond   ">
				</div>
				</form>
				<? output_allowed_tags();
				if($_POST['preview'])
					{?></div><?}
				if($_GET['fail'])
					{
						?>
						<br/>
						<div class="error_message">
						See that box there?  That's where you type stuff.
						</div>
						<?
					}
				?>
				</div>
				<?
			}
		if($were_there_comments)
		{
				?>
				<div class="ar">
				<a href="descent.php?id=<?echo $bet['id']?>&replyto=0#response">Start new thread</a>
				</div>
				<?
		}
	}//closes 'resolved' if
?>
<div style="text-align:center"><a href="#top">top</a></div>
</div>

<?    
}//close output_descent
