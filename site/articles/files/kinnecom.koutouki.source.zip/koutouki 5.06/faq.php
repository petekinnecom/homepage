<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_output.php");
/*************************************/
initiate_pagination_sequence('');
?>
<h2>Never Before Asked Questions</h2>

<b>How do I create a debate?</b><br/>
When you are logged in, on the menu on the right hand, under your avatar, you will see a link entitled <a href="place_bet.php">Propose debate</a>.<br/><br/>

<b>How do I debate?</b><br/>
When you have created a proposal, the description and wager amount will show up on the front page. When another user accepts your bet, you will find a reply box located at the bottom of the challenge screen. Fill this out, click respond, and smile, knowing that your challenger will kneel in tears upon reading your overwhelmingly enlightening argument.<br/><br/>

<b>How do I know when someone accepts my proposal?</b><br/>
An email will inform you of this.  You can enter or change your email address on your <a href="settings.php">settings</a> page.  If you choose not to enter an email, you will simply have to obsessively refresh the website.<br/><br/>

<b>How do I know you won't post my email all over the internets and/or sell it for thousands of dollars to some crazed internet marketing company operating out of Borgladeshi?</b><br/>
Your email won't ever be posted on any Koutouki page.  It will never be seen by any other users (or probably, by myself).  I have yet to make the acquaintance of <i>anyone</i> from Borgladeshi.<br/><br/>

<b>Won't these debates just go on forever?</b><br/>
Most debates can be argued for three days.  After that, users have one day to finish voting.<br/><br/>

<b>If I'm already outvoted, why keep arguing?</b><br/>
Users can vote at any time after the debate has started. They can also change their vote, so don't give up if you're currently outvoted.<br/><br/>

<b>Can I vote for myself multiple times?</b><br/>
Short answer: no.  Long answer: I hope not.  Really long answer: yes, but that's cheating.<br/><br/>

<b>I voted for an idiot!</b><br/>
You can change your vote at any point during the debate.<br/><br/>

<b>Can't people just cheat?</b><br/>
Ever heard of Operation O'Brien?<br/><br/>

<b>What's the difference between a proposal and a challenge?</b><br/>
<a href="javascript:openpopup('description/proposal.html')">Answer</a><br/><br/>
<br/><br/>

<b>I keep getting these annoying emails!  -or-  Emails?  What emails?</b><br/>
Your email preferences can be changed on your "Settings" page.<br/><br/>

<b>Why does your design suck so much?</b><br/>
Sorry to have offended your refined taste.  I can play pretty songs on my guitar, though.<br/><br/>

<b>Should I?  Shouldn't I?</b><br/>
Do it.  And let the English see you do it.<br/><br/>

<b>I hate Koutouki and I hate all of you!</b><br/>
<a href="http://pquusczch.com/hello.html">Click here</a>, then.
<?output_footer();?>