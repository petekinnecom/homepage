<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_register.php");
include("f_output.php");
/*************************************/

initiate_pagination_sequence();
// if we have posted data, process the request

 if(isset($_POST['subjoin']))
 {
  if(register_user())
    {
	 //registration success, redirect to login with newuser message
	 die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?when_I_left_you_I_was_but_a_learner_now_I_am_the_master=only_a_master_of_evil_darth\">");
    }
  else
  {
   //Entered info was valid, but there was a database error.
   ?>
   <h1>Registration Failed</h1>
<p>Jumpin' Jehosephat!  I couldn't register the name <b><? echo $_POST['user']; ?></b>.  I think that the database is indisposed at this moment.  Actually, I could be programmed incorrectly. I'm just a computer after all.<p>
You could always <a href="register.php">try again</a>.
  <?
    } //close else line 19
  } //close if line 14
  
  
else
{  //we don't have posted info, print registration page with possible failure messages.
?>


<div style="text-align:center;">
<h1>
<?php
if($_GET['when_I_left_you_I_was_but_a_learner_now_I_am_the_master'])
	{//freshly registered
		?>
		Now you can log-in.  ------>
		</div>
		<?
	}
else
{ //display the normal page

	if(!$_GET['fail'])
	  {
	  echo 'Sign up.';
	  }
	else
	  {
	  echo 'Stay focused.';
	  }
	?>
	  </h1>
	</center>
	<form action="register.php" method="post">
	<table align="center" border="0" cellspacing="0" cellpadding="3">
	<tr>
	<td>
	<?php
	   if($_GET['fail']<1 && $_GET['fail']>0)
	     {
	      echo '<b class="orange">Username:</b>';
	     }
	   else
	     {
	      echo "Username:";
	     }
	?>

	</td>

	<td><input type="text" name="user" maxlength="16" value=<? echo "\"{$_GET['usrnm']}\""; ?>></td></tr>
	<tr>
	<td>
	<?php
	   if($_GET['fail']>1 && $_GET['fail']<2)
	     {
	      echo '<b class="orange">Password:</b>';
	     }
	   else
	     {
	      echo "Password:";
	     }
	?>
	</td>

	<td><input type="password" name="pass" maxlength="30"></td></tr>
	<tr>
	<td>
	<?php
	   if($_GET['fail']>2 && $_GET['fail']<3)
	     {
	      echo '<b class="orange">Confirm password:</b>';
	     }
	   else
	     {
	      echo "Confirm password:";
	     }
	?></td>
	<td><input type="password" name="pass2" maxlength="30"></td></tr>
	<tr>
	<td><?php
	   if($_GET['fail']>3 && $_GET['fail']<4)
	     {
	      echo '<b class="orange">email: (optional)</b>';
	     }
	   else
	     {
	      echo "email: (optional)";
	     }
	?></td>
	<td><input type="text" name="email" maxlength="30" value=<? echo "\"{$_GET['email']}\""; ?>></td></tr>
	<tr><td colspan="2" align="left">

	<font color="#FF6633">
	<?php
	   if($_GET['fail']==0.1)
	     {
	      echo 'Please enter a username';
	     }
	    if($_GET['fail']==0.2)
	     {
	      echo 'Unfortunately, your username contained an invalid character.  I forgive you, though.';
	     }
	    if($_GET['fail']==0.3)
	     {
	      echo 'Usernames can be no longer than 16 characters';
	     }
	    if($_GET['fail']==0.4)
	     {
	      echo 'This name has already been taken.  Have you considered Piacla_Machaka?';
	     }
	    if($_GET['fail']==0.5)
	     {
	      echo 'Only numbers and letters are allowed.  Otherwise my programs fail, my ram melts and my motherboard explodes.';
	     }
	    if($_GET['fail']==1.1)
	     {
	      echo 'Please enter a password.';
	     }
	    if($_GET['fail']==1.2)
	     {
	      echo 'Your passwords didn\'t match.';
	     }
	if($_GET['fail']==2.1)
	     {
	      echo 'Please confirm your password';
	     }
	if($_GET['fail']==3.1)
	     {
	      echo 'Your email address was invalid.';
	     }
	?>
	</font></td></tr>
	<tr><td colspan="2" align="right"><input type="submit" name="subjoin" value="Register">
	</table>
	</form>
	<br/>
	</div>
	Email will only be used to send you auto-updates regarding your postings.  If I'm lying you can have all my base.
<?
}


} //close else
output_footer();
?>
