<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");

include("f_output.php");
/*************************************/
output_header('profile.css');
if(!$_GET['user'])
	{
		die("<meta http-equiv=\"Refresh\" content=\"0;url=rankings.php\">");
	}
else
	{

		$user = $_GET['user'];
		$data = db_get_user_stats($_GET['user']);

		if(strtolower($user)=='socrates')
			$data['age'] = '2453';
		else if(strtolower($user)=='plato')
			$data['age'] = '2443';
		else if(strtolower($user)=='plebhead')
			$data['age'] = '2519';
		
		?><div id="right_content_box">
		<div id="right_menu" style="text-align:center;">
		<center>
		<?
		output_avatar($data['username']);
		echo $data['username'];
		?></center>
		<br/>
		<div class="note"><?
		echo "Sex: ".$data['sex'];
		?><br/><?
		echo "Age:  ".$data['age'];
		?><br/><?
		echo $data['location'];
		?><br/>
		<?if($data['website']){?><a href="<?echo $data['website']?>">website</a><?}?>

		</div>
		<div style="clear:both;"></div>
		</div>
		<br/>
		<?if($_SESSION['user_name'])
			{
				?><div style="text-align:center"><a href="edit_profile.php">Edit your profile.</a></div><?
			}?>
		</div>
		
		
		<?////////////////////////////////////left Content////////////////////////////////////////////?>
		
		
		<div id="left_content_box">
		<?
		if($data['description'])
			{
				?>
				<div class="description_box">
				<b><?echo $data['username']?> says:</b> 
				<?
				echo $data['description'];
				?>
				</div>
				<?
			}
		if($data['email']!='private_user')
		{
			if($_SESSION['user_name']==$_GET['user'])
				{
					?>
					<div class="ar"><a href="edit_profile.php">Edit your profile!</a></div><br/>
					<?
				}
			?>
			<div class="stat_box">
			<font class="note">member number:</font> <?if($data['adj_id'])echo $data['adj_id'];else echo '0';?> <br/>
			<font class="note">member since </font> <?echo $data['member_since'];?><br/>
			<br/>
			<font class="note">site rank: </font><?if($data['point_rank'])echo $data['point_rank'];else echo '0';?> 
			<br/>
			<font class="note">luminosity:</font> <?if($data['luminosity'])echo $data['points_capital'];else echo '0';?> <br/>
			<br/>
			
			<?if($data['points_wagered'])echo $data['points_wagered'];else echo '0';?> <font class="note">lumens wagered</font><br/>
			<?if($data['points_won'])echo $data['points_won'];else echo '0';?> <font class="note">lumens returned</font><br/>
			
			<?
			echo $data['earnings_percentage'];
			?>% <font class="note">earnings</font><br/>
			<br/>
			<?
			
			if($data['biggest_wager_won_id'])
				{?>
					<font class="note">largest win:</font> <a href="descent.php?id=<?echo $data['biggest_wager_won_id']?>"><?echo $data['biggest_wager_won']?></a> <br/>
				<?}
			if($data['biggest_wager_lost_id'])
				{?>
					<font class="note">largest loss:</font> <a href="descent.php?id=<?echo $data['biggest_wager_lost_id']?>"><?echo $data['biggest_wager_lost']?></a> <br/>
				<?}?>
				
			<br/>

			<?if($data['num_debates'])echo $data['num_debates'];else echo '0';?> <font class="note">debates</font>

			<br/>
			<?if($data['num_debates_won'])echo $data['num_debates_won'];else echo '0';?> <font class="note">debates won</font>
			<br/>
			<?if($data['debate_win_percentage'])echo $data['debate_win_percentage'];else echo '0';?>% <font class="note">win percentage</font><br/>
			<br/>
			<?if($data['num_arguments'])echo $data['num_arguments'];else echo '0';?> <font class="note">arguments made</font>
			<br/>



			<?if($data['votes_for'])echo $data['votes_for'];else echo '0';?> <font class="note">votes for</font>

			<br/>
			<?if($data['votes_against'])echo $data['votes_against'];else echo '0';?> <font class="note">votes against</font><br/>

			<?if($data['votes_for_percentage'])echo $data['votes_for_percentage'];else echo '0';?>% <font class="note">votes for</font><br/>
			<br/>
			<?if($data['votes_cast'])echo $data['votes_cast'];else echo '0';?> <font class="note">votes cast</font>
			<br/>
			<?if($data['num_comments'])echo $data['num_comments'];else echo '0';?> <font class="note">comments made</font>
			<br/>
			<br/>
			<a href="/?filter_user=<?echo $_GET['user']?>">All debates by this user</a>
			</div>
			<?
		}
	output_footer();
}	