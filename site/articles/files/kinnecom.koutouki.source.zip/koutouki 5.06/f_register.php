<?

function check_email($email)
{
   //make sure that we MAY have an email
   
   return (eregi("^[a-zA-Z0-9]+[_a-zA-Z0-9-]*(\.[_a-z0-9-]+)*@[a-z0-9]+(-[a-z0-9]+)*(\.[a-z0-9-]+)*(\.[a-z]{2,4})$",$email));

}

function register_user()
{
/*

This function will process the data posted to register.php.  If the username, password, or email are invalid, it will die with a refresh to register using GET error messages.  Otherwise, it will return true.  If it returns false, it means that all posted fields were valid, but there was a database error.

*/


 // Make sure all fields were entered and are valid 
 
   if(!$_POST['user']){
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=0.1&email={$_POST['email']}\">");
   }  
   
   if(ereg(" ",$_POST['user']))
   {
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=0.2&usrnm={$_POST['user']}&email={$_POST['email']}\">");
   }  
   
 if(!$_POST['pass']){
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=1.1&usrnm={$_POST['user']}&email={$_POST['email']}\">");
   }  
   
 if(!$_POST['pass2']){
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=2.1&usrnm={$_POST['user']}&email={$_POST['email']}\">");
   }
   
 if($_POST['email'] && !check_email($_POST['email'])){
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=3.1&usrnm={$_POST['user']}&email={$_POST['email']}\">");
   }
   
   if($_POST['pass'] != $_POST['pass2'])
     { 
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=1.1&usrnm={$_POST['user']}&email={$_POST['email']}\">");
     }
	 
   /* Spruce up username, check length */
   $_POST['user'] = trim($_POST['user']);
   if(strlen($_POST['user']) > 16){
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=0.3&email={$_POST['email']}\">");
   }

   /* Check if username is already in use */
   if(db_username_availability($_POST['user'])){
      die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=0.4&email={$_POST['email']}\">");
   }
	if(ereg("[^A-Za-z0-9]", $_POST['user']))
		{
		die("<meta http-equiv=\"Refresh\" content=\"0;url=register.php?fail=0.5&email={$_POST['email']}\">");
		}
   //if we've made it this far, we can add the account to the database.  Return true/false
   
   $md5pass = md5($_POST['pass']);
   return db_add_user($_POST['user'], $md5pass,$_POST['email']);
   
}
