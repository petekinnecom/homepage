<?/*
	
	Maintenance:
	
	updates user stats based on database info.
	
	
	$data = db_get_user_info($_GET['user']);
	//this function will query the database a few times and count how many times our hero's name pops up.
	$query = "SELECT id FROM arguments WHERE owner='$username'";
	$result = mysql_query($query);
	$data['num_arguments'] = mysql_numrows($result);
	
	$query = "SELECT id FROM comments WHERE owner='$username'";
	$result = mysql_query($query);
	$data['num_comments'] = mysql_numrows($result);
	

	
	//this must come before general wager info, because we don't query for losses.  We use this info to help us figure out biggest loss.
	$query = "SELECT wager,id,victor,owner,challenger FROM bets WHERE (owner='$username' OR challenger='$username') AND status='resolved'";
	$result = mysql_query($query);
	$data['num_debates'] = mysql_numrows($result);
	
	$data['num_wins'] = 0;
	$data['total_wagered'] = 0;
	$data['biggest_wager_won'] = 0;
	$data['biggest_wager_lost'] = 0;
	$data['total_wagered_won'] = 0;
	while($stuff = mysql_fetch_array($result))
		{
			$data['total_wagered'] = $data['total_wagered'] + $stuff['wager'];
			
			if(($stuff['owner']==$username && $stuff['victor']=='owner') || ($stuff['challenger']==$username && $stuff['victor']=='challenger'))
				{
					//This is a bet this user has won
					$data['num_wins']++;
					$data['total_wagered_won'] = $data['total_wagered_won'] + $stuff['wager'];
					if($stuff['wager']>$data['biggest_wager_won'])
						{
							$data['biggest_wager_won'] = $stuff['wager'];
							$data['biggest_wager_won_id'] = $stuff['id'];
						}
				}
			else
				{
					//the user has lost this bet
					if($stuff['wager']>$data['biggest_wager_lost'])
						{
							$data['biggest_wager_lost'] = $stuff['wager'];
							$data['biggest_wager_lost_id'] = $stuff['id'];
						}
				}
		}

			
	$points = $data['points_capital'];
	$query = "SELECT id FROM users WHERE points_capital > '$points' AND email!='private_user'";
	$result = mysql_query($query);
	$data['point_rank'] = mysql_numrows($result) + 1;

	$data['win_percentage'] = percent($data['num_wins'],$data['num_debates']);
	$data['votes_for_percentage'] = percent($data['votes_for'],$data['votes_for']+$data['votes_against']);
	
	$total_won=$data['total_wagered_won']*2;
	$earnings_percentage = percent($total_won - $data['total_wagered'], $data['total_wagered']);
	$query = "UPDATE users SET
	votes_for_percentage='{$data['votes_for_percentage']}',
	points_wagered = '{$data['total_wagered']}',
	points_won = '$total_won',
	num_debates='{$data['num_debates']}',
	num_debates_won='{$data['num_wins']}',
	debate_win_percentage='{$data['win_percentage']}',
	earnings_percentage='$earnings_percentage'	
	WHERE username='$username'";
	if(!mysql_query($query))
		{
			die("uh-oh: <br/>".mysql_error());
		}
	
	return $data;
	
*/

	/*
	
	USED TO COUNT VOTES
	
	//get all bets
	$query = "SELECT id FROM bets WHERE id!='0'";
	$result = mysql_query($query);
	While($data = mysql_fetch_array($result))
        {
			$bet = db_get_bet($data['id']);
			foreach($bet['voters_owner'] as $voter)
			    {
					if($voter!='' && $voter!=',')
						{			
							$query = "UPDATE users SET votes_cast=votes_cast+1 WHERE username='$voter'";
							mysql_query($query);
						}
				}

			foreach($bet['voters_challenger'] as $voter)
			    {
					if($voter!='' && $voter!=',')
						{			
							$query = "UPDATE users SET votes_cast=votes_cast+1 WHERE username='$voter'";
							mysql_query($query);
						}
				}
	 
		}
	*/
	
		/*
	
	SCORE UPKEEP!
	
	$query = "UPDATE users SET points='1000', points_capital='1000' WHERE id!=0";
	if(!mysql_query($query))
		die('stopped: a');

	
	$query = "SELECT wager,owner,challenger,victor,status,action FROM bets";
	$result = mysql_query($query);
	while($data = mysql_fetch_array($result))
		{
		
			$wager = $data['wager'];
			if($data['status']=='dispute')
				{
					$query = "UPDATE users SET points=points-'$wager' WHERE username='{$data['owner']}'";
					if(!mysql_query($query))
						die('stopped: b');
					$query = "UPDATE users SET points=points-'$wager' WHERE username='{$data['challenger']}'";
					if(!mysql_query($query))
						die('stopped: c');
				}
			if($data['status']=='resolved')
				{
					if($data['victor']=='owner')
						{
							//$tmp = db_get_user_data($data['owner');
							//$points = $data['wager'] + $tmp['points'];
							$owner = $data['owner'];
							$query = "UPDATE users SET points=points+'$wager', points_capital=points_capital+'$wager' WHERE username='$owner'";
							if(!mysql_query($query))
								die('stopped: d');

							$query = "UPDATE users SET points=points-$wager, points_capital=points_capital-'$wager' WHERE username='{$data['challenger']}'";
							if(!mysql_query($query))
								die('stopped: e');
						}
					else
						{
							$query = "UPDATE users SET points=points-$wager, points_capital=points_capital-'$wager' WHERE username='{$data['owner']}'";
							if(!mysql_query($query))
								die('stopped: f');

							$query = "UPDATE users SET points=points+$wager, points_capital=points_capital+'$wager' WHERE username='{$data['challenger']}'";
							if(!mysql_query($query))
								die('stopped: g');						

						
						}
					
					
				
				}
	
		
		}
	
	*/