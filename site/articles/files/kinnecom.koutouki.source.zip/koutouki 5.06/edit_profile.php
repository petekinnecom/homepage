<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_output.php");
/*************************************/
initiate_pagination_sequence();
function validate_date_info($year, $month, $day)
{
// ----------------------------------------------------------------------

// THANKS VROOM.NET!

// ----------------------------------------------------------------------

   // For conversion of month strings into numeric values
   // ---------------------------------------------------
   $mth = array();
   $mth[ 1] = "jan";
   $mth[ 2] = "feb";
   $mth[ 3] = "mar";
   $mth[ 4] = "apr";
   $mth[ 5] = "may";
   $mth[ 6] = "jun";
   $mth[ 7] = "jul";
   $mth[ 8] = "aug";
   $mth[ 9] = "sep";
   $mth[10] = "oct";
   $mth[11] = "nov";
   $mth[12] = "dec";
   
   // Standard days per month.  Ignoring leap years
   // ---------------------------------------------
   $dpm[ 1] = 31;
   $dpm[ 2] = 28;
   $dpm[ 3] = 31;
   $dpm[ 4] = 30;   
   $dpm[ 5] = 31;   
   $dpm[ 6] = 30;   
   $dpm[ 7] = 31;   
   $dpm[ 8] = 31;   
   $dpm[ 9] = 30;   
   $dpm[10] = 31;   
   $dpm[11] = 30;   
   $dpm[12] = 31;   

      if (strlen($year)>4 || strlen($month)!=2 || strlen($day)!=2 )
      {
         return 0;
      }
      
      // Sanity checks on year
      // ---------------------
      $len = strspn($year,"0123456789");
      if ( strlen($year)!=$len )
      {
         return 0;
      }
      
      // Sanity checks on month
      // ----------------------
      $len = strspn($month,"0123456789");
      if ( strlen($month)!=$len )
      {
         return 0;
      }
      if ( $month<1 || $month>12 )
      {
         return 0;
      }

      // Correct leap year determination and check if february
      // -----------------------------------------------------
      if ( $month==2 )
      {
         if ( $year % 4 != 0 )
            $dpm[2] = 28;
         else if ( $year % 400 == 0 )
            $dpm[2] = 29;
         else if ( $year % 100 == 0 )
            $dpm[2] = 28;
         else
            $dpm[2] = 29;
      }
               
      // Sanity checks on day
      // --------------------
      $len = strspn($day,"0123456789");
      if ( strlen($day)!=$len )
      {
         return 0;
      }
      if ( $day<1 || $day>$dpm[(int)$month] )
      {
         return 0;
      }

      // The date fit into a supported format and all known sanity
      // checks were passed, so pass back the date as requested.  Note
      // that timestamps are only good back 01-Jan-1970, so previous
      // dates, such as birthdays, should be sanity checked only.
      // -------------------------------------------------------------
      return sprintf("%04d-%02d-%02d",$year,$month,$day);
}


if($_POST)
{

	//process stuff
	$birthday = validate_date_info($_POST['year'],$_POST['month'],$_POST['day']);
	if($birthday == 0)
		{
			$birthday = '';
		}
	
	$location = $_POST['location'];
	$website = $_POST['website'];
	$description = $_POST['description'];
	if($_SESSION['user_name'])
		db_update_user_profile($birthday, $sex, $location, $website, $description);
	/*	
	echo "bday=  ";
	echo $birthday;

	echo "<br>";
	echo $location;
	echo "<br>";
	echo $website;
	echo "<br>";
	echo $description;
	echo "<br>";
	*/
	die("<meta http-equiv=\"Refresh\" content=\"0;url=profile.php?user={$_SESSION['user_name']}\">");
}

$info = db_get_user_info($_SESSION['user_name']);
if(!$info)
	{die('You know you shouldn\'t be here if you\'re not logged-in!');}

?>
<form name="profile_form" action="edit_profile.php" method="POST">
<br/>
birthday (MM-DD-YYYY)
<br/>
<input type="text" name="month" maxlength="2" style="width:2em;" value="<?echo $info['birth_month']?>">
<input type="text" name="day" maxlength="2" style="width:2em;" value="<?echo $info['birth_day']?>">
<input type="text" name="year" maxlength="4" style="width:4em;" value="<?echo $info['birth_year']?>">
<br/><br/>
Sex
<br/>
<select name="sex">
<option value="M" <?if($info['sex']=='M') echo "selected" ?>>M</option>
<option value="F" <?if($info['sex']=='F') echo "selected" ?>>F</option>
<option value="?" <?if($info['sex']=='?') echo "selected" ?>>?</option>
<option value="!" <?if($info['sex']=='!') echo "selected" ?>>!</option>
</select>
<br/><br/>
location
<br/>
<input type="text" name="location" maxlength="30" value="<? echo $info['location'];?>">
<br/><br/>
website
<br/>
<input type="text" name="website" maxlength="120" style="width:90%;" value="<? echo $info['website'];?>">
<br/><br/>
What do you have to say for yourself?
<br/>

<textarea style="width:90%;" rows="10" name="description"><?
echo br2nl($info['description']);
?></textarea>
<br/>
<input type="submit" name="update" value="  Update  ">
<?output_footer();?>