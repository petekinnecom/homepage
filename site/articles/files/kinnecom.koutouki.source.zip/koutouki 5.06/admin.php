<?
session_start();
include('f_database.php');
if($_SESSION['user_name']!='mctk')
	{die('nope: '.$_SESSION['user_name']);}
else
{
	if($_POST['month'])
		{
			db_init_month();
			echo '<b>done!</b><br/>';
		}
	else
		{
			echo '<b>incorrect month entered</b><br/>';
		}
	?>
	<br/>
	<form action="" method="post">
	<input type="text" name="month"><br/>
	<input type="submit" name="init" value="init month">
	<?
}