<?php
/*
*	This is the small iframe that is called by edToolbar
*	It checks the filetype, lowercases and underscores
*	the filename and moves it to /upload
*	then calls edInsert img or whatever it is
*	to insert the image code.
*
*
*/

function approve_upload($filename)
{
	/* check filetype */
	if (($pos = strrpos($filename, ".")) === FALSE)
		return "<b>Error <i>: filename must have an extension</b>";

	else 
		{
		    //check for duplicates
			$dir    = 'upload';
			$directory = opendir($dir);
			$nextfile = readdir($directory);
			while($nextfile)
				{
					if($nextfile == $filename)
						{
							return "<p><b>Error<i>: duplicate filename</b>";
						}
					$nextfile = readdir($directory);
				}
			$extension = substr($filename, $pos + 1);
		    $extension = strtolower($extension); 
			switch ($extension) 
			{
			    case jpg:
			    case bmp:
			    case png:
			    case gif:
			    case tif:
			    case tga:
			    case ico:
			    case mp3:
			    case ogg:
			    case wav:
			    case avi:
			    case mov:
			    case mpg:
			    case wmv:
			    case wma:
			    case zip:
					return 'approved';
			    default:    
					return "<p><b>Error <i>: invalid filetype<p></b>";
			    break;
			}

     }

/* done check filetype */
}

if($_FILES['image']['name'])
{

	$ftmp = $_FILES['image']['tmp_name'];
	$loweredfilename= strtolower($_FILES['image']['name']); 
	$loweredfilename = str_replace(" ", "_", $loweredfilename);
	$fname = '/home/pquusczc/public_html/koutouki/upload/'.$loweredfilename;
	$webname = 'upload/'.$loweredfilename;
	
	
	$approved = approve_upload($_FILES['image']['name']);
	if($approved=='approved')
		{
			if(move_uploaded_file($ftmp, $fname))
				{
					echo 'Uploaded successfully.  Upload another?';
					?><script src="files/js_quicktags.js" type="text/javascript"></script>
					<script>edInsertImage(window.parent.document.getElementById('content'), '<?echo $webname?>');</script><?
					mail('mctk@koutouki.org', 'koutouki: image uploaded', 'check it http://koutouki.org/upload', null,'-f koutouki@koutouki.org');
				}
			else
				{
					echo 'Error: unknown error.';
				}
		}
	else
		{
			echo $approved;
		}
}
else
{
	echo "Upload an image";
}
?><html><head>
<script>
function upload()
{
		document.iform.submit();
	//document.getElementById('form').style.visibility="hidden";
	document.getElementById('form').innerHTML = '<font style="font-size:50%">This message is intended to entertain while your upload is processed.  I hope you\'ve enjoyed reading it as much as I\'ve enjoyed typing it.  Everyone\'s a winner!</font>';
	document.getElementById('stuff').style.visibility="visible";

}
</script>
<style>
#file {
	width: 100%;
}
</style>
<head><body>
<div id="stuff" style="visibility:hidden"><img src='files/upload_indicator.gif'></div>
<div id="form">
<form id="iform" name="iform" action="insert_upload.php" method="post" enctype="multipart/form-data">
<input id="file" type="file" name="image" onchange="upload()"/></div>


</form>
</html>