<?
function output_index_javascript()
{
	?><script>
	function j_show_bet_stats(bet_id)
	{
		divname = "stats_box_" + bet_id;
		div = document.getElementById(divname);
		
		if(div.style.height == '10px')
		{
			//this is the first time it's opened. 
			div.innerHTML = '<iframe src="bet_stats.php?id='+bet_id+'" frameborder="0" style="width:100%;height:200px;"></iframe>';
			div.style.height = '200px';
			div.style.background = '#f6f6f6';
			div.style.borderTop = '2px solid #FFA62B';
			div.style.display = 'block';
		}
		else if(div.style.display == 'block')
		{	
			div.style.display = 'none';
		}
		else
		{
			div.style.display = 'block';
		}
	}
</script>
<?
}



function output_bet_link($bet)
{
			?>
			<div class="outside_<?echo $bet['status']?>">
			<div class="bet_entry color_<?echo $bet['status']?>" >
			<div class="bet_entry_wager" style="font-size:200%;"><span style="cursor: pointer;" onclick="j_show_bet_stats(<?echo $bet['id']?>)"><? echo $bet['wager'] ?></span></div>
			<div class="bet_entry_title"><? echo $bet['title'] ?></div>
			<div class="bet_entry_info"><a href="descent.php?id=<?echo $bet['id']?>" class="bet_list">
			<?
			if($bet['status']=='resolved' || $bet['status']=='expired' || $bet['status']=='announcement')
				{
					echo $bet['num_comments'] . " comments";
				}
			else if($bet['status']=='open')
				{
					if($bet['anonymous']=='yes')
						echo "Anonymous";
					else if($bet['action']=='personal_challenge')
						echo $bet['owner'] . " challenges ".$bet['challenger'];
					else if($bet['owner'])
						echo "by: ".$bet['owner'];
					else
						echo "by: ".$bet['creator'];

				}
			else if($bet['status']=='dispute')
				{
					echo $bet['time_remaining_frontpage'];
				}
			else
				{
					echo "wha?";
				}
			?><br/>
			View debate
			</a>

			</div>
			<div style="clear:left;"></div>
			<div id="stats_box_<?echo $bet['id']?>" style="display:none;height:10px">
			</div>
			</div>
			</div>

		<?

}
function output_bet_listing_by_type($type,$limit)
{
	$bet_list = db_get_bet_list($type);
	if(!$bet_list)
		{
			echo "";
		}
	
	else
		{
		
			$count=0;
			foreach($bet_list as $bet_id)
				{
					if($count<$limit)
						{
							$bet = db_get_bet($bet_id);
					 
/*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/	
							
							output_bet_link($bet);
							$count++;
						}
/*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/     
				} //close foreach
		} //close else
		
	/*this part is silliness.  Make a nice statement for the VIEW ALL... stuff */
	if($type=='dispute')
		$nice = 'disputes.';
	else if ($type=='resolved')
		$nice = 'resolved debates.';
	else if ($type=='open')
		$nice = 'open debates.';
	if($type!='announcement')
		{
			if($count>=$limit)
				{
					?><div class="ar"><a href="/?filter_status=<?echo $type?>" class="bet_list">View all <?echo $nice?></a></div><?
				}
			else
				{
					?><div class="inactive ar bet_list">Viewing all <?echo $nice?></div><?
				}
		}
	?><br/><?

}

function output_requested_bets()
 {
  
	$bet_list = db_get_bet_list('get');
	if(!$bet_list)
		{
			echo "<br/>These aren't the droids you're looking for.";
		}
	
	else
		{
		
	// Not fully indented for the sake of my SANITY.	
	foreach($bet_list as $bet_id)
		{
			$bet = db_get_bet($bet_id);
	 
/*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/	
			output_bet_link($bet);	 
/*-----------------------------------------------------FORMATTING---------------------------------------------------------------------------------*/     
	 
	} //close foreach
	}//close else
	
	?><div class = "fl"><?
	$get_link = form_get_link('page');
	if($_GET['page']>=1)
		{
			$previous = $_GET['page'] - 1;
			echo '<a href="/'.$get_link.'page='.$previous.'">previous</a>';
		}
	?></div><?
	
	
	$next = $_GET['page'] + 1;
	?>
	<div class = "ar">
	<?
	echo '<a href="/'.$get_link.'page='.$next.'">next</a>';
	?>
	</div>
	<?

	
	?> </div><?
}//end output_bets


function output_search_results()
{
	?><font class="note">Searched for:  <b><?echo $_GET['query']?></b></font><?
	$results = db_get_search_results();
	if(!$results)
		echo "No results found.  (Words less than 4 letters are omitted.)";
	else
		{
			$results = array_unique($results);
			foreach($results as $result)
				{
					$bet = db_get_bet($result);
					if($bet)
						output_bet_link($bet);
				}
		}
}