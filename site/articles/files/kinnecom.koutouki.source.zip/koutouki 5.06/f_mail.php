<?php
function actionEmail($message)
{
// In case any of our lines are larger than 70 characters, we should use wordwrap()
$message = wordwrap($message, 70);

// Send
mail('mctk@koutouki.org', 'koutouki: action', $message, null,'-f mctk@koutouki.org');

}

function send_mail($recipient, $type, $data)
{
//data, here, is either the $bet or the $comment data.


///////////////////////////////////////////////////////////NOT DONE///////////////////////////////////////////////////////////////


	//recipient is the username of the intended recipient.
	//before we construct the email, we need to access his/her user mysql entry and retrieve his/her email.
	$send=0;
	$email = db_get_user_email($recipient);
	if($email['email'])
	{
		//if we have an anonymous bet, we need to hide the name
		if($data['anonymous']=='yes')
			$name = 'Someone';
		else
			$name = $_SESSION['user_name'];
		
		
		if($email['email_options']=='all' || $email['email_options']=='bet_info')
		//form the appropriate message
			{
				if($type == 'challenge')
					{
						$subject = 'koutouki: bet challenged - '.$data['id'];
						$message = $name . " has challenged your bet: "  . $data['title'] . "\n\nhttp://koutouki.org/descent.php?id=". $data['id'];;
						}
				else if($type == 'proposal_accepted')
					{
						$subject = 'koutouki: proposal accepted - '.$data['id'];
						$message = $name . " has accepted your proposal: "  . $data['title'] . "\n\nhttp://koutouki.org/descent.php?id=". $data['id'];
					}	
				else if($type == 'win')
					{
						$subject = 'koutouki: results - '.$data['id'];
						$message = "You have won your bet:  " . $data['title'] . "\n\nCheck the results here: http://koutouki.org/descent.php?id=". $data['id'];
					}	
				else if($type == 'lose')
					{
						$subject = 'koutouki: results - '.$data['id'];
						$message = "You have lost your bet:  " . $data['title'] . "\n\nCheck the results here: http://koutouki.org/descent.php?id=". $data['id'];
					}
				else if($type == 'tied')
					{
						$subject = 'koutouki: debate tied - '.$data['id'];
						$message = "Your bet is tied!\n\nYou have 24 hours to make your closing arguments for your bet:  ".$data['title'] . "Go here to update: http://koutouki.org/descent.php?id=".$data['id'];
					}
				else if($type == 'resurrection')
					{
						$subject = 'koutouki: debate resurrection - '.$data['id'];
						$message = $data['challenger'] . " wishes to resurrect your bet:\n".$data['title']."\n\nPlease go here to accept or decline: http://koutouki.org/descent.php?id=". $data['id'];
					}
			}
		if($email['email_options']=='all' || $email['email_options']=='replies')
			{
				if($type == 'reply_argument')
					{
						$subject = 'koutouki: argument updated - '.$data['id'];
						$message = "Your argument \"" . $data['title'] . "\" has been replied to.\n\nCheck the debate here: http://koutouki.org/descent.php?id=". $data['id'];
					}
				else if($type == 'reply_comment')
					{
						$subject = 'koutouki: comment response - '.$data['id'];
						$message = "Someone has replied to your comment. \n\n Click here to see for yourself: \n \nhttp://koutouki.org/descent.php?id=".$data['id']."#".$data['parent'];
					
					}
				else if($type == 'reply_debate')
					{
						$subject = 'koutouki: comment response - '.$data['id'];
						$message = "Someone has replied to your debate: \"".$data['title']."\". \n\n Click here to see for yourself: \n \nhttp://koutouki.org/descent.php?id=".$data['id'];
					
					}
				else if($type == 'personal_challenge')
					{
						$subject = 'koutouki: personal challenge - '.$data['id'];
						$message = "{$data['owner']} has challenged you and you alone.\n\nCheck the details here: http://koutouki.org/descent.php?id=". $data['id']."\n\nRemember, your pride is on the line.";
					}

			}
		if($message){$send=1;}
		$message = $message . "\n\n\n\n-------------------------------------------------\nYou can change your email settings here: http://koutouki.org/settings.php";
		$message = wordwrap($message, 70);

		// Send
		if($send)
			{
				if(!mail($email['email'], $subject, $message, null,'-f koutouki@koutouki.org'))
					{
						die("failure: f_mail line 61");
					}
			}
	}		
///////////////////////////////////////////////////////////NOT DONE///////////////////////////////////////////////////////////////

}

?>
