<?php
/* Include Files *********************/
session_start();
include("f_database.php");
include("f_login.php");
include("f_output.php");
include("f_place_bet.php");
/*************************************/


?><script type="text/javascript">

//JK Popup Window Script (version 3.0)- By JavaScript Kit (http://www.javascriptkit.com)
//Visit JavaScriptKit.com for free JavaScripts
//This notice must stay intact for legal use

function openpopup(popurl){
var winpops=window.open(popurl,"","width=400,height=400,status,resizable")
}
</script>

<?
	output_header();
	output_sidebar();
	?><div id="left_content_box"><?
if($_POST['placebet'])
	{
		//if the submit button was pressed, process the data.  All error messages will be handled inside here
		add_bet();
	}
else
{
	//First handle the preview
	if($_POST['preview'])
		{
			if($_POST['type']=='proposal')
				{
					$wager = '<img src="files/koutouki_favicon.png">';
					$form_wager = '';
				}
			else if(!$_POST['wager'] )
				{
					$wager = '??';
					$form_wager = '';
				}
			else
				{
					$wager = (int) $_POST['wager'];
					$form_wager = $wager;
				}
			$claim = process_tags(stripslashes($_POST['claim']));
			$form_claim = br2nl($claim);
			$title = stripslashes($_POST['title']);
			$title = str_replace('<','&lt;',$title);
			$title = str_replace('>','&gt;',$title);
			$form_title= $title;
			if(!$title)
				{
					$title = "title goes here";
					$form_wager = '';
				}
				
			?>
			<div style="width:525px;margin:auto;">
			<div class="bet_listing_descent">
			<div class="bet_listing_title_descent">
			<?
			echo "<div class=\"fl\"><b class=\"thick\">{$title}</b></div><div class=\"ar\"><b class=\"wager\">{$wager}</b></div>";
			?> 
			</div>
			<div class="bet_content_descent">
			<?
			if($claim)
				{
					echo $claim;
					?><br /><br/><?
				}
			?>
			<div class="ar note">
			<? 
			if($_POST['anonymous'])
				$name = 'anonymous';
			else
				$name = $_SESSION['user_name'];
			if($_POST['type']=='proposal')
				{
					echo "Proposed by: $name";
				}
			else
				{
					echo $name; 
				}
			?>
			</div>
			</div>
			</div>
			</div>
			<?
		}

	/*
	Now, we need to make sure that the variables from preview are placed in text boxes. 
	but these variables could also be coming from GET for a denied "placebet".
	So, check if they're in GET.  If they are, make a replacement, otherwise, they're good.
	*/
	
	if($_GET['wager'])
		{
			$form_wager = $_GET['wager'];
		}
	if($_GET['title'])
		{
			$form_title = stripslashes(stripslashes($_GET['title']));
		}
	if($_GET['claim'])
		{
			$form_claim = stripslashes(stripslashes($_GET['claim']));
		}


	
	?>


<center>
<h1>Place your bet.</h1>
</center>
<form action="place_bet.php" method="post">

<?php
 if($_GET['fail']==1)
     {
      echo '<b class="orange">Wager:</b>';
     }
   else
     {
      echo "<b>Wager:</b> ";
     }
?>
&nbsp;&nbsp;
<input type="text" id="wager" name="wager" maxlength="6" size="6" value="<? echo $form_wager; ?>">
<p>
<?php
   if($_GET['fail']==5)
     {
      echo '<b class="orange">Title:</b>';
     }
   else
     {
      echo "<b>Title:</b>";
     }
?>

<br>

<input type="text" name="title" maxlength="75" size="60" value="<? echo $form_title; ?>">



<p>

<?php
   if($_GET['fail']==2)
     {
      echo '<b class="orange">Claim:</b>';
     }
   else
     {
      echo "<b>Claim:</b>";
     }
?>
<br>
<font class="caption">
A few sentences clarifying your bet.  <b>This can be left blank</b>

<p>
<? output_tag_buttons() ?>
<textarea rows="10" cols="65" name="claim" id="content">
<? echo $form_claim; ?>
</textarea>
<script type="text/javascript">var edCanvas = document.getElementById('content');var up_toggle = 1;</script>
Allowed tags: &lt;i&gt;, &lt;b&gt;, &lt;a&gt;, &lt;blockquote&gt;, &lt;ul&gt;, &lt;li&gt;.</font><br/><br/>
<input type="radio" name="type" value="proposal" onclick="document.getElementById('wager').disabled = true;document.getElementById('user_to_challenge').disabled = true;document.getElementById('anonymous').disabled = false;"<?
	if($_POST['type']=='proposal')
		{
			echo "checked";
		}
?>>
This is a proposal.<br/>
<input type="radio" name="type" value="challenge" onclick="document.getElementById('wager').disabled = false;document.getElementById('user_to_challenge').disabled = true;document.getElementById('anonymous').disabled = false;"<?
	if($_POST['type']=='challenge')
		{
			echo "checked";
		}
?>>This is a challenge.<br/>
<input type="radio" name="type" value="personal_challenge" onclick="document.getElementById('wager').disabled = false;document.getElementById('user_to_challenge').disabled = false;document.getElementById('anonymous').disabled = true;"<?
	if($_POST['type']=='personal_challenge')
		{
			echo "checked";
		}
?>>This is a personal challenge for <input id="user_to_challenge" type="text" name="user_to_challenge" maxlength="30" size="12" value="<?echo $_POST['user_to_challenge']?>" >.<br/>
<a href="javascript:openpopup('description/proposal.html')">What's the difference?</a>
<br/>
<br/>
<input type="checkbox" name="show_vote_counts" value="yes"
<?
	if($_POST['show_vote_counts']=='yes')
		{
			echo "checked";
		}
?>
> Show vote tallies during debate.
<br/>
<input id="anonymous" type="checkbox" name="anonymous" value="yes"
<?
	if($_POST['anonymous']=='yes')
		{
			echo "checked";
		}
?>
> <a href="javascript:openpopup('description/anonymous.html')">Anonymous</a> Debate<br/>
<select name="num_arguments_allowed">
	<option value="-1"<? if($_POST['num_arguments_allowed']==-1){echo 'selected';}?>>unlimited</option>
	<option value="1"<? if($_POST['num_arguments_allowed']==1){echo 'selected';}?>>1</option>
	<option value="2"<? if($_POST['num_arguments_allowed']==2){echo 'selected';}?>>2</option>
	<option value="3"<? if($_POST['num_arguments_allowed']==3){echo 'selected';}?>>3</option>
	<option value="4" <? if($_POST['num_arguments_allowed']==4){echo 'selected';}?>>4</option>
	<option value="5"<? if($_POST['num_arguments_allowed']==5){echo 'selected';}?>>5</option>
	<option value="17553"<? if($_POST['num_arguments_allowed']==17553){echo 'selected';}?>>17553</option>
</select> Arguments allowed for each side.<br/>
<p align="right">
<input type="submit" name="preview" value="   Preview   ">&nbsp;&nbsp;
<input type="submit" name="placebet" value="   Bet   ">
&nbsp;&nbsp;
</p>
</form>
<p>
<div class="error_message">
<?php
  if($_GET['fail']==1)
    {
     echo "You need to bet <i>something</i>";
    }
  if($_GET['fail']==2)
    {
     echo "I'm under the impression that you will never see this error message.  Now I'm really confused.";
    }
  if($_GET['fail']==3)
    {
     echo "You don't have that many lumens to wager.";
    }
  if($_GET['fail']==4)
    {
     echo "You aren't logged in!";
    }  
if($_GET['fail']==5)
    {
     echo "You aren't entitled to leave this untitled.";
    }
if($_GET['fail']==6)
    {
     echo "Claims are limited to 500 characters.  Condense.  Simplify.";
    }
if($_GET['fail']==7)
    {
     echo "&lt;apology&gt;&nbsp;Sorry, no tags in the title.&nbsp;&lt;/apology&gt;";
    }
if($_GET['fail']==9 || $_GET['fail']==8)
    {
     echo "Your wager must be a positive integer.";
    }
if($_GET['fail']==10)
    {
     echo "Please mark either challenge or proposal.";
    }
if($_GET['fail']==11)
    {
     echo "There is no such user.  I swear.  I checked.";
    }

?>
</div>
</div>
</center>
</div>
</html>
<?
}//closes else
?>