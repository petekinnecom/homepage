<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_output.php");
/*************************************/
initiate_pagination_sequence('profile.css');
?>
<b>Koutouki: enlighten the plebheads.</b><br/><br/>
The plebheads are witless fools.  At Koutouki, we dedicate ourselves to bringing logic and rational thought to the ignorant masses.  Take up the torch and argue for truth and enlightenment!<br/>
<br/>
Lumens (points) are awarded for winning debates.  Each debate is limited to two users.  The debaters make their wager and argue for their winnings.  The plebheads (other Koutouki users) decide the debate by voting for a winner.  <b>Prizes</b> (free stuff) are awarded at the end of each monthly competition for the <a href="rankings.php">most enlightening Koutoukian</a>.<br/>
<br/>
Most debates are argued for 3 days, then allow 1 day for the plebheads to read and vote.  On the front page you will find a listing of all current debates, marked with their wagered amount.  Debates are broken in to three categories:<br/>
<br/>
<b>Open</b> (green):  These are proposed topics for argument.  When you are logged in, you are free to make a wager and argue your point of view.  Debates stay on the front page for 3 days before they are sent to The Graveyard.<br/>
<br/>
<b>Disputed</b> (red):  These are topics currently being argued.  Read and vote for the most convincing argument.  Remember, <b>you can change your vote at any point during the debate</b>, so check back often for updates.<br/>
<br/>
<b>Resolved</b> (blue):  These are debates that have already been decided by vote.  You are free to comment on the results.<br/>
<br/>
<b>Expired</b> (grey):  Only found in <a href="/?filter_status=expired">The Graveyard</a>, these are proposals for debate that no one challenged.   If you find a topic that you would like to argue, you may resurrect the debate.<br/>
<br/>
No subject too grand.  No topic too trivial.  Join us.  Enlighten the plebheads!
<br/><br/>
mctk<br/>
Dec. 31, 2006

<?output_footer();?>