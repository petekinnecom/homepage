<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_output.php");
/*************************************/
initiate_pagination_sequence('profile.css');
	?>
	<div class="control_header note">
	<a href="rankings.php?orderby=points">lumens</a>  ||
	<a href="rankings.php?orderby=points_wagered">total wagered</a>  ||
	<a href="rankings.php?orderby=earnings_percentage">% earnings</a>  ||
	<a href="rankings.php?orderby=votes_for_percentage">% vote</a>  ||
	<a href="rankings.php?orderby=num_debates_won">debates won</a>  ||
	<?if ($_GET['month'] && $_GET['month']!=date('m'))
		{
			?><a href="rankings.php?orderby=num_arguments">arguments</a><?
		}
	else 
		{
			//so that users cannot see num_arguments.
			if($_GET['orderby']=='num_arguments')
				$_GET['orderby'] = 'points';
			?>arguments<?
		}
	?>  ||	
	<a href="rankings.php?orderby=num_comments">comments</a> 
	</div>
	<div class="stat_box"><?
	if($_GET['month']=='all' && (!$_GET['orderby'] || $_GET['orderby']=='points'))
		{$orderby = 'points_capital';}
	if(!$_GET['orderby'])
		{$orderby = 'points';}
	else
		{$orderby = $_GET['orderby'];}
	if(!$_GET['asc_desc'])
		$asc_desc = 'DESC';
	
	$data = db_get_user_list($orderby);

	switch ($orderby)
		{
			case points:
				$title = "Luminance: ";
				break;
			case points_wagered:
				$title = "Total Lumens wagered: ";
				break;
			case earnings_percentage:
				$title = "Percent earnings: ";
				break;
			case votes_for_percentage:
				$title = "Percent that voted for: ";
				break;
			case num_debates_won:
				$title = "Number of debates won: ";
				break;
			case num_arguments:
				$title = "Number of arguments made: ";
				break;
			case num_comments:
				$title = "Number of comments: ";
				break;
			default:    
				$title = "error";
		}
	echo $title;
	?>
	<br/><br/><?
	//for error checking.
	$total = 0;
	foreach($data as $stuff)
		{
			?><div style="float:left;width:4em;"><?
			echo $stuff[$orderby];
			if($orderby=='points_capital')
				{$total = $total + $stuff[$orderby];}
			
			?></div>
			<a href="profile.php?user=<?echo $stuff['username']?>"><?
			echo $stuff['username'];
			?></a><br/><?			
			
		}
	if($orderby='points_capital' && $total%1000!=0)
		{log_error('points_capital does not equal 0 mod 1000:  Problem with points');}

?></div><?output_footer();
