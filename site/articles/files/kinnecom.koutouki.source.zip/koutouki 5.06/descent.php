<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_login.php");
include("f_output.php");
checkLogin();
if($_SESSION['noscript'])
	{include("f_output_descent_no_javascript.php");}
else
	{include("f_output_descent.php");}
include("f_descent.php");
/*************************************/

/*
	Process all POST data

*/
?>

<?

$bet_id = $_GET['id'];
$content = $_POST['content'];
if($_GET['parent'])
	{$parent = $_GET['parent'];}
else
	{$parent = $_GET['replyto'];}
	
$owner = $_SESSION['user_name'];
if(!$_SESSION['user_name'])
	$owner = 'plebhead';
if($_POST['add_argument'])
	{	

		db_add_argument($bet_id, $owner, $content);
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&posted#footer\">");
	}
else if($_POST['add_comment'])
	{
		db_add_comment($bet_id, $owner, $content, $parent);
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}#{$parent}\">");
	}
if($_GET['vote']=='owner')
	{
		db_add_vote('owner',$_GET['id']);
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&voted\">");
	}
else if($_GET['vote']=='challenger')
	{
		db_add_vote('challenger',$_GET['id']);
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&voted\">");
	}

	//if bet accepted, first check all error messages. 
if($_POST['accept_bet'])
	{
		process_accept_bet();
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&challenged\">");
	}
else if($_POST['resurrect_bet'])
	{
		process_resurrect_bet();
		die("<meta http-equiv=\"Refresh\" content=\"0;url=descent.php?id={$_GET['id']}&challenged\">");
	}

else if($_GET['decision']=='accept')
		{
			$bet = db_get_bet($_GET['id']);
			if($_SESSION['user_name']==$bet['owner'])
				{
					db_process_resurrection($bet, $_GET['decision']);
				}
		}
	
initiate_pagination_sequence();
output_java_functions();
output_descent($_GET['id']);
output_footer();
 



?>
</div>
</body>
</html>