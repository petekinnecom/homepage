<?php

function add_bet()
{
	//Correct formatting
	$urlclaim = urlencode($_POST['claim']);
	$urltitle = urlencode($_POST['title']);
	$_POST['wager'] = (int) ($_POST['wager']);

	//verify information.  Die back to place_bet with error message

	if(!$_SESSION['user_name'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=4&claim={$urlclaim}&title={$urltitle}\">");
		}
	if(!$_POST['wager'] && ($_POST['type']=='challenge' || $_POST['type']=='personal_challenge'))
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=1&claim={$urlclaim}&title={$urltitle}\">");
		}

	if(strlen($_POST['claim'])>5000)
		{
			$shortclaim = substr($_POST['claim'], 0, 500);
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=6&wager={$_POST['wager']}&title={$urltitle}&claim={$shortclaim}\">");
		}
	
	if($_POST['title'] != strip_tags($_POST['title']))
		{
			$shortclaim = substr($_POST['claim'], 0, 500);
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=7&wager={$_POST['wager']}&title={$urltitle}&claim={$shortclaim}\">");
		}
		
	
	if(!$_POST['type'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=10&claim={$urlclaim}&title={$urltitle}\">");
		}
	if($_POST['type']=='personal_challenge' && !db_username_availability($_POST['user_to_challenge']))
		{
			//die("user_to_challenge: ".$_POST['user_to_challenge']);
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=11&claim={$urlclaim}&title={$urltitle}\">");
		}
	/*
	* removed to make claim optional
	*
	if(!$_POST['claim'])
	{
	die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=2&wager={$_POST['wager']}&title={$urltitle}\">");
	}

	*
	*/

	if($_SESSION['user_points'] < $_POST['wager'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=3&claim={$urlclaim}&title={$urltitle}\">");
		}
	if(0 > $_POST['wager'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=8&claim={$urlclaim}&title={$urltitle}\">");
		}

	if(!$_POST['title'])
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=place_bet.php?fail=5&wager={$_POST['wager']}&claim={$urlclaim}\">");
		}

	$owner = $_SESSION['user_name'];
	$wager = $_POST['wager'];
	$title = $_POST['title'];
	$claim = $_POST['claim'];
	$type = $_POST['type'];
	$creator = $_SESSION['user_name'];
	$user_to_challenge = $_POST['user_to_challenge'];
	$show_vote_counts = 'no';
	$anonymous = 'no';
	$num_arguments_allowed = $_POST['num_arguments_allowed'];
	
	if($_POST['show_vote_counts'])
		{
			$show_vote_counts = 'yes';
		}
	
	if($_POST['anonymous'] && $_POST['type']!='personal_challenge')
		{
			$anonymous = 'yes';
		}
	
	if(!db_add_bet($owner, $wager, $title, $claim, $type, $anonymous, $show_vote_counts, $num_arguments_allowed, $creator, $user_to_challenge))
		{
			echo "<h1>MUTANT ZOMBIES ATTACK EARTH!!!  THOUSANDS DECOMPOSING!!!</h1><p> Oh wait...it's just an error in the database. f_place_bet: add_bet";
		} 
	else
		{
			die("<meta http-equiv=\"Refresh\" content=\"0;url=/\">");
		}
}
?>

