<?php


function log_error($msg)
{
	$date = date('m-y');
	$FileName = "files/{$date}.error_log.txt"; 
	$file = fopen($FileName, 'a') or die("Can't open file");

	$date = date('d-m-Y :: H:i:s');
	$tofile = $date . "  " . $msg . "\n\n";
	
	fwrite($file, $tofile);
 	fclose($file);

}
function log_action($betid, $type, $msg)
{
	$date = date('m-y');
	$FileName = "files/{$date}.log.txt"; 
	$file = fopen($FileName, 'a') or die("Can't open file");

	$date = date('d-m-Y :: H:i:s');
	$user = $_SESSION['user_name'];
	$ip = $_SERVER['REMOTE_ADDR'];
	
	if(ereg('66.249.', $ip))
		{
			//this is google
			return;
		}
	if(ereg('67.160.164.232',$ip) && (!$_SESSION['user_name'] || $_SESSION['user_name']=='mctk'))
		{
			//this is me
			return;
		}
	/*
	make standard lengths, so log looks pretty
	*/
	
	while(strlen($type)<9)
		{
			$type = $type . " ";
		}

	while(strlen($user)<15)
		{
			$user = $user . " ";
		}
	
	while(strlen($ip)<16)
		{
			$ip = $ip . " ";
		}
	
	while(strlen($msg)<50)
		{
			$msg = $msg . " ";
		}

	$tofile = $date . "   ". $betid."  ".$type." ".$ip." ".$user."    ".$msg."\n";
	
	fwrite($file, $tofile);
 	fclose($file);
}



?>