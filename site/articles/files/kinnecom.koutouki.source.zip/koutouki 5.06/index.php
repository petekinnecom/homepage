<?php
/* Include Files *********************/
session_start(); 
include("f_database.php");
include("f_output.php");
include("f_output_index.php");
include("f_login.php");
/*************************************/
initiate_pagination_sequence();
output_index_javascript();

if($_GET['filter_status'] || $_GET['filter_action'] || $_GET['sort'] || $_GET['order'] || $_GET['filter_user'] || isset($_GET['page']) || $_GET['announcement'])
	{
		output_requested_bets();
		
	}
else if($_GET['query'])
	{
		output_search_results();
	}
else
	{
		output_bet_listing_by_type('announcement',1);
		output_bet_listing_by_type('resolved',2);
		output_bet_listing_by_type('dispute',10);
		output_bet_listing_by_type('open',10);
	}
output_footer();
