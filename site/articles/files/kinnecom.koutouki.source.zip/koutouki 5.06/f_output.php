<?php
function br2nl($text)
{
   return  preg_replace('/<br\\s*?\/??>/i', '', $text);
}
function output_tag_buttons()
{
	/*
	<script type="text/javascript">edToolbar();</script>
	*/
	?><div id="buttons"></div><script type="text/javascript">buttons.innerHTML = edToolbar();</script><?
	
}
function output_allowed_tags()
{
	?>
	<div class="note">
	Allowed tags: &lt;i&gt;, &lt;b&gt;, &lt;a&gt;, &lt;img&gt; &lt;center&gt;, &lt;blockquote&gt;, &lt;ul&gt;, &lt;ol&gt;, &lt;li&gt;.		
		</div>
	<?
}

/*
	This function spits back the proper GET string to append to a link.
	It will return the current GET string.
*/
function form_get_link($except_this)
{
	$this = '?';
	if($_GET['filter_status'] && $except_this!='filter_status')
		{
			$this = $this . "filter_status=".$_GET['filter_status']."&";
		}
	if($_GET['sort'] && 'sort'!=$except_this)
		{
			$this = $this . "sort=".$_GET['sort']."&";
		}
	if($_GET['order'] && 'order'!=$except_this)
		{
			$this = $this . "order=".$_GET['order']."&";
		}
	if($_GET['filter_action'] && 'filer_action'!=$except_this)
		{
			$this = $this . "filter_action=".$_GET['filter_action']."&";
		}
	if($_GET['filter_user'] && 'filer_user'!=$except_this)
		{
			$this = $this . "filter_user=".$_GET['filter_user']."&";
		}
	if($_GET['page'] && 'page'!=$except_this)
		{
			$this = $this . "page=".$_GET['page']."&";
		}
	return $this;
}
function is_debater($username, $bet)
{
	if($username==$bet['owner'] ||	$username==$bet['challenger'])
		{
			return true;
		}
	return false;
}
function can_argue($username, $bet)
{
	//returns true of false.  
	//don't need to worry about num_arguments being above 
	//num_arguments_allowed because f_database will close bet when that happens
	//must add 'close debate' check to add_argument
	
	if($bet['num_arguments_allowed']==-1)
		return true;
	if($bet['action']=='pending')
		return true;
	if($bet['action']=='waiting_owner' && $_SESSION['user_name']==$bet['owner'])
		return true;
	if($bet['action']=='waiting_challenger' && $_SESSION['user_name']==$bet['challenger'])
		return true;
		
	return false;

	
	
/* tracked in the database now

	if(count($arguments)%2==0)
		return true;
	
	$owned = 0;
	$other = 0;
	foreach($arguments as $arg)
		{
			if($arg['owner']==$_SESSION['user_name'])
				$owned++;
			else
				$other++;
		}
		
	//the = sign should not matter because then we would have a mod 2, which would already have been returned
	//I'll leave it on here just FOR FUN! YAY!
	if($owned<=$other)
		return true;
		
	return false;
*/	
}
function output_avatar($username)
{
	
	$info = db_get_user_info($username);
	
	if(!$username)
		{
			?><div class="avatar"><?
			echo '<img src="avatars/default_blank.jpg" border="0" alt="avatar" width="100" height="100">';
		
		}
	else if(file_exists('avatars/'.$info['avatar']))
		{
			?><div class="avatar_border">
			<a href="profile.php?user=<?echo $username?>" target="_top">
			<?
			echo '<img src="avatars/'.$info['avatar'].'" border="0" alt="avatar" width="100" height="100">';
			?></a><?
		}
	else
		{
			?><div class="avatar_border"><?
			echo '<img src="avatars/default.jpg" border="0" alt="avatar" width="100" height="100" >';
		}
	?></div><?
}

function output_login_bar()
{
	if ($_SESSION['user_name'])
        {
			echo "<b>{$_SESSION['user_name']}</b>.  |  
				{$_SESSION['user_points']} lm   | ";
			
			if($_SESSION['points_in_holding'])
				{
					echo "<a href=\"/?filter_user={$_SESSION['user_name']}\">{$_SESSION['points_in_holding']} lms wagered</a> | ";   
				}

			if($_SESSION['user_points']){ echo " <a href=\"place_bet.php\"> Propose debate </a>  |  ";}
			else{echo " <font color=\"#BBBBBB\"> Place bet </font> |  ";}
			echo  "<a href=\"{$_SERVER['PHP_SELF']}?logout=true\">Log out</a>";
        }
    else
        {
			echo '<a href="login.php">Log in</a> or <a href="register.php">Sign up</a>';
        }

}
function output_search_bar()
{
	?>
		<div class="control_header" style="text-align:left;font-size:80%">
		<form action="/" method="get">
		<input type="text" name="query" maxlength="60" style="width:75%;">  
		<input type="submit" name="obiwan_never_told_you_who_your_true_father_was_did_he" value="search">
		</form>
		</div>
	<?
}
function output_sort_bar()
{
	?>
	<div class="control_header" style="text-align:left;font-size:80%">
	<div class="fl">
	<?
	//form GET statement, to simplify menu links
	$get = form_get_link('sort');
	?>
	<a href="/<? echo $get; ?>sort=last_updated">last updated</a>  ||  
	<a href="/?filter_user=<?echo $_SESSION['user_name']?>">mine</a>  ||  
	<a href="/<? echo $get; ?>sort=num_arguments">most debated</a>  ||  
	<a href="/<? echo $get; ?>sort=num_comments">most commented</a> 
	</div>
	<div class="ar">
	<?
	if($_GET['order'])
		{
			?><a href="/?filter_status=<? echo $_GET['filter_status'] ?>&sort=<? echo $_GET['sort'] ?>">reverse order</a><?
		}
	else
		{
			?><a href="/?filter_status=<? echo $_GET['filter_status'] ?>&sort=<? echo $_GET['sort'] ?>&order=ASC">reverse order</a><?
		}
	?>
	</div>
	</div>
	<?
}
function output_header($stylesheet='')
{
	/*	echo '
	<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">';*/
	?>
	
	<head>
	<title>Koutouki: enlighten the plebheads.</title>
	<noscript>
		<?if($_GET['noscript'] || $_SESSION['noscript'])
			{
				$_SESSION['noscript']=true;
				//echo "noscript";
			}
		else
			{
				?><meta http-equiv="Refresh" content="0;url=/?noscript=true"><?
			}?>
	</noscript>
	<meta http-equiv="content-type" 
			content="text/html;charset=utf-8" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<?//<meta name="robots" content="noarchive" />?>
	<meta name="keywords" content="koutouki" />
	<meta name="description" content="Enlighten the plebheads" />
	<link rel="stylesheet" type="text/css" href="style.css" />
	<?if($stylesheet)
		{?><link rel="stylesheet" type="text/css" href="<?echo $stylesheet;?>" /><?}?>
	<!--[if IE 7]>
	<link rel="stylesheet" type="text/css" href="ie_style.css" />
	<![endif]-->	
		
		
	<link href="files/koutouki_favicon.png" rel="shortcut icon" />
	<script src="files/js_quicktags.js" type="text/javascript"></script>
	
	<script type="text/javascript">
	function openpopup(popurl){
	var winpops=window.open(popurl,"","width=400,height=600,status,resizable")
	}
	</script>
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
	_uacct = "UA-785958-1";
	urchinTracker();
	</script>
	
	<script>
	function j_show_div(divname)
	{
		div = document.getElementById(divname);
		if(div.style.display == 'none')
		{
			div.style.display = 'block';
		}
		else
		{
			div.style.display = 'none';
		}
	}
	
	</script>
	
	
	
	</head>
	<body>

	<div id="container">
	<div class="header_right">
	<div class="header_left">
	<div id="header">
	</div>
	<div id="banner">
	</div>
	<!--Currently under construction.  May tweak out. Sorry.-->
	<div id="stripe"></div>
	<a name="top"></a>

	<div id="bar">
	<div style="text-align:right;font-size:80%;float:right;display:inline">enlighten the plebheads</div>
	<a href="/">home</a>  ||  
	<a href="rankings.php">rankings</a>  ||  
	<a href="#" onclick="j_show_div('sort_bar');document.getElementById('search_bar').style.display='none';">sort</a>  ||  
	<a href="#" onclick="j_show_div('search_bar');document.getElementById('sort_bar').style.display='none';">search</a>	  ||  
	<a href="about.php">about</a>
	</div>

	<?
}
function output_left_content_box()
{
	?> 
	<div id="left_content_box">
	<div id="sort_bar" style="display:none">
	<?
	output_sort_bar();
	?>
	</div>
	<div id="search_bar" style="display:none">
	<?
	output_search_bar();
	?>
	</div>
	<?
}
function output_sidebar()
{
	?> <div id="right_content_box"> 
	
	<div id="right_user_info"><?
	if(!$_SESSION['user_name'])
		{
			?>
			<form action="" method="post">
			<?if($_GET['fail']=='nm')
				{?><b>Username:</b><?}
			else
				{?>Username:<?}
			?>
			<input type="text" name="user" maxlength="30" value="<?echo $_GET['usrnm']?>">
			<?if($_GET['fail']=='pss')
				{?><b>Password:</b><?}
			else
				{?>Password:<?}
			?>			
			<input type="password" name="pass" maxlength="30">
			<input type="checkbox" name="remember">
			<font size="2">Remember me next time</font>
			<input type="submit" name="sublogin" value="Login">
			</form>
			<?
			if($_GET['fail']=='pss')
				{?><b>Incorrect password.</b><?}
			if($_GET['fail']=='nm')
				{?><b>Incorrect username.</b><?}?>
			<a href="register.php">Sign up</a>
			<?
		}
	else
		{
			?><div style="text-align:center;"><?
			output_avatar($_SESSION['user_name']);
			echo $_SESSION['user_name'];
			?></div>
			<a href="place_bet.php">Propose Debate</a><br/>
			<?
			echo "lms: ".$_SESSION['user_points']."<br/>";
			if($_SESSION['points_in_holding'])
				{
					echo "<a href=\"/?filter_user={$_SESSION['user_name']}\"> lms wagered: {$_SESSION['points_in_holding']}</a><br/>";   
				}
			else
				{
					echo "lms wagered: 0<br/>";
				}
			echo "title: ".$_SESSION['user_title']."<br/>";
			echo '<a href="settings.php">Settings</a><br/>';
			/*   ADMIN LINK
			if($_SESSION['user_name']=='mctk')
				{?><a href="admin.php">admin</a><br/><?}
			*/
			echo  "<a href=\"{$_SERVER['PHP_SELF']}?id={$_GET['id']}&logout=true\">Log out</a>";
		}
	
	?></div>
	
	
	
	
	<div id="right_menu">
	<a href="/?filter_status=expired">the Graveyard</a><br/>
	<a href="/?announcement=reading_this_phrase_is_not_really_worth_the_effort,_but_I'm_sure_you're_glad_you_read_it_anyway">feedback</a><br/>
    <a href="faq.php">faq</a><br/>
	<a href="description/site_meta_info.html">update log</a><br/>
	<?/*
	<a href="#" onclick="setActiveStyleSheet('test');return false;">style</a>
	<a href="#" onclick="setActiveStyleSheet('standard');return false;">style 2</a>
	*/?>
	</div>
	<?/*
	<div id="right_ad"><?
	
	$rand = rand(0,1);
	if($rand==0 || $_SESSION['user_name']=='mctk')
		{
		$rand = rand(0,5);
		?><img src="files/ad_0<?echo $rand?>.jpg" alt="Ridiculously awesome advertisement" /><?
		
		}
	
	
	else
	
	{?>
	<script type="text/javascript"><!--
	google_ad_client = "pub-3176662297770066";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text_image";
	google_ad_channel = "";
	google_color_border = "CCCCCC";
	google_color_bg = "E6E6E6";
	google_color_link = "000000";
	google_color_text = "333333";
	google_color_url = "666666";
	//--></script>
	<script type="text/javascript"
	src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
	</script>
	<?}?>
	</div><?*/?>
	</div>
	<?

}
function output_footer()
{

	?>
	</div><!--left_content_box-->
	<div id="footer">
	</div>
	</div>
	</div>
	</body>
	</html>
	<?
}
function initiate_pagination_sequence($css='')
{
	output_header($css);
	output_sidebar(); //must come before left_content_box
	output_left_content_box();
}
 ?>
