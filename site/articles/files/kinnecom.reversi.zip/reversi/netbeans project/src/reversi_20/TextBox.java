/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package reversi_20;

import javax.swing.JTextArea;

/**
 *
 * @author pete
 */
public class TextBox extends JTextArea{

    public void print(String s){
        append(s+"\n");
        setCaretPosition(this.getDocument().getLength());

    }

}
