/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package reversi_20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author pete
 */
class DBMachine {

    TextBox textBox;


    public Boolean preLoad() {
        try {
            // load the sqlite-JDBC driver using the current class loader
            Class.forName("org.sqlite.JDBC");

        } catch (ClassNotFoundException ex) {
            return false;
        }
        return true;
    }

    public boolean connect(Board b){
        Connection conn = null;
        if (!preLoad()) {
            return false;
        }
        try {
            Board c = new Board(b.width, b.height, b.s_x, b.s_y, b.squareSize, b.firstPlayer);

            conn = DriverManager.getConnection(c.getConnectionString());
            Statement statement = conn.createStatement();
            statement.setQueryTimeout(30);
            ResultSet rs = statement.executeQuery("SELECT id FROM positions WHERE id==1");
            if(!rs.next()){
                return false;
            }
            rs = statement.executeQuery("SELECT id FROM positions WHERE finished==0 ORDER BY level");
            if (rs.next()) {
                return false;
            }
            rs = statement.executeQuery("SELECT * FROM positions WHERE class==NULL");
            if (rs.next()) {
                return false;
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                return false;
            }
        }
        if(conn==null){
            return false;
        }
        return true;
    }

    public int[] getNextMove(Board b){


    /* Get the board.  Get a child.  Try every move.  If it equals the child, return the coords of the move. */
        Connection conn = null;
        ArrayList<Integer> childrenID = new ArrayList();
        ArrayList<String> childrenPos = new ArrayList();
        ArrayList<Integer> childrenClass = new ArrayList();
        int id;
        int mn[] = {-1,-1};
        try {
            Board c = new Board(b.width, b.height, b.s_x, b.s_y, b.squareSize, b.firstPlayer);
            conn = DriverManager.getConnection(c.getConnectionString());
            Statement statement = conn.createStatement();
            statement.setQueryTimeout(30);
            ResultSet rs = statement.executeQuery("SELECT id FROM positions WHERE pos=='"+b.posToString()+"';");
            if(!rs.next()){
                textBox.print("error: I cannot find this position in the game tree.\nMy logic has broken down somewhere.  Goodbye, I'm going out to play");
            }
            id = rs.getInt("id");
            rs = statement.executeQuery("SELECT child FROM links WHERE parent=="+id+";");
            while (rs.next()) {
                childrenID.add(rs.getInt("child"));
            }

            /* if the game is over */
            if(childrenID.isEmpty()){
                return mn;
            }

            for (int k = 0; k < childrenID.size(); k++) {
                rs = statement.executeQuery("SELECT pos,class FROM positions WHERE id==" + childrenID.get(k).intValue());
                rs.next();
                childrenPos.add(rs.getString("pos"));
                childrenClass.add(rs.getInt("class"));
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            }
            catch (SQLException e) {
                return mn;
            }
            if (childrenPos.isEmpty()) {
                textBox.print("error: I cannot find this position in the game tree.\nMy logic has broken down somewhere.  Goodbye, I'm going out to play");
            }
            Board d;
            for(int k=0;k<childrenPos.size();k++){
                if(childrenClass.get(k)==0){
                    return findMove(b, childrenPos.get(k));
                }
            }
            return moveRandom(b);
        } catch (SQLException ex) {
            textBox.print("error:"+ex.toString());
            return mn;
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                return mn;
            }
        }

    }

    private int[] findMove(Board b, String pos) {
        Board c;
        int[] mn = {-1,-1};
        for(int i=0;i<b.width;i++){
            for(int j=0;j<b.height;j++){
                if(b.canMove(i, j)){
                    c = b.clone();
                    c.move(i,j);
                    if(c.posToString().equals(pos)){
                        if(b.firstPlay){textBox.print("I will win.");}
                        mn[0] = i;
                        mn[1] = j;
                        return mn;
                    }
                }
            }
        }
        textBox.print("error: findMove found no moves");
        return mn;
    }

    private int[] moveRandom(Board b) {
        if(b.firstPlay){textBox.print("I will lose.");}
        int[][] mn = new int[64][2];
        int k = 0;
        Random rand = new Random();
        mn[0][0] = -1;
        mn[0][1] = -1;
        for (int i = 0; i < b.width; i++) {
            for (int j = 0; j < b.height; j++) {
                if (b.canMove(i, j)) {
                    mn[k][0] = i;
                    mn[k][1] = j;
                    k++;
                }
            }
        }
        if (mn[0][0] == -1) {
            return mn[0];
        }
        else {
            int i = rand.nextInt(k);
            return mn[i];
        }
    }

}
