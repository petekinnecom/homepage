package reversi_20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TreeBuilder {

    Thread btl;
    Board b;
    private TextBox textBox;
    private String CONNECTION;

    public void preLoad() {
        try {
            // load the sqlite-JDBC driver using the current class loader
            Class.forName("org.sqlite.JDBC");

        } catch (ClassNotFoundException ex) {

            textBox.print("Crashed and burned: ");
            textBox.print(ex.getLocalizedMessage());
        }

    }

    public Boolean prepTable(Board b) {
        /* Here with open the database and check to see if it already
         * has a record at id=1.  If it does, the table is good to go: return.
         * If it doesn't the table will be made and we just need to insert
         * this Board b.
         */

        Connection conn = null;
        textBox.print("Initializing\n\nConnecting to " + CONNECTION);

        boolean success = false;
        /* open the window */
        try {
            conn = DriverManager.getConnection(CONNECTION);
            Statement statement = conn.createStatement();
            statement.setQueryTimeout(30);

            /* painfully stupid, but I'm just not getting these sql commands:
             * make the table, if it doesn't exist.  Then check to see if it has a root.
             * If it does, it's good to go: we return.  If it doesn't, drop the table
             * (in case it has bad data in it), recreate it and insert the root board
             */
            /* test ! */
            statement.executeUpdate("PRAGMA synchronous = OFF;");

            statement.executeUpdate("DROP TABLE IF EXISTS positions");
            statement.executeUpdate("DROP TABLE IF EXISTS links");

            textBox.print("Creating database.");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS positions (" +
                    "id INTEGER PRIMARY KEY  ," +
                    "level TINYINT NOT NULL," +
                    "pos TEXT NOT NULL ," +
                    "turn TINYINT NOT NULL ," +
                    "finished BOOL DEFAULT '0'," +
                    "class TINYINT NULL " +
                    ")");
            statement.executeUpdate("INSERT INTO positions (level,pos, turn) VALUES (0, '" + b.posToString() + "' , " + b.turn + ")");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS links (" +
                    "parent INTEGER NOT NULL," +
                    "child INTEGER NOT NULL" +
                    ")");
            success = true;


        } catch (SQLException ex) {

            Logger.getLogger(TreeBuilder.class.getName()).log(Level.SEVERE, null, ex);
            textBox.print("Crashed and burned: ");
            textBox.print(ex.getLocalizedMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                    return success;
                }
            } catch (SQLException e) {
                // connection close failed.
                System.err.println(e);
            }
        }

        return false;
    }

    void startBuildTreeMainLoop(Board b, TextBox textBox) {

        this.b = new Board(b.width, b.height, b.s_x, b.s_y, b.squareSize, b.firstPlayer);
        this.textBox = textBox;

        CONNECTION = b.getConnectionString();
        preLoad();

        btl = new Thread(new buildTreeLoop());

        if (prepTable(b)) {
            btl.setPriority(Thread.NORM_PRIORITY);
            btl.start();
        }
    }

    public class buildTreeLoop implements Runnable {

        public void run() {

            textBox.print("Populating tree\n");

            boolean more = true;
            /* c[0] is the upper level of finished boards
             * c[1] is the working level of unfinished boards */

            ArrayList<Board> top_array = new ArrayList();
            ArrayList<Board> child_array = new ArrayList();
            top_array.ensureCapacity(1000000);
            child_array.ensureCapacity(1000000);

            Board c = null;


            double timeStart = 0.0;
            double timeDiff = 0.0;
            double timeBegan = 0.0;
            double average = 0.0;
            int thisLevel;

            int totalLevels = b.width * b.height - 4;
            int row_id;
            int levelCount = 0;
            Iterator<Board> top_i;
            /* this is the main loop.
             * We will be in here until the tree is finished.  */ /* row_id == -1 is a flag that we didn't get anything from the db */
            row_id = dbGetNextLevel(top_array) + 1;
            timeBegan = System.currentTimeMillis();
            textBox.print("row_id initialized to " + row_id);

            while (!top_array.isEmpty()) {
                average = (System.currentTimeMillis() - timeBegan) / 1000.0;
                timeStart = System.currentTimeMillis();

                levelCount = 0;
                top_i = top_array.iterator();
                while (top_i.hasNext()) {
                    c = top_i.next();
                    for (int i = 0; i < b.width; i++) {
                        for (int j = 0; j < b.height; j++) {
                            if (c.canMove(i, j)) {
                                if (processSquare(i, j, c, row_id, child_array)) {
                                    row_id++;
                                //System.out.println("processed : "+row_id);
                                }
                                levelCount++;
                            }
                        }
                    }
                }
                if (c != null) {
                    timeDiff = -timeStart + System.currentTimeMillis();
                    //average = (-timeBegan+System.currentTimeMillis())/(row_id*1.0);
                    textBox.print("level " + c.level + " of " + totalLevels + ":\n" + levelCount + " processed in " + timeDiff + "ms");
                }
                thisLevel = row_id-1;
                textBox.print(average + "s for " + thisLevel + " positions.");
                /* we've now finished processing every board in c[0]
                 * dbAddBoards will add c[1] to the database; returns false if
                 * row_id does not match last input row.    */
                if (!dbAddBoardArray(child_array, row_id, top_array)) {
                    //System.out.println("The row ID's don't match!");
                    //System.exit(1);
                }
                /* Note: This must come after we've added the boards
                 * to the database.  Otherwise we might corrupt the db */
                if (Thread.interrupted()) {
                    more = false;
                    break;
                }
                top_array = child_array;
                child_array = new ArrayList();
                child_array.ensureCapacity(1000000);
            }
            textBox.print("Finished creating position tree.");
            TreeAnalyzer treeAnalyzer = new TreeAnalyzer();
             treeAnalyzer.startAnalyzeTreeMainLoop(b, textBox);

        }

        private boolean dbAddBoardArray(ArrayList<Board> child_array, int row_id, ArrayList<Board> top_array) {
            double timeStart = System.currentTimeMillis();
            double timeTotal;

            Board c;

            Connection conn = null;
            boolean success = false;
            try {
                conn = DriverManager.getConnection(CONNECTION);
                Statement statement = conn.createStatement();
                statement.setQueryTimeout(30);
                statement.executeUpdate("PRAGMA synchronous = OFF;");
                statement.executeQuery("PRAGMA journal_mode = OFF;");
                String queryPos = new String();
                String queryLinks = new String();
                String queryFinished = new String();

                Iterator<Board> child_i = child_array.iterator();

                int p;
                /* Now close the top_array */
                for (int i = 0; i < top_array.size(); i++) {
                    queryFinished = "UPDATE positions SET finished=1 WHERE id=" + top_array.get(i).id + "; ";
                    statement.addBatch(queryFinished);
                }
                /* for every child, add the board to the positions database */
                while (child_i.hasNext()) {
                    c = child_i.next();
                    c.level++;
                    queryLinks = "INSERT INTO 'links' (parent,child) VALUES (" + c.parent + "," + c.id + "); ";
                    statement.addBatch(queryLinks);
                    queryPos = "INSERT INTO 'positions' (level,pos,turn) " +
                            "VALUES (" + c.level + ", '" + c.posToString() +
                            "' , " + c.turn + "); ";
                    statement.addBatch(queryPos);
                }



                /* important that queryPos is last, so that last_insert_rowid() functions correctly */
                //System.out.println(queryFinished + queryLinks + queryPos);
                statement.executeBatch();
                ResultSet rs2 = statement.executeQuery("SELECT last_insert_rowid() AS id;");
                if (rs2.getInt("id") + 1 != row_id) {
                    //textBox.print("---Error---\ndb_id = "+rs2.getInt("id") + " but our row_id = "+row_id+"---Error---");
                    success = false;
                }
                success = true;

            } catch (SQLException ex) {

                Logger.getLogger(TreeBuilder.class.getName()).log(Level.SEVERE, null, ex);
                textBox.print("Crashed and burned: ");
                textBox.print(ex.getLocalizedMessage());
            } finally {
                try {
                    if (conn != null) {
                        conn.close();
                        timeTotal = (System.currentTimeMillis() - timeStart) / 1000.0;
                        textBox.print("Level saved in " + timeTotal + "s\n");
                        return success;
                    }
                } catch (SQLException e) {
                    // connection close failed.
                    System.err.println(e);
                }
            }
            return false;

        }

        private int dbGetNextLevel(ArrayList<Board> top_array) {
            Board c = new Board(b.width, b.height, b.s_x, b.s_y, b.squareSize, b.firstPlayer);
            Connection conn = null;
            int row_id = -1;
            try {

                conn = DriverManager.getConnection(CONNECTION);
                Statement statement = conn.createStatement();
                statement.setQueryTimeout(30);

                ResultSet rs = statement.executeQuery("SELECT * FROM positions WHERE finished==0 ORDER BY level");

                int level_check = 0;
                if (rs.next()) {
                    if (level_check == 0) {
                        level_check = rs.getInt("level");
                    }
                    c.parseBoard(rs.getString("pos"));
                    c.turn = rs.getInt("turn");
                    c.id = rs.getInt("id");
                    c.level = rs.getInt("level");
                    //c.print();
                    if (c.level != level_check) {
                        textBox.print("\n Level Check Fail!\nThis database is corrupted.\n Level Check Fail!");
                        System.out.println("\n Level Check Fail!\nThis database is corrupted!\n Level Check Fail!");
                        System.exit(1);
                    }
                    top_array.add(c);
                    row_id = c.id;
                }
            } catch (SQLException ex) {

                Logger.getLogger(TreeBuilder.class.getName()).log(Level.SEVERE, null, ex);
                textBox.print("Crashed and burned: ");
                textBox.print(ex.getLocalizedMessage());
            } finally {
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                    // connection close failed.
                    System.err.println(e);
                }
            }
            return row_id;


        }

        private boolean processSquare(int i, int j, Board c, int row_id, ArrayList<Board> child_array) {
            Board other;
            Board tmp = c.clone();
            tmp.move(i, j);
            tmp.id = row_id;
            tmp.parent = c.id;
            child_array.add(tmp);
            return true;

        }
    }
}



