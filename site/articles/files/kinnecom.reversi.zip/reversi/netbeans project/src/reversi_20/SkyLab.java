/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package reversi_20;

import java.awt.Cursor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author pete
 */
class SkyLab {

    private Board b;
    private GraphBox graphBox;
    private TextBox textBox;
    private Stack<Board> backStack;
    private Stack<Board> forwardStack;

    private Player[] player = new Player[2];
    private ValueArray firstValueArray;
    private ValueArray secondValueArray;

    public void init(GraphBox GB, TextBox TB){
        b = new Board();
        backStack = new Stack();
        forwardStack = new Stack();
        //just so I don't have to keep passing them as parameters
        graphBox = GB;
        textBox = TB;
        textBox.print("---new game---\n");
        graphBox.initBuffer();
        graphBox.setCursor(new Cursor(Cursor.HAND_CURSOR));

        player[0] = new Player(0,textBox, b);
        player[1] = new Player(1,textBox, b);
        redraw();
    }

    void buildTreeAction() {
        
        TreeBuilder treeBuilder = new TreeBuilder();
        treeBuilder.startBuildTreeMainLoop(b, textBox);


    }

    void boardSizeAction() {
        String response = JOptionPane.showInputDialog(null, "Enter width,height", "Resize the board, you say?", JOptionPane.QUESTION_MESSAGE);
        if (response != null) {
            ParseNewBoard(response);
        }
    }

    void magnifyAction() {
        String response = JOptionPane.showInputDialog(null, "Enter the pixel size of each square.", "Resize the square size?", JOptionPane.QUESTION_MESSAGE);
        if (response != null) {
            try {
                b.squareSize = Integer.parseInt(response);
                redraw();
            } catch (NumberFormatException numberFormatException) {
                JOptionPane.showMessageDialog(null, "Sorry, I didn't understand.");

            }

        }
    }

    void newGameAction() {
        b = new Board(b.width, b.height, b.s_x, b.s_y, b.squareSize);
        backStack = new Stack();
        forwardStack = new Stack();
        redraw();
        textBox.print("\n---new game---\n");
    }

    void tournament() {
        String response = JOptionPane.showInputDialog(null, "How many trials per match-up", "What you say?", JOptionPane.QUESTION_MESSAGE);
        int numTrials;
        if (response != null) {
            try {
                numTrials = Integer.parseInt(response);

            }
            catch (NumberFormatException numberFormatException) {
                JOptionPane.showMessageDialog(null, "Sorry, I didn't understand.");
                return;
            }
            String[] strats = {"random", "greedy+", "greedy-", "greedy-,minimize", "minimize", "minimize,greedy-", "minimize,greedy,value"};
            for(int i=0;i<strats.length;i++){
                for(int j=0;j<strats.length;j++){
                    player[0].setStrategy(strats[i], b);
                    player[1].setStrategy(strats[j], b);
                    simulate(numTrials, true);
                }
            }

        }
    }

    void trialAction() {
        if (player[0].strategy.equals("user")) {
            textBox.print("Cannot run trials: " + player[0].name + " is user controlled");
            return;
        }
        if (player[1].strategy.equals("user")) {
            textBox.print("Cannot run trials: " + player[1].name + " is user controlled");
            return;
        }
        String response = JOptionPane.showInputDialog(null, "How many trials shall we do?", "Main screen turn on.", JOptionPane.QUESTION_MESSAGE);
        int numTrials;
        if (response != null) {
            try {
                numTrials = Integer.parseInt(response);
                simulate(numTrials, true);
            }
            catch (NumberFormatException numberFormatException) {
                JOptionPane.showMessageDialog(null, "Sorry, I didn't understand.");

            }
        }
    }

    void unicornAction() {
        textBox.print("Totally.");
    }

    private Boolean testDBMachine() {
        DBMachine db = new DBMachine();
        if (db.connect(b)) {
            return true;
        }
        else {
            return false;
        }
    }

    void setStrategy(int p, String s) {
        if (s.equals("perfect")) {
            if (!testDBMachine()) {
                textBox.print("error: The game tree for this database is not finished.");
                setStrategy(p, "user");
                return;
            }
        }
        player[p].setStrategy(s, b);
        textBox.print("Set " + player[p].name + "'s strategy to " + s);
    }

    private void ParseNewBoard(String response) {
        String[] dims = response.trim().split(",");
        int width2, height2;
        try {
            width2 = Integer.parseInt(dims[0]);
        }
        catch (NumberFormatException numberFormatException) {
            JOptionPane.showMessageDialog(null, "Sorry, I didn't understand.");
            return;
        }
        try {
            height2 = Integer.parseInt(dims[1]);
        }
        catch (NumberFormatException numberFormatException) {
            JOptionPane.showMessageDialog(null, "Sorry, I didn't understand.");
            return;
        }
        if (width2 > 8 || height2 > 8) {
            JOptionPane.showMessageDialog(null, "8x8 is the limit.");
            return;
        }
        int sx = (int) Math.floor(width2/2) - 1;
        int sy = (int) Math.floor((height2/2)) -1 ;
        Board tmp = new Board(width2, height2, sx, sy, b.squareSize);
        b = tmp;
        newGameAction();
        redraw();
    }

    void startPosAction() {
        String response = JOptionPane.showInputDialog(null, "Enter x,y", "Where to place the starting square?", JOptionPane.QUESTION_MESSAGE);
        if (response != null) {
            ParseNewStarting(response);
        }

    }

    private void ParseNewStarting(String response) {
        String[] dims = response.trim().split(",");
        int s_x, s_y;
        try {
            s_x = Integer.parseInt(dims[0]);
        }
        catch (NumberFormatException numberFormatException) {
            JOptionPane.showMessageDialog(null, "Sorry, I didn't understand.");
            return;
        }
        try {
            s_y = Integer.parseInt(dims[1]);
        }
        catch (NumberFormatException numberFormatException) {
            JOptionPane.showMessageDialog(null, "Sorry, I didn't understand.");
            return;
        }

        if (s_x >= b.width || s_y >= b.height) {
            JOptionPane.showMessageDialog(null, "That won't fit on this board.  Try resizing the board.");
            return;
        }
        Board tmp = new Board(b.width, b.height, s_x - 1, s_y - 1, b.squareSize);
        b = tmp;
        newGameAction();
        redraw();
    }

    public void redraw() {
        b.draw(graphBox.buffer);
        graphBox.repaint();
    }

    public void undoAction() {
        if (!backStack.isEmpty()) {
            forwardStack.push(b.clone());
            b = backStack.pop();
        }
        redraw();
    }

    public void redoAction() {
        if (!forwardStack.isEmpty()) {
            backStack.push(b.clone());
            b = forwardStack.pop();
        }
        redraw();
    }

    public void graphBoxAction(int x, int y, int button) {
        if (button != 1) {
            /* not a left click */
            b.next();
            redraw();

            /* catch the user if they are doing perfect.
             * Maybe the db doesn't exist. */
            if (player[0].strategy.equals("perfect")) {
                setStrategy(0, player[0].strategy);
            }
            if (player[1].strategy.equals("perfect")) {
                setStrategy(1, player[1].strategy);
            }
            return;
        }
        if (!player[b.turn].isComp) {
            int m = (int) ((x * 1.0) / (b.squareSize * 1.0));
            int n = (int) ((y * 1.0) / (b.squareSize * 1.0));
            if (move(m, n)) {
                x = m + 1;
                y = n + 1;
                textBox.print(player[b.IsNext()].name + " moves to (" + x + "," + y + ")");
            }
        }
        else {
            textBox.print("It is the computer's turn. [Hit space]");
        }
    }

    public void nextMoveAction() {
        if (player[b.turn].isComp) {
            int[] mn = player[b.turn].makeMove(b);
            if (mn[0] == -1 || mn[1] == -1) {
                textBox.print(player[b.turn].name + " cannot move.");
            }
            else {
                move(mn[0], mn[1]);
                int x = mn[0] + 1;
                int y = mn[1] + 1;
                textBox.print(player[b.IsNext()].name + " moves (" + x + "," + y + ")");
            }

        }
        else {
            textBox.print("It's your turn.");
        }
    }

    private Boolean move(int m, int n) {
        if (b.canMove(m, n)) {
            backStack.push((Board) b.clone());
            forwardStack = new Stack();
            b.move(m, n);
            redraw();
            return true;
        }
        return false;
    }

    private int playSimulation(Board c) {
        int[] xy;
        while (true) {
            xy = player[c.turn].makeMove(c);
            if (xy[0] == -1 || xy[1] == -1) {
                return c.IsNext();
            }
            if (!c.canMove(xy[0], xy[1])) {
                return c.IsNext();
            }
            else {
                c.move(xy[0], xy[1]);
            }
        }
    }

    public int simulate(int numTrials, Boolean show) {
        double timeStarted = System.currentTimeMillis();
        double timeDiff;
        int[] results = new int[numTrials];
        Board c;
        for (int i = 0; i < numTrials; i++) {
            c = new Board(b.width, b.height, b.s_x, b.s_y, b.squareSize, b.firstPlayer);
            results[i] = playSimulation(c);

        }

        timeDiff = System.currentTimeMillis() - timeStarted;
        if (show) {
            textBox.print("\nResults from" + numTrials + " trials simulated in " + timeDiff + "ms");
        }
        int sum = 0;
        for (int i = 0; i < numTrials; i++) {
            sum += results[i];
        }
        double wp = (1.0 * sum) / (1.0 * numTrials);
        double bp = 1 - wp;
        if (show) {
            if (b.firstPlayer == 1) {
                /*then we have to switch the results*/
                textBox.print("player 1 : White : " + player[b.firstPlayer].strategy + " : probability: " + bp);
                textBox.print("player 2 : Black : " + player[(b.firstPlayer + 1) % 2].strategy + " : probability: " + wp + "\n");
            }
            else {
                textBox.print("player 1 : Black : " + player[b.firstPlayer].strategy + " : probability: " + bp);
                textBox.print("player 2 : White : " + player[(b.firstPlayer + 1) % 2].strategy + " : probability: " + wp + "\n");
            }
        }
        /* just return blacks stats */
        return numTrials - sum;

    }

    public void beginEvolveThread(int startPlayer){
        EvolveThread T = new EvolveThread();
        T.startPlayer = startPlayer;
        Thread et = new Thread(T);
        et.setPriority(Thread.MIN_PRIORITY);
        et.start();
    }

    public class EvolveThread implements Runnable {

        int startPlayer;
        public void run() {
            startEvolution();
        }

        public void collectValues(ArrayList<ValueArray> valueArray, int starter) {

            int blackWins;
            int trials = 1;
            for (int i = 0; i < valueArray.size(); i++) {
                for (int j = 0; j < valueArray.size(); j++) {
                    if(i!=j){
                        player[0].valueArray = valueArray.get(i);
                        player[1].valueArray = valueArray.get(j);
                        b.firstPlayer = 0;
                        if(starter==1){
                            blackWins = simulate(trials, false);
                            valueArray.get(i).wins += blackWins;
                            valueArray.get(i).games += trials;
                        }
                        else{
                            blackWins = simulate(trials, false);
                            valueArray.get(j).wins += trials - blackWins;
                            valueArray.get(j).games += trials;
                        }
                    }
                }
            }
        }

        private void evolveValues(ArrayList<ValueArray> valueArray) {

            int killCount = 0;
            int bornCount = 0;
            int origSize = valueArray.size();
            int median = (int) Math.ceil(origSize / 2.0);
            //textBox.print("BEFORE----------");
            ValueArray tmp2;
            for(int i=0;i<valueArray.size();i++){
                tmp2 = valueArray.get(i);
                //textBox.print(i+": "+tmp2.wins+"/"+tmp2.games+" value\n"+tmp2.print()+"\n");
            }


            /* ditch our below 50%'s */
            Collections.sort(valueArray, new ValueArrayComparator());

            //textBox.print("AFTER----------");
            for(int i=0;i<valueArray.size();i++){
                tmp2 = valueArray.get(i);
                //textBox.print(i+": "+tmp2.wins+"/"+tmp2.games+" value\n"+tmp2.print()+"\n");
            }

            
            textBox.print("best: "+valueArray.get(valueArray.size()-1).wins+"/"+valueArray.get(valueArray.size()-1).games);
            textBox.print("\n"+valueArray.get(valueArray.size()-1).print());
            for (int i = 0; i < median; i++) {
                //textBox.print("\n"+valueArray.get(i).print());
                valueArray.remove(i);
                killCount++;
            }
            int tmp = valueArray.size();
            for (int i = 0; i < tmp; i++) {
                if (valueArray.get(i).games != 0) {
                    valueArray.add(valueArray.get(i).evolve());
                    bornCount++;
                }
            }

            ValueArray toAdd = new ValueArray(b.width,b.height);
            toAdd.initDefault();
            valueArray.add(toAdd);

            toAdd = new ValueArray(b.width,b.height);
            toAdd.initCorner();
            valueArray.add(toAdd);

            toAdd = new ValueArray(b.width,b.height);
            toAdd.initHollow();
            valueArray.add(toAdd);

            toAdd = new ValueArray(b.width,b.height);
            toAdd.initRandom();
            valueArray.add(toAdd);

        }

        public void startEvolution() {
            DBMachine db = new DBMachine();
            db.textBox = textBox;
            int generations = 5;
            setStrategy(0, "depthOneValue");
            setStrategy(1, "depthOneValue");

            textBox.print("Evolving new values.");
            //ArrayList<ValueArray> valueArray = db.getValueArray();
            ArrayList<ValueArray> valueArray = new ArrayList();
//            for (int i = 0; i < 10; i++) {
//                valueArray.add(new ValueArray(b.width, b.height));
//                if(i%2==0){
//                    valueArray.get(i).initPete();
//                }
//                valueArray.get(i).initPete();
//            }


            ValueArray toAdd = new ValueArray(b.width,b.height);
            toAdd.initDefault();
            valueArray.add(toAdd);

            toAdd = new ValueArray(b.width,b.height);
            toAdd.initCorner();
            valueArray.add(toAdd);

            toAdd = new ValueArray(b.width,b.height);
            toAdd.initHollow();
            valueArray.add(toAdd);

            toAdd = new ValueArray(b.width,b.height);
            toAdd.initRandom();
            valueArray.add(toAdd);

            ValueArray tmp2 = new ValueArray(b.width, b.height);
            for (int i = 0; i < 10; i++) {
                valueArray.add(tmp2.evolve());
            }

            for (int i = 0; i < generations; i++) {
                collectValues(valueArray,startPlayer);
                evolveValues(valueArray);
                textBox.print("generation " + i + " of "+generations);
            }
            ValueArray tmp;
            for (int i = 0; i < valueArray.size(); i++) {
                tmp = valueArray.get(i);
                if(tmp.games!=0){
                    textBox.print("wins : " + tmp.wins + " games: " + tmp.games);
                }
            }
            Collections.sort(valueArray, new ValueArrayComparator());
            if(startPlayer==1){
                firstValueArray = valueArray.get(valueArray.size()-1);
                player[b.firstPlayer].valueArray = firstValueArray;
                player[b.firstPlayer].strategy = "evolved";
                textBox.print("Set best values for first player:\n"+firstValueArray.print());
            }
            else if(startPlayer==2){
                secondValueArray = valueArray.get(valueArray.size()-1);
                player[(b.firstPlayer+1)%2].valueArray = secondValueArray;
                player[(b.firstPlayer+1)%2].strategy = "evolved";
                textBox.print("Set best values for second player:\n"+secondValueArray.print());
            }
            else{
                System.out.println("error: startPlayer ?");
                System.exit(1);
            }

        }
    }


}
