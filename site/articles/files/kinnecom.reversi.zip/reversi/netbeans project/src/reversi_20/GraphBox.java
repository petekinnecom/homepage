/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package reversi_20;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JPanel;

/**
 *
 * @author pete
 */
class GraphBox extends JPanel{
    Image buffer;


    public void initBuffer(){
        buffer = createImage(1000,1000);
    }

    @Override
    public void paint(Graphics g) {
        g.drawImage(buffer, 0, 0, this);
    }

}
