package reversi_20;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.util.Arrays;

public class Board implements Cloneable {

    int[][] pos = new int[8][8];
    int turn;
    int width;
    int height;
    int s_x;
    int s_y;
    int squareSize;
    Boolean hints;
    int level;
    int parent;
    int id;
    int outcomeClass;
    int firstPlayer;
    Boolean firstPlay;
    double value;


    @Override
    public Board clone() {
        int[][] tmpPos = new int[8][8];
        Board tmp = new Board();

        for (int i = 0; i < width; i++) {
            tmpPos[i] = pos[i].clone();
        }

        tmp.pos = tmpPos;
        tmp.turn = turn;
        tmp.width = width;
        tmp.height = height;
        tmp.squareSize = squareSize;
        tmp.s_x = s_x;
        tmp.s_y = s_y;
        tmp.hints = hints;
        tmp.firstPlay = firstPlay;
        tmp.firstPlayer = firstPlayer;

        tmp.level = level;
        tmp.parent = parent;
        tmp.id = id;
        tmp.value = value;
        return tmp;
    }

    public Board() {
        this(8, 8, 3, 3, 80,0);
    }
    public Board(int width, int height, int s_x, int s_y, int squareSize){
        this(width, height, s_x, s_y, squareSize, 0);
    }
    Board(int width, int height, int s_x, int s_y, int squareSize, int firstPlayer) {
        this.width = width;
        this.height = height;
        this.s_x = s_x;
        this.s_y = s_y;
        this.squareSize = squareSize;
        this.hints = true;
        this.firstPlayer = firstPlayer;
        this.firstPlay = true;
        value = 0;
        turn = firstPlayer;
        for (int i = 0; i < this.width; i++) {
            Arrays.fill(pos[i], -1);
        }
        pos[s_x][s_y] = 0;
        pos[s_x][s_y + 1] = 1;
        pos[s_x + 1][s_y + 1] = 0;
        pos[s_x + 1][s_y] = 1;
    }

    public void draw(Image buffer) {

        Graphics2D g2d = (Graphics2D) buffer.getGraphics();
        g2d.setColor(new Color(238,238,238));
        //g2d.setColor(Color.BLACK);
        g2d.fillRect(0, 0, 1000, 1000);
        /* draw the background */
        Color green = new Color(0.0f, 0.9f, 0.5f);
        g2d.setColor(green);
        g2d.fillRect(0, 0, width * squareSize, height * squareSize);


        /* draw grid */
        for (int i = 0; i <= width; i++) {
            g2d.setColor(Color.GRAY);
            g2d.drawLine(i * squareSize, 0, i * squareSize, height * squareSize);
        }
        for (int j = 0; j <= height; j++) {
            g2d.setColor(Color.GRAY);
            g2d.drawLine(0, j * squareSize, width * squareSize, j * squareSize);
        }
        /* highlight the possible moves */
        if (hints) {
            double offSet = 1.5 / 5.0;
            double offSize = 2.0 / 5.0;
            if(turn==0){
                g2d.setColor(new Color(0.4f, 1.0f, 0.94f));
            }
            else{
                g2d.setColor(new Color(1.0f, 1.0f, 0.5f));
            }
            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    if (canMove(i, j)) {
                        g2d.fillRect((int) ((i + offSet) * squareSize), (int) ((j + offSet) * squareSize), (int) ((offSize) * squareSize), (int) ((offSize) * squareSize));
                    }
                }
            }
        }
        /* draw tokens */
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (pos[i][j] == 0) {
                    g2d.setColor(Color.BLACK);
                    g2d.fillOval(i * squareSize + 2, j * squareSize + 2, squareSize - 4, squareSize - 4);
                } else if (pos[i][j] == 1) {
                    g2d.setColor(Color.WHITE);
                    g2d.fillOval(i * squareSize + 2, j * squareSize + 2, squareSize - 4, squareSize - 4);
                }
            }
        }

    }

    public void next() {
        turn = (turn + 1) % 2;
        if(firstPlay){
            firstPlayer = turn;
        }
    }

    public int IsNext() {
        return (turn + 1) % 2;
    }

    public String getConnectionString() {
        /* Form the unique identifier for each game arrangement:
         * b[4,4]sp[1,1]turn[0].db
         */
        String s = "jdbc:sqlite:";
        s = s + "b[" + width + "," + height + "]sp[" + s_x + "," + s_y + "]turn[" + firstPlayer + "].db";
        return s;
    // return "jdbc:sqlite:sample.db";
    }

    int moveCountNumFlipped(int m, int n) {

        /* done: 0 -> we are not done
         *       1 -> we have finished because we hit the edge
         *       2 -> we have a valid in between.
         */
        int tmpCount;
        int done;
        int x;
        int y;
        int numFlipped = 0;

        /* no player here */
        if (pos[m][n] != -1) {
            return 0;
        }
        /* off the board */
        if (m >= width || n >= height) {
            return 0;
        }

        for (int i = -1; i < 2; i++) {

            for (int j = -1; j < 2; j++) {

                //we have chosen our slope, now follow that line
                tmpCount = 0;
                done = 0;

                for (int k = 1; done == 0; k++) {

                    /* The square in question */
                    x = m + k * i;
                    y = n + k * j;
                    //System.out.print("checking: "+x+","+y +"  -> ");
                    if (x < 0 || y < 0 || x >= width || y >= height) {
                        done = 1; //FAILURE
                    } else if (pos[x][y] == IsNext()) {
                        tmpCount++; //KeepGoing
                    } else if (pos[x][y] == turn) {
                        done = 2; //Possible success
                    } else {
                        done = 1; //Catch all
                    }
                //System.out.print(done +"\n");
                }

                /* If we stopped because we hit our own piece
                 * AND we had more than one between us, then yes! */

                if (tmpCount > 0 && done == 2) {
                    numFlipped += tmpCount;
                }
            }

        }
        return numFlipped;
    }

    boolean canMove(int m, int n) {

        /* done: 0 -> we are not done
         *       1 -> we have finished because we hit the edge
         *       2 -> we have a valid in between.
         */
        int tmpCount;
        int done;
        int x;
        int y;

        /* off the board */
        if (m >= width || n >= height) {
            return false;
        }

        /* no player here */
        if (pos[m][n] != -1) {
            return false;
        }


        for (int i = -1; i < 2; i++) {

            for (int j = -1; j < 2; j++) {

                //we have chosen our slope, now follow that line
                tmpCount = 0;
                done = 0;

                for (int k = 1; done == 0; k++) {

                    /* The square in question */
                    x = m + k * i;
                    y = n + k * j;
                    //System.out.print("checking: "+x+","+y +"  -> ");
                    if (x < 0 || y < 0 || x >= width || y >= height) {
                        done = 1; //FAILURE
                    } else if (pos[x][y] == IsNext()) {
                        tmpCount++; //KeepGoing
                    } else if (pos[x][y] == turn) {
                        done = 2; //Possible success
                    } else {
                        done = 1; //Catch all
                    }
                //System.out.print(done +"\n");
                }

                /* If we stopped because we hit our own piece
                 * AND we had more than one between us, then yes! */

                if (tmpCount > 0 && done == 2) {
                    return true;
                }
            }
        }
        return false;
    }

    boolean move(int m, int n) {
        /* done: 0 -> we are not done
         *       1 -> we have finished because we hit the edge
         *       2 -> we have a valid in between.
         */

        if (!canMove(m, n)) {
            return false;
        }

        int done = 0;
        int x;
        int y;
        boolean hasMoved = false;

        int tmpCount;

        if (pos[m][n] != -1) {
            return false;
        }
        if (m >= width || n >= height) {
            return false;
        }
        //System.out.println(" ----- Checked : " + m +","+n+" ----- ");
        for (int i = -1; i < 2; i++) {

            for (int j = -1; j < 2; j++) {

                //we have chosen our slope, now follow that line
                tmpCount = 0;
                done = 0;

                for (int k = 1; done == 0; k++) {
                    x = m + k * i;
                    y = n + k * j;
                    //System.out.print("checking: "+x+","+y +"  -> ");
                    if (x < 0 || y < 0 || x >= width || y >= height) {
                        done = 1; //Failure
                    } else if (pos[x][y] == IsNext()) {
                        tmpCount++; //keepGoing
                    } else if (pos[x][y] == turn) {
                        done = 2; //maybe
                    } else {
                        done = 1; //catchAll
                    }
                //System.out.print(done +"\n");
                }

                if (tmpCount > 0 && done == 2) {
                    done = 0;
                    for (int k = 1; done == 0; k++) {
                        x = m + k * i;
                        y = n + k * j;
                        if (pos[x][y] == IsNext()) {
                            pos[x][y] = turn;
                            hasMoved = true;
                        } else if (pos[x][y] == turn) {
                            done = 2;
                        } else {
                            done = 1;
                            System.out.println("Massive Logical Failure: Board.java:327");
                            System.exit(1);
                        }
                    }
                }
            //System.out.println("");

            }

        }

        pos[m][n] = turn;
        firstPlay = false;
        next();

        return true;

    }
    public void applyValues(double[][] v){

        double Tvalue=0;
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                if(pos[i][j] == turn){
                    Tvalue += v[i][j];
                }
                else if(pos[i][j] == IsNext()){
                    Tvalue -= v[i][j];
                }
            }
        }

        this.value = Tvalue;

    }
    
    public int countOptions() {

        int numOptions = 0;
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                if(canMove(i,j)){
                    numOptions++;
                }
            }
        }
        return numOptions;
    }

    public String posToString() {
        String t = new String();
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                t = t + pos[i][j] + ",";
            }
        }
        return t;
    }

    public void parseBoard(String string) {
        String[] tokens = string.split(",");
        int k=0;
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                if(k<tokens.length){
                    pos[i][j] = Integer.parseInt(tokens[k]);
                    k++;
                }
                else{
                    System.out.println("error?");
                }
            }
        }

    }

    public void print() {
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                System.out.print(pos[i][j] + " , ");
            }
            System.out.print("\n");
        }
        System.out.println("\n");
    }

}


