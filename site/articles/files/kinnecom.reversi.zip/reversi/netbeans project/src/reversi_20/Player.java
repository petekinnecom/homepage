/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reversi_20;

import java.util.Random;

/**
 *
 * @author pete
 */
public class Player {

    Boolean isComp;
    String strategy;
    String name;
    TextBox textBox;
    DBMachine db;
    ValueArray valueArray;

    public Player(int i, TextBox textBox, Board b) {
        db = new DBMachine();
        valueArray = new ValueArray(b);
        valueArray.initHollow();

        db.textBox = textBox;

        this.textBox = textBox;
        isComp = false;
        strategy = "user";
        if (i == 0) {
            name = "Black";
        }
        else {
            name = "White";
        }
    }

    public void setStrategy(String s, Board b, double[][] v) {

        if (s.equals("user")) {
            strategy = s;
            isComp = false;
        }
        else {
            strategy = s;
            isComp = true;
        }

       if (s.equals("minimize,greedy,value")) {
            valueArray.initHollowCorners();
            textBox.print(valueArray.print());
        }

    }
    public void setStrategy(String s, Board b) {

        setStrategy(s,b,new double[1][1]);
    }
    public int[] makeMove(Board b) {
        if (strategy.equals("random")) {
            return moveRandom(b);
        }
        else if (strategy.equals("greedy+")) {
            return moveGreedyPlus(b);
        }
        else if (strategy.equals("greedy-")) {
            return moveGreedyMinus(b);
        }
        else if (strategy.equals("perfect")) {
            return movePerfect(b);
        }
        else if(strategy.equals("minimize")){
            return moveDepthOne(b);
        }
        else if(strategy.equals("minimize,greedy,value")){
            return moveMinimizeGreedyValue(b);
        }
        else if(strategy.equals("minimize,greedy-")){
            return moveMinimizeGreedy(b);
        }
        else if(strategy.equals("greedy-,minimize")){
            return moveGreedyMinimize(b);
        }
        else {
            int[] mn = {-1, -1};
            return mn;
        }

    }

    private int[] moveDepthOne(Board b) {
        int[][] mn = new int[225][2];
        int k = 9999;
        int mnCount=0;
        int tmp;
        Board c;
        Random r = new Random();

        for(int i=0;i<b.width;i++){
            for(int j=0;j<b.height;j++){
                if(b.canMove(i, j)){
                    c = b.clone();
                    c.move(i,j);
                    tmp = c.countOptions();
                    if(tmp<k){
                        k = tmp;
                        mn[0][0] = i;
                        mn[0][1] = j;
                        mnCount = 1;
                    }
                    else if(tmp==k){
                        mn[mnCount][0] = i;
                        mn[mnCount][1] = j;
                        mnCount++;
                    }
                }
            }
        }
        if(mnCount==0){
            int[] xy = {-1,-1};
            return xy;
        }
        else{
            return mn[r.nextInt(mnCount)];
        }
    }

    private int[] moveDepthOneValue(Board b) {
        int[][] mn = new int[225][2];
        int k = 9999;
        int mnCount=0;
        int tmp;
        Board c;
        Board[] d = new Board[30];
        Random r = new Random();

        for(int i=0;i<b.width;i++){
            for(int j=0;j<b.height;j++){
                if(b.canMove(i, j)){
                    c = b.clone();
                    c.move(i,j);
                    tmp = c.countOptions();
                    if(tmp<k){
                        k = tmp;
                        mn[0][0] = i;
                        mn[0][1] = j;
                        d[0] = c.clone();
                        mnCount = 1;

                    }
                    else if(tmp==k){
                        mn[mnCount][0] = i;
                        mn[mnCount][1] = j;
                        d[mnCount] = c.clone();
                        mnCount++;
                    }
                }
            }
        }
        if (mnCount == 0) {
            int[] xy = {-1, -1};
            return xy;
        }

        /* Now find the board with the max/min value */
        double maxVal = -9999.0;
        int[][] canDo = new int[30][2];
        int canDoCount = 0;
        for (int i = 0; i < mnCount; i++) {

            /* For every equivalent board, find the value
             * catch boards with the same value and return
             * a random one */

            d[i].applyValues(valueArray.v);
            int x = mn[i][0] + 1;
            int y = mn[i][1] + 1;
            //textBox.print("value : "+d[i].value + " for move to ("+x+","+y+")");
            if (d[i].value > maxVal) {
                canDo[0] = mn[i];
                canDoCount = 1;
                maxVal = d[i].value;
            }
            else if (d[i].value == maxVal) {
                canDo[canDoCount] = mn[i];
                canDoCount++;

            }
        }
        if(canDoCount==0){
            System.out.println("mnC: " +mnCount+" and cDC: "+canDoCount+" d[0].value="+d[0].value+"\n\nval:"+valueArray.print());
            System.exit(1);
        }
        //textBox.print(valueArray.print());
        return canDo[r.nextInt(canDoCount)];

    }
    private int[] moveGreedyMinimize(Board b) {
        int[][] mn = new int[225][2];
        int minPieceCount = 9999;
        int minOppMove = 9999;
        int mnCount=0;
        int tmp;
        Board c;

        for (int i = 0; i < b.width; i++) {
            for (int j = 0; j < b.height; j++) {
                tmp = b.moveCountNumFlipped(i,j);
                c = b.clone();
                c.move(i,j);
                if (tmp < minPieceCount && b.canMove(i, j)) {
                    /* This is our new min, reset k and mnCount */
                    mn[0][0] = i;
                    mn[0][1] = j;
                    mnCount=1;

                    minPieceCount = tmp;
                    minOppMove = c.countOptions();
                }
                else if(tmp==minPieceCount && b.canMove(i, j)){
                    if(c.countOptions()<minOppMove){
                        mn[0][0] = i;
                        mn[0][1] = j;
                        mnCount=1;

                        minPieceCount = tmp;
                        minOppMove = c.countOptions();

                    }
                    else if(c.countOptions()==minOppMove){
                        mn[mnCount][0] = i;
                        mn[mnCount][1] = j;
                        mnCount++;
                    }
                    /* this is another option */

                }
            }
        }
        if(mnCount==0){
            int[] xy = {-1,-1};
            return xy;
        }
        else {
            Random r = new Random();
            int i = r.nextInt(mnCount);
            return mn[i];
        }
    }

    private int[] moveMinimizeGreedy(Board b) {
        int[][] mn = new int[225][2];
        int minPieceCount = 9999;
        int minOppMove = 9999;
        int mnCount = 0;
        int numFlipped;
        int numOptions;
        Board c;

        for (int i = 0; i < b.width; i++) {
            for (int j = 0; j < b.height; j++) {
                if (b.canMove(i, j)) {
                    numFlipped = b.moveCountNumFlipped(i, j);
                    c = b.clone();
                    c.move(i, j);
                    numOptions = c.countOptions();
                    if (numOptions < minOppMove) {
                        /* This is our new min, reset k and mnCount */
                        mn[0][0] = i;
                        mn[0][1] = j;
                        mnCount = 1;

                        minPieceCount = numFlipped;
                        minOppMove = numOptions;
                    }
                    else if (numOptions == minOppMove) {
                        if (numFlipped < minPieceCount) {
                            mn[0][0] = i;
                            mn[0][1] = j;
                            mnCount = 1;

                            minPieceCount = numFlipped;
                            minOppMove = numOptions;

                        }
                        else if (numFlipped == minPieceCount) {
                            mn[mnCount][0] = i;
                            mn[mnCount][1] = j;
                            mnCount++;
                        }
                    /* this is another option */

                    }
                }
            }
        }
//        if(mnCount>1){
//            System.out.println("random");
//        }
        if(mnCount==0){
            int[] xy = {-1,-1};
            return xy;
        }

        else{
            Random r = new Random();
            int i = r.nextInt(mnCount);
            int x = mn[i][0] + 1;
            int y = mn[i][1] + 1;
            return mn[i];
        }
    }

    private int[] moveMinimizeGreedyValue(Board b) {
        int[][] mn = new int[225][2];
        int minPieceCount = 9999;
        int minOppMove = 9999;
        double maxValue = -9999;
        int mnCount = 0;
        int numFlipped;
        int numOptions;
        Board c;

        for (int i = 0; i < b.width; i++) {
            for (int j = 0; j < b.height; j++) {
                if (b.canMove(i, j)) {
                    numFlipped = b.moveCountNumFlipped(i, j);
                    c = b.clone();
                    c.move(i, j);
                    numOptions = c.countOptions();
                    if (numOptions < minOppMove) {
                        /* This is our new min, reset k and mnCount */
                        mn[0][0] = i;
                        mn[0][1] = j;
                        mnCount = 1;

                        minPieceCount = numFlipped;
                        minOppMove = numOptions;
                        maxValue = valueArray.v[i][j];
                    }
                    else if (numOptions == minOppMove) {
                        if (numFlipped < minPieceCount) {
                            mn[0][0] = i;
                            mn[0][1] = j;
                            mnCount = 1;

                            minPieceCount = numFlipped;
                            minOppMove = numOptions;
                            maxValue = valueArray.v[i][j];
                        }
                        else if (numFlipped == minPieceCount) {
                            if (valueArray.v[i][j] > maxValue) {
                                mn[0][0] = i;
                                mn[0][1] = j;
                                mnCount = 1;

                                minPieceCount = numFlipped;
                                minOppMove = numOptions;
                                maxValue = valueArray.v[i][j];
                            }
                            else if (valueArray.v[i][j] == maxValue) {
                                mn[mnCount][0] = i;
                                mn[mnCount][1] = j;
                                mnCount++;
                            }
                        }
                    /* this is another option */

                    }
                }
            }
        }
        if(mnCount==0){
            int[] xy = {-1,-1};
            return xy;
        }
        else{
           // System.out.println("random");
            Random r = new Random();
            int i = r.nextInt(mnCount);
            int x = mn[i][0]+1;
            int y = mn[i][1]+1;
            return mn[i];
        }
    }

    private int[] moveGreedyPlus(Board b) {
        int[][] mn = new int[225][2];
        int k = 0;
        int mnCount=0;
        int tmp;

        for (int i = 0; i < b.width; i++) {
            for (int j = 0; j < b.height; j++) {
                tmp = b.moveCountNumFlipped(i,j);
                if (tmp > k) {
                    mn[0][0] = i;
                    mn[0][1] = j;
                    mnCount = 1;
                    k = tmp;
                }
                else if(tmp==k){
                    mn[mnCount][0] = i;
                    mn[mnCount][1] = j;
                    mnCount++;
                }
            }
        }
        if (mnCount == 0) {
            int[] xy = {-1, -1};
            return xy;
        }
        else {
            Random r = new Random();
            int i = r.nextInt(mnCount);
            return mn[i];
        }
    }

    private int[] moveGreedyMinus(Board b) {
        int[][] mn = new int[225][2];
        int k = 9999;
        int mnCount=0;
        int tmp;

        for (int i = 0; i < b.width; i++) {
            for (int j = 0; j < b.height; j++) {
                tmp = b.moveCountNumFlipped(i,j);
                if (tmp < k && b.canMove(i, j)) {
                    /* This is our new min, reset k and mnCount */
                    mn[0][0] = i;
                    mn[0][1] = j;
                    mnCount=1;
                    k = tmp;
                }
                else if(tmp==k){
                    /* this is another option */
                    mn[mnCount][0] = i;
                    mn[mnCount][1] = j;
                    mnCount++;
                }
            }
        }
        if(mnCount==0){
            int[] xy = {-1,-1};
            return xy;
        }
        else{
            Random r = new Random();
            int i = r.nextInt(mnCount);
            return mn[i];
        }
    }


    private int[] movePerfect(Board b) {
        return db.getNextMove(b);
    }

    private int[] moveRandom(Board b) {
        int[][] mn = new int[64][2];
        int k = 0;
        Random rand = new Random();
        mn[0][0] = -1;
        mn[0][1] = -1;
        for (int i = 0; i < b.width; i++) {
            for (int j = 0; j < b.height; j++) {
                if (b.canMove(i, j)) {
                    mn[k][0] = i;
                    mn[k][1] = j;
                    k++;
                }
            }
        }
        if (mn[0][0] == -1) {
            return mn[0];
        }
        else {
            int i = rand.nextInt(k);
            return mn[i];
        }
    }
}
