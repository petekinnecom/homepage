/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reversi_20;

import java.util.Comparator;

/**
 *
 * @author pete
 */
public class ValueArrayComparator implements Comparator<ValueArray> {

    public int compare(ValueArray a, ValueArray b) {
        double aWins, bWins;
        if(a.games==0 || b.games==0){
            System.out.println("error:");
            //System.exit(1);
        }
        aWins = (a.wins * 1.0) / (a.games * 1.0);
        bWins = (b.wins * 1.0) / (b.games * 1.0);


        if (aWins < bWins) {
            return -1;
        }
        else if (aWins > bWins) {
            return 1;
        }
        else{
            return 0;
        }
    }
}