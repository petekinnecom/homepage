/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package reversi_20;

import java.text.DecimalFormat;
import java.util.Random;

/**
 *
 * @author pete
 */
public class ValueArray {

    public double[][] v;
    public int wins;
    public int games;

    public ValueArray(Board b){
        v = new double[b.width][b.height];
        wins = 0;
        games = 0;
    }

    public ValueArray(int width, int height) {
        v = new double[width][height];
        wins = 0;
        games = 0;
        initDefault();
    }
    public void initDefault(){
        for(int i=0;i<v.length;i++){
            for(int j=0;j<v[i].length;j++){
                v[i][j] = 1;
            }
        }
    }

    public ValueArray copyVals(){
        ValueArray tmp = new ValueArray(this.v.length,this.v[0].length);
        for(int i=0;i<v.length;i++){
            tmp.v[i] = this.v[i].clone();
        }
        return tmp;
    }
    public ValueArray evolve(){
        /* change amplitude is 1-win%.  Better values evolve less */

        double var;

        if(games==0){var=0.5;}
        else{var = (wins*1.0)/(games*1.0);}
        if(var>.5){var = 1-var;}
        Random r = new Random();

        ValueArray tmp = this.copyVals();
        for(int i=0;i<v.length;i++){
            for(int j=0;j<v[0].length;j++){
                if(r.nextBoolean()){
                    tmp.v[i][j] = this.v[i][j]+r.nextDouble()*var;
                }
                else{
                   tmp.v[i][j] = this.v[i][j]-r.nextDouble()*var;
                }
            }
        }
        //System.out.println(tmp.print());
        return tmp;
    }

    public String print() {
        String s = new String();
        DecimalFormat df = new DecimalFormat("#.##");

        for(int i=0;i<v.length;i++){
            for(int j=0;j<v[0].length;j++){
                s = s + df.format(v[i][j])+" , ";
            }
            s = s +"\n";
        }
        return s;
    }

    void initCorner() {
        double[] r1 = { 2, 1, 1, 1, 1, 1, 1, 2 };
        double[] r2 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        double[] r3 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        double[] r4 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        double[] r5 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        double[] r6 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        double[] r7 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        double[] r8 = { 2, 1, 1, 1, 1, 1, 1, 2 };
        v[0] = r1;
        v[1] = r2;
        v[2] = r3;
        v[3] = r4;
        v[4] = r5;
        v[5] = r6;
        v[6] = r7;
        v[7] = r8;
    }

    void initHollow() {
        double[] r1 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        double[] r2 = { 1, 0, 0, 0, 0, 0, 0, 1 };
        double[] r3 = { 1, 0, 1, 1, 1, 1, 0, 1 };
        double[] r4 = { 1, 0, 1, 0, 0, 1, 0, 1 };
        double[] r5 = { 1, 0, 1, 0, 0, 1, 0, 1 };
        double[] r6 = { 1, 0, 1, 1, 1, 1, 0, 1 };
        double[] r7 = { 1, 0, 0, 0, 0, 0, 0, 1 };
        double[] r8 = { 1, 1, 1, 1, 1, 1, 1, 1 };
        v[0] = r1;
        v[1] = r2;
        v[2] = r3;
        v[3] = r4;
        v[4] = r5;
        v[5] = r6;
        v[6] = r7;
        v[7] = r8;
    }
    void initHollowCorners() {
        double[] r1 = { 5, 0, 3, 3, 3, 3, 0, 5 };
        double[] r2 = { 0, 0, 0, 0, 0, 0, 0, 0 };
        double[] r3 = { 3, 0, 1, 1, 1, 1, 0, 3 };
        double[] r4 = { 3, 0, 1, 0, 0, 1, 0, 3 };
        double[] r5 = { 3, 0, 1, 0, 0, 1, 0, 3 };
        double[] r6 = { 3, 0, 1, 1, 1, 1, 0, 3 };
        double[] r7 = { 0, 0, 0, 0, 0, 0, 0, 0 };
        double[] r8 = { 5, 0, 3, 3, 3, 3, 0, 5 };

        v[0] = r1;
        v[1] = r2;
        v[2] = r3;
        v[3] = r4;
        v[4] = r5;
        v[5] = r6;
        v[6] = r7;
        v[7] = r8;
    }
    void initRandom(){
        Random r = new Random();
        for(int i=0;i<v.length;i++){
            for(int j=0;j<v[0].length;j++){
                v[i][j] = r.nextInt(3);
            }
        }

    }

    void initUserValue(double[][] v) {
        this.v = v;
    }

}
