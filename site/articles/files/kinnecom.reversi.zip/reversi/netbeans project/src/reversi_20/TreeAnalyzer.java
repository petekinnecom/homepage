/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reversi_20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pete
 */
public class TreeAnalyzer {

    private Board b = new Board();
    private String CONNECTION;
    private TextBox textBox;

    public Boolean preLoad() {

        try {
            // load the sqlite-JDBC driver using the current class loader
            Class.forName("org.sqlite.JDBC");

        } catch (ClassNotFoundException ex) {

            textBox.print("Crashed and burned: ");
            textBox.print(ex.getLocalizedMessage());
            return false;
        }
        return true;
    }

    public void startAnalyzeTreeMainLoop(Board b, TextBox textBox) {
        this.b = new Board(b.width, b.height, b.s_x, b.s_y, b.squareSize, b.firstPlayer);
        this.textBox = textBox;
        CONNECTION = b.getConnectionString();



        if (preLoad()) {
            Thread atl = new Thread(new AnalyzeTreeLoop());
            atl.setPriority(Thread.MIN_PRIORITY);
            atl.start();
        }


    // processData();
    }

    public class AnalyzeTreeLoop implements Runnable {

        private int[] parents = new int[200000];
        private int[] outcomeClasses = new int[200000];
        int iParents = 2;


        public void run() {
            Arrays.fill(parents, -1);
            if (getLinks()) {
                if(processData()){
                    addData();
                }
            }
        }

        private Boolean addData() {
            double timeStart = System.currentTimeMillis();
            double timeTotal;

            Connection conn = null;
            boolean success = false;
            try {
                conn = DriverManager.getConnection(CONNECTION);
                Statement statement = conn.createStatement();
                statement.setQueryTimeout(30);
                statement.executeUpdate("PRAGMA synchronous = OFF;");
                statement.executeQuery("PRAGMA journal_mode = OFF;");
                String queryPos = new String();

                /* include outcomeClass[1] because it is our root */
                for(int i=1;i<iParents;i++){
                    statement.addBatch("UPDATE positions SET class="+outcomeClasses[i]+" WHERE id="+i);
                }
                
                statement.executeBatch();

                success = true;

            }
        catch (SQLException ex) {

                Logger.getLogger(TreeBuilder.class.getName()).log(Level.SEVERE, null, ex);
                textBox.print("Crashed and burned: ");
                textBox.print(ex.getLocalizedMessage());
            } finally {
                try {
                    if (conn != null) {
                        conn.close();
                        timeTotal = (System.currentTimeMillis() - timeStart)/1000.0;
                        textBox.print("Level saved in "+timeTotal+"s");
                        return success;
                    }
                } catch (SQLException e) {
                    // connection close failed.
                    System.err.println(e);
                }
            }
            return false;

        }

        private Boolean getLinks() {

            Connection conn = null;
            Boolean success = true;
            double timeStarted = 0;
            double timeDiff = 0;


            textBox.print("Opening Links table.");

            try {
                conn = DriverManager.getConnection(CONNECTION);
                Statement statement = conn.createStatement();
                statement.setQueryTimeout(30);

                timeStarted = System.currentTimeMillis();
                ResultSet rs = statement.executeQuery("SELECT * FROM links");
                while (rs.next()) {
                    parents[rs.getInt("child")] = rs.getInt("parent");
                    iParents++;
                    //positions.get(rs.getInt("parent")).children.add(rs.getInt("child"));
                    if(rs.getInt("child")%50000==0){
                    timeDiff = System.currentTimeMillis() - timeStarted;
                    textBox.print(rs.getInt("child")+" links processed in "+timeDiff+"ms");
                    }
                }
                textBox.print(iParents+" links processed in "+timeDiff+"ms");

            } catch (SQLException ex) {
                textBox.print("Crashed and burned line 203: ");
                textBox.print(ex.getLocalizedMessage());
                success = false;
            } finally {
                try {
                    if (conn != null) {
                        conn.close();
                        return success;
                    }
                } catch (SQLException e) {
                    // connection close failed.
                    System.err.println(e);
                }
            }
            return success;


        }

        private boolean processData() {

            textBox.print("Determining Outcome Classes.");
            Arrays.fill(outcomeClasses, 0);
            /* don't include the outcomeclass[1] because parent[1] is empty */
            for(int i=iParents-1;i>1;i--){
                if(outcomeClasses[i]==0){
                    if(parents[i]==-1){
                        textBox.print("Illegal parent. i: "+i);
                        return false;
                    }
                    outcomeClasses[parents[i]] = 1;
                }
            }
            textBox.print("Finished assigning outcome Classes.  Saving...");
            return true;
        }
    }
}
